/**
 * AeroChromium Build Script
 * Compiles Electron TypeScript files and bundles renderer assets into electron-dist/
 */

import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const outDir = 'electron-dist';

// Ensure output directories exist
fs.mkdirSync(path.join(outDir, 'renderer'), { recursive: true });

async function build() {
  console.log('[Build] Compiling Electron main and preload...');

  // Main process bundle
  await esbuild.build({
    entryPoints: ['electron/main.ts'],
    outfile: path.join(outDir, 'main.cjs'),
    bundle: true,
    platform: 'node',
    target: 'node20',
    format: 'cjs',
    external: ['electron'],
    sourcemap: true,
  });

  // Preload script bundle
  await esbuild.build({
    entryPoints: ['electron/preload.ts'],
    outfile: path.join(outDir, 'preload.cjs'),
    bundle: true,
    platform: 'node',
    target: 'node20',
    format: 'cjs',
    external: ['electron'],
    sourcemap: true,
  });

  // Toolbar Renderer Client Script
  await esbuild.build({
    entryPoints: ['electron/renderer/chrome.ts'],
    outfile: path.join(outDir, 'renderer', 'chrome.js'),
    bundle: true,
    platform: 'browser',
    target: 'chrome120',
    format: 'iife',
    sourcemap: true,
  });

  // New Tab Client Script
  await esbuild.build({
    entryPoints: ['electron/renderer/newtab.ts'],
    outfile: path.join(outDir, 'renderer', 'newtab.js'),
    bundle: true,
    platform: 'browser',
    target: 'chrome120',
    format: 'iife',
    sourcemap: true,
  });

  // Copy static HTML and CSS files
  const filesToCopy = [
    ['electron/renderer/chrome.html', 'renderer/chrome.html'],
    ['electron/renderer/chrome.css', 'renderer/chrome.css'],
    ['electron/renderer/newtab.html', 'renderer/newtab.html'],
    ['electron/renderer/newtab.css', 'renderer/newtab.css'],
  ];

  for (const [src, dest] of filesToCopy) {
    if (fs.existsSync(src)) {
      fs.copyFileSync(src, path.join(outDir, dest));
    }
  }

  console.log('[Build] AeroChromium build completed successfully in electron-dist/');
}

build().catch((err) => {
  console.error('[Build] Build failed:', err);
  process.exit(1);
});
