/**
 * Client-side Session Engine for live in-browser simulation and verification.
 * Implements the identical Opera GX atomic rotation, validation, and recovery algorithms.
 */

export interface PersistedTab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  lastAccessed: number;
}

export interface ClosedTabRecord {
  url: string;
  title: string;
  favicon?: string;
  closedAt: number;
}

export interface BrowserSessionData {
  version: number;
  lastSaved: string;
  activeTabId: string;
  tabs: PersistedTab[];
  closedTabs?: ClosedTabRecord[];
}

export class SimulatedDiskSessionManager {
  private primaryStorageKey = 'aero_session_v1_primary';
  private backupStorageKey = 'aero_session_v1_backup';
  private isShuttingDown = false;
  private closedTabsHistory: ClosedTabRecord[] = [];
  public operationLogs: Array<{ time: string; action: string; details: string; type: 'info' | 'success' | 'warn' | 'error' }> = [];

  constructor() {
    this.addLog('info', 'Init', 'Simulated Windows %APPDATA% disk storage initialized.');
  }

  private addLog(type: 'info' | 'success' | 'warn' | 'error', action: string, details: string) {
    const time = new Date().toLocaleTimeString();
    this.operationLogs.unshift({ time, action, details, type });
    if (this.operationLogs.length > 50) this.operationLogs.pop();
  }

  public prepareForShutdown(): void {
    this.isShuttingDown = true;
    this.addLog('warn', 'Shutdown Signal', 'Application received before-quit. Destruction-wipeout protection active.');
  }

  public resetShutdown(): void {
    this.isShuttingDown = false;
  }

  public isAppShuttingDown(): boolean {
    return this.isShuttingDown;
  }

  public recordClosedTab(tab: { url: string; title: string; favicon?: string }): void {
    if (this.isShuttingDown) return;
    this.closedTabsHistory.unshift({
      url: tab.url,
      title: tab.title || 'Untitled',
      favicon: tab.favicon,
      closedAt: Date.now(),
    });
    this.addLog('info', 'Tab Closed', `Recorded closed tab: "${tab.title}" for Ctrl+Shift+T restore`);
  }

  public popRecentlyClosedTab(): ClosedTabRecord | null {
    const record = this.closedTabsHistory.shift() ?? null;
    if (record) {
      this.addLog('success', 'Tab Restored', `Restored closed tab: "${record.title}" (${record.url})`);
    }
    return record;
  }

  public getClosedTabsCount(): number {
    return this.closedTabsHistory.length;
  }

  public loadSession(): BrowserSessionData {
    const rawPrimary = localStorage.getItem(this.primaryStorageKey);
    if (rawPrimary) {
      try {
        const parsed = JSON.parse(rawPrimary);
        if (this.isValidSessionPayload(parsed)) {
          this.addLog('success', 'Primary Load', `Successfully loaded ${parsed.tabs.length} tabs from aero-session-v1.json`);
          if (parsed.closedTabs) {
            this.closedTabsHistory = [...parsed.closedTabs];
          }
          return parsed;
        } else {
          this.addLog('warn', 'Corrupt Primary', 'Primary session payload invalid structure. Inspecting .bak backup...');
        }
      } catch {
        this.addLog('error', 'Parse Error', 'Primary file JSON corrupt/truncated. Inspecting .bak backup...');
      }
    }

    // Try backup
    const rawBackup = localStorage.getItem(this.backupStorageKey);
    if (rawBackup) {
      try {
        const parsedBackup = JSON.parse(rawBackup);
        if (this.isValidSessionPayload(parsedBackup)) {
          this.addLog('success', 'Backup Recovered', `Gracefully recovered ${parsedBackup.tabs.length} tabs from aero-session-v1.json.bak!`);
          this.saveSessionSync(parsedBackup.tabs, parsedBackup.activeTabId);
          return parsedBackup;
        }
      } catch {
        this.addLog('error', 'Backup Corrupted', 'Backup session also unreadable.');
      }
    }

    // Fallback default
    this.addLog('info', 'Clean Fallback', 'No readable session found. Starting clean with default New Tab.');
    const fallback: BrowserSessionData = {
      version: 1,
      lastSaved: new Date().toISOString(),
      activeTabId: 'tab-init-1',
      tabs: [{ id: 'tab-init-1', url: 'browser://newtab', title: 'New Tab', lastAccessed: Date.now() }],
      closedTabs: [],
    };
    this.saveSessionSync(fallback.tabs, fallback.activeTabId);
    return fallback;
  }

  public saveSessionSync(tabs: PersistedTab[], activeTabId: string): boolean {
    if (this.isShuttingDown && tabs.length === 0) {
      this.addLog('warn', 'Protected', 'Blocked shutdown destruction from wiping session with 0 tabs!');
      return false;
    }

    if (!tabs || tabs.length === 0) {
      return false;
    }

    // 1. Rotate current valid primary to .bak
    const currentPrimary = localStorage.getItem(this.primaryStorageKey);
    if (currentPrimary) {
      localStorage.setItem(this.backupStorageKey, currentPrimary);
    }

    const payload: BrowserSessionData = {
      version: 1,
      lastSaved: new Date().toISOString(),
      activeTabId: activeTabId || tabs[0].id,
      tabs: tabs.map((t) => ({ ...t })),
      closedTabs: this.closedTabsHistory.slice(0, 15),
    };

    // 2. Atomic write
    localStorage.setItem(this.primaryStorageKey, JSON.stringify(payload, null, 2));
    this.addLog('success', 'Atomic Write', `Session written (${tabs.length} tabs, active: ${activeTabId}). Rotated backup.`);
    return true;
  }

  public corruptPrimaryFile(): void {
    localStorage.setItem(this.primaryStorageKey, '<<< [CRASH_CORRUPTED_JSON_DATA] { version: 1, tabs: ...');
    this.addLog('error', 'Injected Corruption', 'Injected corrupt payload into aero-session-v1.json to test crash recovery!');
  }

  public corruptBothFiles(): void {
    localStorage.setItem(this.primaryStorageKey, 'corrupt primary');
    localStorage.setItem(this.backupStorageKey, 'corrupt backup');
    this.addLog('error', 'Injected Double Corruption', 'Injected corrupt payload into both primary and backup files.');
  }

  public getRawFiles(): { primary: string | null; backup: string | null } {
    return {
      primary: localStorage.getItem(this.primaryStorageKey),
      backup: localStorage.getItem(this.backupStorageKey),
    };
  }

  private isValidSessionPayload(obj: unknown): obj is BrowserSessionData {
    if (!obj || typeof obj !== 'object') return false;
    const c = obj as Record<string, unknown>;
    return c.version === 1 && Array.isArray(c.tabs) && c.tabs.length > 0 && typeof c.activeTabId === 'string';
  }
}
