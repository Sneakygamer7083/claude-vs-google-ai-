import React from 'react';
import { Layers, ShieldCheck, Database, HardDrive, AlertTriangle, Key, Terminal, Code2 } from 'lucide-react';

export const ArchitectureDoc: React.FC = () => {
  return (
    <div className="space-y-8 text-slate-300 text-sm">
      {/* Overview Card */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">System Architecture & Version Strategy</h3>
            <p className="text-xs text-slate-400">Electron v33.4 (Chromium 130, Node 20, V8 12.9)</p>
          </div>
        </div>

        <p className="text-sm leading-relaxed text-slate-300">
          AeroChromium is engineered as a true personal desktop web browser targeting Windows first.
          Instead of using deprecated <code className="text-amber-300 font-mono">BrowserView</code> or fake HTML <code className="text-red-300 font-mono">&lt;iframe&gt;</code> mocks,
          it adopts modern <strong className="text-white">WebContentsView</strong> introduced in Electron 30+ and supported in stable Electron 33.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
            <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider">Main Window</span>
            <p className="text-xs text-slate-400">
              Frameless <code className="text-slate-200">BrowserWindow</code> containing a top 78px isolated toolbar view and dynamic web views underneath.
            </p>
          </div>
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
            <span className="text-xs font-semibold text-purple-400 uppercase tracking-wider">Toolbar Chrome View</span>
            <p className="text-xs text-slate-400">
              Dedicated internal <code className="text-slate-200">WebContentsView</code> running the dark Opera GX interface, isolated with custom Preload IPC.
            </p>
          </div>
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-1">
            <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wider">Web Content Views</span>
            <p className="text-xs text-slate-400">
              Real Chromium rendering instances with full Sandboxing, context isolation, and persistent cookie partition.
            </p>
          </div>
        </div>
      </div>

      {/* Storage Architecture: Deliverable 6 */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800/60 flex items-center justify-center text-purple-400">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Where Session & Profile Data Are Stored</h3>
            <p className="text-xs text-slate-400">Clear separation of browser tab metadata vs website storage</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-cyan-300 font-bold text-xs uppercase tracking-wider">
              <HardDrive className="w-4 h-4" />
              <span>1. Browser Session Metadata (Tabs & State)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Stored in the Windows user profile directory via <code className="text-cyan-300 font-mono">app.getPath(&apos;userData&apos;)</code>:
            </p>
            <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 font-mono text-[11px] text-cyan-400 break-all space-y-1">
              <div>%APPDATA%\AeroChromium\aero-session-v1.json</div>
              <div className="text-amber-400">%APPDATA%\AeroChromium\aero-session-v1.json.bak</div>
              <div className="text-slate-500">%APPDATA%\AeroChromium\aero-session-v1.json.tmp</div>
            </div>
            <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
              <li>Contains tab IDs, URLs, page titles, tab order, and active tab ID.</li>
              <li>Includes stack of up to 30 recently closed tabs for <kbd>Ctrl+Shift+T</kbd>.</li>
              <li>Atomic write: writes to <code className="text-slate-300">.tmp</code>, runs <code className="text-slate-300">fsync</code>, rotates previous state to <code className="text-slate-300">.bak</code>, then renames.</li>
              <li>Never overwritten on shutdown or crash.</li>
            </ul>
          </div>

          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-300 font-bold text-xs uppercase tracking-wider">
              <Database className="w-4 h-4" />
              <span>2. Website Cookies & Profile Storage</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Managed automatically by Chromium under a persistent partition (<code className="text-emerald-300 font-mono">persist:aero-chromium-profile</code>):
            </p>
            <div className="p-3 bg-slate-900/90 rounded-lg border border-slate-800 font-mono text-[11px] text-emerald-400 break-all space-y-1">
              <div>%APPDATA%\AeroChromium\Partitions\aero-chromium-profile\</div>
              <div className="text-slate-400">├── Network\Cookies (SQLite)</div>
              <div className="text-slate-400">├── Local Storage\leveldb\</div>
              <div className="text-slate-400">└── IndexedDB\</div>
            </div>
            <ul className="text-xs text-slate-400 space-y-1 list-disc list-inside">
              <li>Web logins, authentication tokens, session cookies persist across restarts according to site expiration policies.</li>
              <li>Isolated from session metadata so corrupted JSON never damages website cookies.</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Security & Process Boundaries */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-950 border border-emerald-800/60 flex items-center justify-center text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Security & Process Boundaries</h3>
            <p className="text-xs text-slate-400">Treating all remote websites as completely untrusted</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              Full Sandboxing & Context Isolation
            </div>
            <p className="text-xs text-slate-400">
              Web views run with <code className="text-slate-200">sandbox: true</code>, <code className="text-slate-200">contextIsolation: true</code>, and <code className="text-slate-200">nodeIntegration: false</code>.
              Websites have zero access to Node.js, Electron APIs, or the filesystem.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
              Narrow IPC Bridge (Preload)
            </div>
            <p className="text-xs text-slate-400">
              Only the trusted internal toolbar view receives the <code className="text-slate-200">window.aeroBrowserApi</code> preload bridge.
              External sites never receive IPC handlers.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              Window Open & Popup Protection
            </div>
            <p className="text-xs text-slate-400">
              <code className="text-slate-200">setWindowOpenHandler</code> intercepts <code className="text-slate-200">window.open</code> and <code className="text-slate-200">target=&quot;_blank&quot;</code>, creating an isolated browser tab instead of an arbitrary unmanaged window.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-400"></span>
              Single Instance Lock
            </div>
            <p className="text-xs text-slate-400">
              <code className="text-slate-200">app.requestSingleInstanceLock()</code> ensures only one instance can write to disk, preventing race conditions from corrupting the session.
            </p>
          </div>
        </div>
      </div>

      {/* Known Limitations: Deliverable 9 */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-950 border border-amber-800/60 flex items-center justify-center text-amber-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Known Limitations & Transparent Boundaries</h3>
            <p className="text-xs text-slate-400">Honest disclosure of inherent desktop runtime characteristics</p>
          </div>
        </div>

        <div className="space-y-3 text-xs text-slate-400">
          <div className="flex gap-2.5">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5"></div>
            <p>
              <strong className="text-slate-200">DRM / Protected Content (Widevine):</strong> Proprietary video streaming services (e.g. Netflix, Spotify web player) require proprietary Widevine CDM binaries which cannot be legally redistributed without Google licensing agreements.
            </p>
          </div>
          <div className="flex gap-2.5">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5"></div>
            <p>
              <strong className="text-slate-200">Google Account Sign-In:</strong> Google restricts OAuth login on embedded Chromium user agents (&quot;This browser or app may not be secure&quot;). Standard websites work normally, but Google-specific account logins may require standard user-agent spoofing or external OAuth flows.
            </p>
          </div>
          <div className="flex gap-2.5">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5"></div>
            <p>
              <strong className="text-slate-200">Chrome Web Store Extensions:</strong> Electron does not bundle the full Chrome Extension ecosystem (Manifest V3 extension store APIs).
            </p>
          </div>
          <div className="flex gap-2.5">
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5"></div>
            <p>
              <strong className="text-slate-200">Ongoing Chromium Hardening:</strong> Mature mainstream browsers (Chrome, Edge) deploy rapid 2-week zero-day updates. As a personal browser project, updating Electron versions regularly is required to maintain upstream security patches.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
