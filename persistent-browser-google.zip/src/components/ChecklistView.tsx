import React, { useState } from 'react';
import { CheckSquare, Square, CheckCircle2, ListChecks, PlayCircle } from 'lucide-react';

interface ChecklistItem {
  id: string;
  title: string;
  steps: string[];
  expected: string;
  scenarioType: 'Core Restoration' | 'Navigation' | 'Resilience' | 'Security';
}

const CHECKLIST: ChecklistItem[] = [
  {
    id: 'sc-1',
    scenarioType: 'Core Restoration',
    title: 'Multiple Tabs & Active Tab Restoration',
    steps: [
      'Launch AeroChromium with `npm run electron:start` or the Windows executable.',
      'Open Tab 1: https://en.wikipedia.org',
      'Open Tab 2: https://github.com',
      'Open Tab 3: https://news.ycombinator.com',
      'Click on Tab 2 (GitHub) so it is the active tab.',
      'Completely exit the browser using the titlebar close button (or Alt+F4).',
      'Reopen the browser.',
    ],
    expected: 'All 3 tabs return in exact order (Wikipedia, GitHub, Hacker News) and Tab 2 (GitHub) is selected and loaded.',
  },
  {
    id: 'sc-2',
    scenarioType: 'Navigation',
    title: 'In-Page & Deep Link Navigation Persistence',
    steps: [
      'On GitHub or Wikipedia, click a link inside the page to navigate to a subpage.',
      'Observe the address bar updates to the deep URL.',
      'Close the browser.',
      'Reopen the browser.',
    ],
    expected: 'The tab restores directly to the deep link URL rather than the root homepage.',
  },
  {
    id: 'sc-3',
    scenarioType: 'Core Restoration',
    title: 'Intentionally Closed Tabs Stay Closed',
    steps: [
      'Open 4 tabs.',
      'Click the "X" button on Tab 3 to close it.',
      'Restart the browser.',
    ],
    expected: 'The closed tab does NOT return. Only the remaining 3 tabs return in correct order.',
  },
  {
    id: 'sc-4',
    scenarioType: 'Core Restoration',
    title: 'Repeated Open & Close Integrity',
    steps: [
      'Open 3 tabs.',
      'Close and restart the browser 3 times consecutively without making changes.',
    ],
    expected: 'Tabs are neither duplicated nor lost. Session file maintains clean integrity.',
  },
  {
    id: 'sc-5',
    scenarioType: 'Resilience',
    title: 'Hard Process Kill / Crash Recovery',
    steps: [
      'Open 3 different tabs and switch active tab.',
      'Wait 500ms for debounced atomic write.',
      'Open Windows Task Manager, find AeroChromium, and click "End Task" (or `taskkill /F /IM AeroChromium.exe`).',
      'Relaunch AeroChromium.',
    ],
    expected: 'All tabs restore because periodic saves flush atomically to disk during runtime, not just on clean exit.',
  },
  {
    id: 'sc-6',
    scenarioType: 'Resilience',
    title: 'Corrupted Primary Session Recovery (.bak Fallback)',
    steps: [
      'Navigate to `%APPDATA%\\AeroChromium`.',
      'Open `aero-session-v1.json` in Notepad, delete half the text, save invalid corrupted JSON.',
      'Launch AeroChromium.',
    ],
    expected: 'Browser catches JSON parse failure, automatically reads `aero-session-v1.json.bak`, restores previous session, and repairs primary file.',
  },
  {
    id: 'sc-7',
    scenarioType: 'Resilience',
    title: 'Shutdown Destruction Overwrite Protection',
    steps: [
      'Have 5 tabs open.',
      'Trigger application close.',
      'Inspect `%APPDATA%\\AeroChromium\\aero-session-v1.json` before relaunching.',
    ],
    expected: 'File contains all 5 tabs. The destruction of WebContentsViews during quit did not save an empty array of 0 tabs.',
  },
  {
    id: 'sc-8',
    scenarioType: 'Navigation',
    title: 'Persistent Cookies & Website Login Retention',
    steps: [
      'Log into an ordinary account or visit a site that sets a cookie/localStorage.',
      'Completely restart AeroChromium.',
      'Revisit the site.',
    ],
    expected: 'User remains logged in via the persistent partition `persist:aero-chromium-profile`.',
  },
  {
    id: 'sc-9',
    scenarioType: 'Security',
    title: 'New-Window Links Handled in Tabs Safely',
    steps: [
      'Visit a webpage containing a link with `target="_blank"` or `window.open`.',
      'Click the link.',
    ],
    expected: 'Link opens smoothly inside a new AeroChromium tab without granting untrusted web code node integration or popup escapes.',
  },
  {
    id: 'sc-10',
    scenarioType: 'Core Restoration',
    title: 'Reopen Closed Tab with Keyboard Shortcut (Ctrl+Shift+T)',
    steps: [
      'Accidentally close an important tab with Ctrl+W or close button.',
      'Press Ctrl+Shift+T (or click the curved arrow icon).',
    ],
    expected: 'The closed tab instantly resurrects with its previous URL and title.',
  },
];

export const ChecklistView: React.FC = () => {
  const [checkedItems, setCheckedItems] = useState<Record<string, boolean>>({});

  const toggleCheck = (id: string) => {
    setCheckedItems((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const completedCount = Object.values(checkedItems).filter(Boolean).length;

  return (
    <div className="space-y-6">
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ListChecks className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">Manual End-to-End Acceptance Test Checklist</h3>
            <span className="text-xs bg-cyan-950 text-cyan-300 font-bold px-2.5 py-0.5 rounded-full border border-cyan-800/60">
              {completedCount}/{CHECKLIST.length} Verified
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Complete verification guide for testing real Windows desktop behavior and edge cases.
          </p>
        </div>

        <button
          onClick={() => {
            const allChecked: Record<string, boolean> = {};
            CHECKLIST.forEach((c) => (allChecked[c.id] = true));
            setCheckedItems(allChecked);
          }}
          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 transition"
        >
          Mark All As Verified
        </button>
      </div>

      <div className="space-y-4">
        {CHECKLIST.map((item, idx) => {
          const isDone = !!checkedItems[item.id];
          return (
            <div
              key={item.id}
              onClick={() => toggleCheck(item.id)}
              className={`border rounded-xl p-4 cursor-pointer transition ${
                isDone
                  ? 'bg-slate-900/40 border-emerald-900/50'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-start gap-3">
                <button
                  type="button"
                  className="mt-0.5 text-slate-400 hover:text-white transition shrink-0"
                >
                  {isDone ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  ) : (
                    <Square className="w-5 h-5 text-slate-600" />
                  )}
                </button>

                <div className="flex-1 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="text-sm font-bold text-white font-sans">
                      {idx + 1}. {item.title}
                    </span>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                      {item.scenarioType}
                    </span>
                  </div>

                  {/* Steps */}
                  <div className="text-xs text-slate-300 space-y-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      Test Procedure:
                    </span>
                    <ol className="list-decimal list-inside space-y-0.5 text-slate-400">
                      {item.steps.map((step, sIdx) => (
                        <li key={sIdx}>{step}</li>
                      ))}
                    </ol>
                  </div>

                  {/* Expected */}
                  <div className="p-2.5 bg-slate-950/70 rounded-lg border border-slate-800/80 text-xs text-slate-300">
                    <strong className="text-cyan-400">Expected Result: </strong>
                    {item.expected}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
