import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  Plus,
  X,
  Lock,
  Globe,
  RotateCcw,
  AlertTriangle,
  FileText,
  Activity,
  Power,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { SimulatedDiskSessionManager, PersistedTab } from '../lib/sessionEngine';

const PRESET_SITES = [
  { url: 'https://en.wikipedia.org', title: 'Wikipedia, the free encyclopedia', icon: 'W' },
  { url: 'https://github.com', title: 'GitHub: Let’s build from here', icon: 'GH' },
  { url: 'https://news.ycombinator.com', title: 'Hacker News', icon: 'Y' },
  { url: 'https://www.reddit.com', title: 'Reddit - Dive into anything', icon: 'R' },
  { url: 'https://duckduckgo.com', title: 'DuckDuckGo — Privacy, simplified.', icon: 'DDG' },
];

export const BrowserSimulator: React.FC = () => {
  const [manager] = useState(() => new SimulatedDiskSessionManager());
  const [tabs, setTabs] = useState<PersistedTab[]>([]);
  const [activeTabId, setActiveTabId] = useState<string>('');
  const [inputUrl, setInputUrl] = useState<string>('');
  const [isCrashed, setIsCrashed] = useState<boolean>(false);
  const [logs, setLogs] = useState(manager.operationLogs);
  const [diskFiles, setDiskFiles] = useState(manager.getRawFiles());
  const [showDiskViewer, setShowDiskViewer] = useState<boolean>(false);

  // Initialize or restore session
  const bootBrowser = () => {
    setIsCrashed(false);
    manager.resetShutdown();
    const session = manager.loadSession();
    setTabs(session.tabs);
    setActiveTabId(session.activeTabId);
    const active = session.tabs.find((t) => t.id === session.activeTabId) || session.tabs[0];
    setInputUrl(active?.url === 'browser://newtab' ? '' : active?.url || '');
    refreshDiskState();
  };

  useEffect(() => {
    bootBrowser();
  }, []);

  const refreshDiskState = () => {
    setLogs([...manager.operationLogs]);
    setDiskFiles(manager.getRawFiles());
  };

  // Add a new tab
  const handleNewTab = (presetUrl?: string, presetTitle?: string) => {
    const newId = `tab-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const url = presetUrl || 'browser://newtab';
    const title = presetTitle || (url === 'browser://newtab' ? 'New Tab' : url);
    const newTab: PersistedTab = {
      id: newId,
      url,
      title,
      lastAccessed: Date.now(),
    };

    const updatedTabs = [...tabs, newTab];
    setTabs(updatedTabs);
    setActiveTabId(newId);
    setInputUrl(url === 'browser://newtab' ? '' : url);

    manager.saveSessionSync(updatedTabs, newId);
    refreshDiskState();
  };

  // Switch active tab
  const handleSelectTab = (tabId: string) => {
    setActiveTabId(tabId);
    const selected = tabs.find((t) => t.id === tabId);
    if (selected) {
      setInputUrl(selected.url === 'browser://newtab' ? '' : selected.url);
      manager.saveSessionSync(tabs, tabId);
      refreshDiskState();
    }
  };

  // Close tab
  const handleCloseTab = (tabId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const target = tabs.find((t) => t.id === tabId);
    if (target) {
      manager.recordClosedTab({
        url: target.url,
        title: target.title,
      });
    }

    const updated = tabs.filter((t) => t.id !== tabId);
    if (updated.length === 0) {
      // Re-create default new tab if all tabs closed
      const defId = `tab-${Date.now()}`;
      const defTab: PersistedTab = {
        id: defId,
        url: 'browser://newtab',
        title: 'New Tab',
        lastAccessed: Date.now(),
      };
      setTabs([defTab]);
      setActiveTabId(defId);
      setInputUrl('');
      manager.saveSessionSync([defTab], defId);
    } else {
      let nextActive = activeTabId;
      if (activeTabId === tabId) {
        const closedIdx = tabs.findIndex((t) => t.id === tabId);
        const nextIdx = Math.min(closedIdx, updated.length - 1);
        nextActive = updated[nextIdx].id;
      }
      setTabs(updated);
      setActiveTabId(nextActive);
      const nextTab = updated.find((t) => t.id === nextActive);
      setInputUrl(nextTab?.url === 'browser://newtab' ? '' : nextTab?.url || '');
      manager.saveSessionSync(updated, nextActive);
    }
    refreshDiskState();
  };

  // Reopen recently closed tab (Ctrl+Shift+T)
  const handleReopenClosed = () => {
    const closed = manager.popRecentlyClosedTab();
    if (closed) {
      handleNewTab(closed.url, closed.title);
    }
  };

  // Navigate active tab
  const handleNavigate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;

    let targetUrl = inputUrl.trim();
    let title = targetUrl;

    if (!targetUrl.startsWith('http://') && !targetUrl.startsWith('https://')) {
      if (targetUrl.includes('.')) {
        targetUrl = `https://${targetUrl}`;
      } else {
        targetUrl = `https://www.google.com/search?q=${encodeURIComponent(targetUrl)}`;
        title = `Google Search: ${inputUrl}`;
      }
    }

    const updated = tabs.map((t) => {
      if (t.id === activeTabId) {
        return { ...t, url: targetUrl, title };
      }
      return t;
    });

    setTabs(updated);
    setInputUrl(targetUrl);
    manager.saveSessionSync(updated, activeTabId);
    refreshDiskState();
  };

  // Simulate Force-Quit / Power Outage / Crash
  const handleSimulateCrash = () => {
    setIsCrashed(true);
    refreshDiskState();
  };

  // Simulate Clean Shutdown & Restart
  const handleCleanRestart = () => {
    manager.prepareForShutdown();
    refreshDiskState();
    setTimeout(() => {
      bootBrowser();
    }, 400);
  };

  // Simulate Primary File Corruption
  const handleCorruptPrimary = () => {
    manager.corruptPrimaryFile();
    refreshDiskState();
  };

  const activeTab = tabs.find((t) => t.id === activeTabId) || tabs[0];

  return (
    <div className="flex flex-col gap-6">
      {/* Test Controls Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 shadow-lg">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></div>
          <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider">
            Live Session Restoration Playground
          </span>
          <span className="text-xs text-slate-400 ml-2 border-l border-slate-700 pl-3 hidden sm:inline">
            Verify Opera GX behavior: tabs, order, active tab, and backup recovery
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleCleanRestart}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded-lg border border-slate-700 flex items-center gap-1.5 transition"
            title="Clean quit and restart simulating application exit"
          >
            <Power className="w-3.5 h-3.5 text-emerald-400" />
            Normal Restart
          </button>

          <button
            onClick={handleSimulateCrash}
            className="px-3 py-1.5 bg-red-950/60 hover:bg-red-900/60 text-red-200 text-xs font-medium rounded-lg border border-red-800/80 flex items-center gap-1.5 transition"
            title="Simulate sudden process kill / power loss"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
            Simulate Crash
          </button>

          <button
            onClick={handleCorruptPrimary}
            className="px-3 py-1.5 bg-amber-950/60 hover:bg-amber-900/60 text-amber-200 text-xs font-medium rounded-lg border border-amber-800/80 flex items-center gap-1.5 transition"
            title="Inject malformed bytes into primary session file"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Corrupt Primary .json
          </button>

          <button
            onClick={() => setShowDiskViewer(!showDiskViewer)}
            className="px-3 py-1.5 bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-200 text-xs font-medium rounded-lg border border-cyan-800/80 flex items-center gap-1.5 transition"
          >
            <FileText className="w-3.5 h-3.5 text-cyan-400" />
            {showDiskViewer ? 'Hide Disk Files' : 'Inspect Disk Files'}
          </button>
        </div>
      </div>

      {/* Main Browser Window Frame */}
      {isCrashed ? (
        <div className="bg-slate-950 border-2 border-dashed border-red-800/80 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 min-h-[460px] shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-red-900/30 border border-red-700 flex items-center justify-center text-red-400">
            <Power className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-slate-100">Browser Process Terminated</h3>
            <p className="text-sm text-slate-400 max-w-md mt-1">
              The browser was force-closed or experienced sudden termination. In a standard browser without Opera GX session saving, tabs would be permanently lost.
            </p>
          </div>
          <button
            onClick={bootBrowser}
            className="mt-2 px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm rounded-xl flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition"
          >
            <RotateCcw className="w-4 h-4" />
            Reopen Browser (Test Session Recovery)
          </button>
        </div>
      ) : (
        <div className="bg-[#0b0c10] border border-slate-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col min-h-[520px]">
          {/* Top Row: Opera GX Tab Strip */}
          <div className="bg-[#0b0c10] px-3 pt-2 flex items-center gap-1 border-b border-slate-800/60 select-none">
            {/* Compass Logo */}
            <div className="w-7 h-7 flex items-center justify-center text-cyan-400 mr-1" title="AeroChromium Personal Browser">
              <div className="w-5 h-5 rounded-full border border-cyan-400 flex items-center justify-center">
                <div className="w-2 h-2 bg-cyan-400 rounded-full animate-ping"></div>
              </div>
            </div>

            {/* Scrollable Tabs */}
            <div className="flex items-center gap-1 overflow-x-auto flex-1 no-scrollbar py-0.5">
              {tabs.map((tab, idx) => {
                const isActive = tab.id === activeTabId;
                return (
                  <div
                    key={tab.id}
                    onClick={() => handleSelectTab(tab.id)}
                    className={`group relative flex items-center gap-2 px-3 py-1.5 rounded-t-lg text-xs cursor-pointer min-w-[130px] max-w-[210px] transition-all ${
                      isActive
                        ? 'bg-[#151821] text-slate-100 font-medium shadow-md border-t-2 border-cyan-400'
                        : 'bg-[#101217] text-slate-400 hover:bg-[#14161f] hover:text-slate-300'
                    }`}
                  >
                    <span className="w-3.5 h-3.5 flex items-center justify-center text-[10px] font-bold text-cyan-400/80">
                      {idx + 1}
                    </span>
                    <span className="truncate flex-1 font-sans">{tab.title || 'New Tab'}</span>
                    <button
                      onClick={(e) => handleCloseTab(tab.id, e)}
                      className="opacity-50 hover:opacity-100 p-0.5 rounded hover:bg-red-500/20 hover:text-red-400 transition"
                      title="Close tab (Ctrl+W)"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
            </div>

            {/* New Tab Button */}
            <button
              onClick={() => handleNewTab()}
              className="p-1.5 text-slate-400 hover:text-cyan-400 hover:bg-slate-800/60 rounded-md transition ml-1"
              title="New Tab (Ctrl+T)"
            >
              <Plus className="w-4 h-4" />
            </button>

            {/* Window Controls (Cosmetic Representation) */}
            <div className="flex items-center gap-2 pl-3 ml-auto text-slate-500">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-slate-700"></span>
            </div>
          </div>

          {/* Row 2: Omnibox & Navigation Bar */}
          <div className="bg-[#151821] px-4 py-2 flex items-center gap-2 border-b border-slate-800">
            <button
              className="p-1.5 text-slate-500 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800 transition"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <button
              className="p-1.5 text-slate-500 hover:text-slate-200 disabled:opacity-30 rounded hover:bg-slate-800 transition"
              title="Forward"
            >
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => refreshDiskState()}
              className="p-1.5 text-slate-400 hover:text-cyan-400 rounded hover:bg-slate-800 transition"
              title="Reload (Ctrl+R)"
            >
              <RotateCw className="w-4 h-4" />
            </button>

            {/* Omnibox input */}
            <form onSubmit={handleNavigate} className="flex-1 flex items-center gap-2 bg-[#0c0d11] border border-slate-800 focus-within:border-cyan-500 focus-within:shadow-[0_0_12px_rgba(0,243,255,0.2)] rounded-lg px-3 py-1.5 transition">
              {inputUrl.startsWith('https://') ? (
                <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              ) : (
                <Globe className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              )}
              <input
                type="text"
                value={inputUrl}
                onChange={(e) => setInputUrl(e.target.value)}
                placeholder="Search with Google or enter web address..."
                className="w-full bg-transparent text-xs text-slate-200 outline-none placeholder:text-slate-600 font-sans"
              />
              <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-cyan-950/80 border border-cyan-800/60 text-[10px] text-cyan-300 font-semibold shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                AUTO-SAVED
              </div>
            </form>

            {/* Reopen Closed Tab */}
            <button
              onClick={handleReopenClosed}
              className="p-1.5 text-slate-400 hover:text-cyan-400 rounded hover:bg-slate-800 transition relative"
              title="Reopen recently closed tab (Ctrl+Shift+T)"
            >
              <RotateCcw className="w-4 h-4" />
              {manager.getClosedTabsCount() > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-cyan-500 text-slate-950 rounded-full text-[9px] font-bold flex items-center justify-center">
                  {manager.getClosedTabsCount()}
                </span>
              )}
            </button>
          </div>

          {/* WebContentsView Content Area */}
          <div className="flex-1 bg-[#090a0d] p-6 flex flex-col items-center justify-center relative overflow-hidden">
            {activeTab?.url === 'browser://newtab' ? (
              <div className="w-full max-w-xl flex flex-col items-center gap-6 text-center z-10">
                <div className="space-y-1">
                  <h2 className="text-4xl font-light tracking-tight text-white font-mono">
                    {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </h2>
                  <p className="text-xs uppercase tracking-widest text-slate-500">
                    AeroChromium Desktop Core
                  </p>
                </div>

                <div className="w-full">
                  <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider font-semibold">
                    Quick Speed Dial
                  </p>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                    {PRESET_SITES.map((site) => (
                      <button
                        key={site.url}
                        onClick={() => {
                          const updated = tabs.map((t) =>
                            t.id === activeTabId ? { ...t, url: site.url, title: site.title } : t
                          );
                          setTabs(updated);
                          setInputUrl(site.url);
                          manager.saveSessionSync(updated, activeTabId);
                          refreshDiskState();
                        }}
                        className="bg-slate-900/80 hover:bg-slate-800/90 border border-slate-800 hover:border-cyan-500/40 rounded-xl p-3 flex flex-col items-center gap-2 transition group shadow-sm"
                      >
                        <div className="w-9 h-9 rounded-lg bg-slate-800 group-hover:bg-cyan-950 flex items-center justify-center text-xs font-bold text-cyan-400 transition">
                          {site.icon}
                        </div>
                        <span className="text-[11px] text-slate-300 truncate w-full">
                          {site.title.split(' ')[0]}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full max-w-2xl bg-slate-900/70 border border-slate-800 rounded-xl p-6 text-left space-y-4 shadow-xl z-10">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span className="text-xs font-semibold text-slate-200">Active WebContentsView</span>
                  </div>
                  <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/50">
                    Partition: persist:aero-chromium-profile
                  </span>
                </div>

                <div>
                  <h4 className="text-lg font-bold text-white">{activeTab?.title}</h4>
                  <p className="text-xs font-mono text-slate-400 break-all mt-1">{activeTab?.url}</p>
                </div>

                <div className="p-3 bg-slate-950/80 rounded-lg border border-slate-800 text-xs text-slate-300 space-y-1">
                  <p className="text-slate-400">
                    <strong className="text-slate-200">Session State:</strong> Commits on main-frame navigation & SPA route changes.
                  </p>
                  <p className="text-slate-400">
                    <strong className="text-slate-200">Website Data:</strong> Cookies, LocalStorage, IndexedDB, and logins persist across app reboots via Chromium partition.
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      // Navigate inside site
                      const deepUrl = `${activeTab?.url}/docs/overview`;
                      const updated = tabs.map((t) =>
                        t.id === activeTabId ? { ...t, url: deepUrl, title: `${activeTab.title} - Docs` } : t
                      );
                      setTabs(updated);
                      setInputUrl(deepUrl);
                      manager.saveSessionSync(updated, activeTabId);
                      refreshDiskState();
                    }}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg border border-slate-700 transition"
                  >
                    Click Deep Link Inside Site
                  </button>

                  <button
                    onClick={() => handleNewTab()}
                    className="px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-200 text-xs rounded-lg border border-cyan-800 transition"
                  >
                    Open New Window Link as Tab
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Disk Files & Real-time Persistence Inspector */}
      {showDiskViewer && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* File Contents */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
                <FileText className="w-4 h-4" />
                <span>%APPDATA%/AeroChromium/aero-session-v1.json</span>
              </div>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                Active Primary
              </span>
            </div>
            <pre className="bg-slate-950 p-3 rounded-lg text-[11px] font-mono text-slate-300 max-h-56 overflow-auto border border-slate-800">
              {diskFiles.primary || '// Primary file empty'}
            </pre>

            <div className="flex items-center justify-between border-b border-slate-800 pt-2 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <FileText className="w-4 h-4" />
                <span>aero-session-v1.json.bak (Last-Known-Good)</span>
              </div>
              <span className="text-[10px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40">
                Rotated Backup
              </span>
            </div>
            <pre className="bg-slate-950 p-3 rounded-lg text-[11px] font-mono text-slate-400 max-h-36 overflow-auto border border-slate-800">
              {diskFiles.backup || '// Backup file not yet created'}
            </pre>
          </div>

          {/* Live Disk Operation Logs */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Session Engine Disk Operations</span>
              </div>
              <span className="text-[10px] text-slate-400 font-mono">
                {logs.length} operations recorded
              </span>
            </div>
            <div className="bg-slate-950 p-3 rounded-lg flex-1 max-h-96 overflow-auto space-y-2 border border-slate-800">
              {logs.map((log, idx) => (
                <div key={idx} className="text-[11px] font-mono flex items-start gap-2">
                  <span className="text-slate-500 shrink-0">{log.time}</span>
                  <span
                    className={`font-semibold shrink-0 ${
                      log.type === 'success'
                        ? 'text-emerald-400'
                        : log.type === 'warn'
                        ? 'text-amber-400'
                        : log.type === 'error'
                        ? 'text-red-400'
                        : 'text-cyan-400'
                    }`}
                  >
                    [{log.action}]
                  </span>
                  <span className="text-slate-300 break-all">{log.details}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
