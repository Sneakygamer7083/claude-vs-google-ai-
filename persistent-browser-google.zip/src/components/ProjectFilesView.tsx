import React, { useState } from 'react';
import { FolderTree, Terminal, Copy, Check, FileCode, Package, Play, Cpu } from 'lucide-react';

export const ProjectFilesView: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="space-y-8 text-slate-300">
      {/* Windows Quickstart Commands */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Windows Run & Build Commands</h3>
            <p className="text-xs text-slate-400">Exact step-by-step commands for running and compiling on Windows 10/11</p>
          </div>
        </div>

        <div className="space-y-3 pt-2">
          {/* Step 1: Install */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-cyan-400 uppercase tracking-wider block">
                1. Install Project Dependencies
              </span>
              <code className="text-xs font-mono text-slate-200 block">npm install</code>
            </div>
            <button
              onClick={() => copyToClipboard('npm install', 'cmd-install')}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
              title="Copy Command"
            >
              {copiedCmd === 'cmd-install' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Step 2: Run Automated Tests */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block">
                2. Run Automated Session Tests (14 Tests)
              </span>
              <code className="text-xs font-mono text-slate-200 block">npm test</code>
            </div>
            <button
              onClick={() => copyToClipboard('npm test', 'cmd-test')}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
              title="Copy Command"
            >
              {copiedCmd === 'cmd-test' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Step 3: Run Desktop App */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider block">
                3. Launch AeroChromium in Development Mode
              </span>
              <code className="text-xs font-mono text-slate-200 block">npm run electron:start</code>
            </div>
            <button
              onClick={() => copyToClipboard('npm run electron:start', 'cmd-start')}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
              title="Copy Command"
            >
              {copiedCmd === 'cmd-start' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          {/* Step 4: Package Windows Executable */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-amber-400 uppercase tracking-wider block">
                4. Build Standalone Windows Executable (.exe & NSIS Installer)
              </span>
              <code className="text-xs font-mono text-slate-200 block">npm run electron:dist:win</code>
              <p className="text-[11px] text-slate-500">
                Produces standalone executable in <code className="text-slate-400">dist-win/AeroChromium 0.0.0.exe</code>
              </p>
            </div>
            <button
              onClick={() => copyToClipboard('npm run electron:dist:win', 'cmd-build')}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"
              title="Copy Command"
            >
              {copiedCmd === 'cmd-build' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Complete Project Directory Tree: Deliverable 2 */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-950 border border-cyan-800/60 flex items-center justify-center text-cyan-400">
            <FolderTree className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Complete Project File Tree</h3>
            <p className="text-xs text-slate-400">Modular structure separating main process, renderer UI, and test suites</p>
          </div>
        </div>

        <pre className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs font-mono text-slate-300 overflow-x-auto leading-relaxed">
{`AeroChromium/
├── electron/
│   ├── main.ts                   # Main process: single instance lock, BaseWindow, WebContentsViews, shortcuts
│   ├── tabManager.ts             # Tab lifecycle, real WebContentsView bindings, persistent partition session
│   ├── sessionManager.ts         # Opera GX persistence engine: atomic writes, backup rotation, corruption recovery
│   ├── preload.ts                # Context-isolated IPC bridge strictly exposed to trusted toolbar UI
│   ├── types.ts                  # TypeScript schemas for tabs, session JSON format, IPC channels
│   ├── urlUtils.ts               # Protocol whitelist, address bar search query parser, URL sanitizer
│   └── renderer/
│       ├── chrome.html           # Dark Opera GX toolbar markup (tab strip, omnibox, window controls)
│       ├── chrome.css            # Cyberpunk/dark theme styling, active tab neon glow, animations
│       ├── chrome.ts             # Client toolbar logic interacting with window.aeroBrowserApi
│       ├── newtab.html           # Internal start page markup (browser://newtab)
│       ├── newtab.css            # Start page stylesheet, speed dials, digital clock
│       └── newtab.ts             # Live clock tick and search submission handler
├── test/
│   ├── sessionManager.test.ts    # 8 automated unit tests for atomic writes, recovery, order preservation
│   └── urlUtils.test.ts          # 6 automated tests for protocol safety, search routing, injection defense
├── build-electron.mjs            # Production esbuild bundler compiling TS to electron-dist/
├── electron-builder.json         # Windows NSIS installer and portable .exe packaging config
├── package.json                  # Scripts (npm test, npm run electron:start, npm run electron:dist:win)
└── tsconfig.json                 # Strict TypeScript configuration`}
        </pre>
      </div>

      {/* Keyboard Shortcuts Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-950 border border-purple-800/60 flex items-center justify-center text-purple-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Integrated Keyboard Shortcuts</h3>
            <p className="text-xs text-slate-400">Full Windows native shortcut bindings</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">New Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + T</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Close Active Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + W</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Reopen Closed Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + Shift + T</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Focus Address Bar</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + L</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Next Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + Tab</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Previous Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + Shift + Tab</kbd>
          </div>
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
            <span className="text-xs text-slate-300">Reload Tab</span>
            <kbd className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs font-mono text-cyan-400">Ctrl + R / F5</kbd>
          </div>
        </div>
      </div>
    </div>
  );
};
