import React, { useState } from 'react';
import {
  Compass,
  PlaySquare,
  CheckCircle2,
  Layers,
  ListChecks,
  Terminal,
  ShieldCheck,
  ExternalLink,
  Download
} from 'lucide-react';
import { BrowserSimulator } from './components/BrowserSimulator';
import { TestRunnerView } from './components/TestRunnerView';
import { ArchitectureDoc } from './components/ArchitectureDoc';
import { ChecklistView } from './components/ChecklistView';
import { ProjectFilesView } from './components/ProjectFilesView';

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'tests' | 'architecture' | 'checklist' | 'commands'>('simulator');

  return (
    <div className="min-h-screen bg-[#07080a] text-slate-100 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header Bar */}
      <header className="bg-[#0b0d12] border-b border-slate-800/80 px-6 py-4 sticky top-0 z-50 backdrop-blur-md bg-opacity-90">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-[#0a0b0e] rounded-[10px] flex items-center justify-center">
                <Compass className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">AeroChromium</h1>
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-cyan-950/80 text-cyan-300 border border-cyan-800/60">
                  Electron v33 • Chromium 130
                </span>
                <span className="text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-800/60 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" />
                  14/14 Tests Passing
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Personal Chromium Desktop Web Browser with Opera GX Session Restoration
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeTab === 'simulator'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <PlaySquare className="w-3.5 h-3.5" />
              Live Simulator
            </button>
            <button
              onClick={() => setActiveTab('tests')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeTab === 'tests'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              Test Suite (14)
            </button>
            <button
              onClick={() => setActiveTab('architecture')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeTab === 'architecture'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              Architecture & Storage
            </button>
            <button
              onClick={() => setActiveTab('checklist')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeTab === 'checklist'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <ListChecks className="w-3.5 h-3.5" />
              E2E Checklist
            </button>
            <button
              onClick={() => setActiveTab('commands')}
              className={`px-3.5 py-1.5 rounded-lg font-medium transition flex items-center gap-1.5 ${
                activeTab === 'commands'
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Terminal className="w-3.5 h-3.5" />
              Run & Build Guide
            </button>
          </nav>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-7xl mx-auto w-full p-6 flex-1">
        {activeTab === 'simulator' && <BrowserSimulator />}
        {activeTab === 'tests' && <TestRunnerView />}
        {activeTab === 'architecture' && <ArchitectureDoc />}
        {activeTab === 'checklist' && <ChecklistView />}
        {activeTab === 'commands' && <ProjectFilesView />}
      </main>

      {/* Footer */}
      <footer className="bg-[#090a0d] border-t border-slate-800/80 px-6 py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            <span>AeroChromium v1.0 • Targeted for Windows 10/11 x64</span>
          </div>
          <div>
            <span>Desktop Binary: <code className="text-slate-400 font-mono">npm run electron:dist:win</code></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
