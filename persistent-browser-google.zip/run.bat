@echo off
setlocal enabledelayedexpansion
title AeroChromium Desktop Browser Launcher

echo ========================================================
echo         AeroChromium Desktop Browser for Windows
echo ========================================================
echo.

:: 1. Check if Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not found on your system!
    echo Please install Node.js (version 20 or higher) from:
    echo   https://nodejs.org/
    echo.
    echo After installing Node.js, run this batch file again.
    pause
    exit /b 1
)

echo [OK] Node.js is installed:
node -v
echo.

:: 2. Check if node_modules exists, install if missing
if not exist "node_modules\" (
    echo [SETUP] First-time setup: installing dependencies...
    echo Running "npm install"...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm install encountered an error.
        pause
        exit /b %errorlevel%
    )
    echo [OK] Dependencies installed successfully.
    echo.
)

:: 3. Build the Electron assets and launch the browser
echo [LAUNCH] Building Electron bundles and launching AeroChromium...
call npm run electron:start

if %errorlevel% neq 0 (
    echo.
    echo [NOTICE] Browser closed or exited with code %errorlevel%.
)

pause
