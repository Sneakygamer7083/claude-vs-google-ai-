/**
 * Automated Tests: Session Persistence Engine
 * Validates serialization, ordering, atomic writes, backup rotation,
 * corruption recovery, and shutdown overwrite protection.
 */

import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test, { beforeEach, describe } from 'node:test';
import {
  CURRENT_SESSION_VERSION,
  SESSION_BACKUP_NAME,
  SESSION_FILE_NAME,
  SessionManager,
} from '../electron/sessionManager.js';
import { PersistedTab } from '../electron/types.js';

describe('SessionManager Persistence Engine', () => {
  let tempDir: string;
  let sessionManager: SessionManager;

  beforeEach(() => {
    // Create an isolated temporary userData directory for each test run
    tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'aero-test-session-'));
    sessionManager = new SessionManager({
      userDataDir: tempDir,
      debounceMs: 50,
      onLog: () => {}, // silence during tests
    });
  });

  test('loadSession creates safe default session on fresh launch', () => {
    const session = sessionManager.loadSession();
    assert.equal(session.version, CURRENT_SESSION_VERSION);
    assert.equal(session.tabs.length, 1);
    assert.equal(session.tabs[0].url, 'browser://newtab');
    assert.equal(session.activeTabId, session.tabs[0].id);
  });

  test('saves and restores multiple tabs in order with active tab preserved', () => {
    sessionManager.setRestorationComplete(true);

    const tabs: PersistedTab[] = [
      { id: 'tab-1', url: 'https://en.wikipedia.org', title: 'Wikipedia', lastAccessed: 1000 },
      { id: 'tab-2', url: 'https://github.com', title: 'GitHub', lastAccessed: 2000 },
      { id: 'tab-3', url: 'https://news.ycombinator.com', title: 'Hacker News', lastAccessed: 1500 },
    ];

    // Select middle tab (tab-2)
    sessionManager.scheduleSave(tabs, 'tab-2', true);

    // Verify session file exists on disk
    const sessionPath = path.join(tempDir, SESSION_FILE_NAME);
    assert.ok(fs.existsSync(sessionPath), 'Session file should exist on disk');

    // Create a new instance simulating application restart
    const restartedManager = new SessionManager({ userDataDir: tempDir });
    const restored = restartedManager.loadSession();

    assert.equal(restored.tabs.length, 3);
    assert.equal(restored.tabs[0].id, 'tab-1');
    assert.equal(restored.tabs[1].id, 'tab-2');
    assert.equal(restored.tabs[2].id, 'tab-3');
    assert.equal(restored.activeTabId, 'tab-2', 'Middle tab should remain active');
    assert.equal(restored.tabs[1].url, 'https://github.com');
  });

  test('updates committed URL when navigation occurs', () => {
    sessionManager.setRestorationComplete(true);

    const initialTabs: PersistedTab[] = [
      { id: 'tab-1', url: 'https://example.com', title: 'Example', lastAccessed: Date.now() },
    ];
    sessionManager.scheduleSave(initialTabs, 'tab-1', true);

    // Simulate navigation link click
    const navigatedTabs: PersistedTab[] = [
      { id: 'tab-1', url: 'https://example.com/deep/page', title: 'Deep Page', lastAccessed: Date.now() },
    ];
    sessionManager.scheduleSave(navigatedTabs, 'tab-1', true);

    const reloaded = new SessionManager({ userDataDir: tempDir }).loadSession();
    assert.equal(reloaded.tabs[0].url, 'https://example.com/deep/page');
    assert.equal(reloaded.tabs[0].title, 'Deep Page');
  });

  test('creates backup file on subsequent writes for crash resilience', () => {
    sessionManager.setRestorationComplete(true);

    const firstTabs: PersistedTab[] = [
      { id: 't1', url: 'https://site-a.com', title: 'Site A', lastAccessed: 1 },
    ];
    sessionManager.scheduleSave(firstTabs, 't1', true);

    const backupPath = path.join(tempDir, SESSION_BACKUP_NAME);

    const secondTabs: PersistedTab[] = [
      { id: 't1', url: 'https://site-a.com', title: 'Site A', lastAccessed: 1 },
      { id: 't2', url: 'https://site-b.com', title: 'Site B', lastAccessed: 2 },
    ];
    sessionManager.scheduleSave(secondTabs, 't2', true);

    assert.ok(fs.existsSync(backupPath), 'Backup file should have been rotated');

    const backupContent = JSON.parse(fs.readFileSync(backupPath, 'utf-8'));
    assert.equal(backupContent.tabs.length, 1, 'Backup should contain prior valid state');
  });

  test('recovers gracefully from corrupted primary session file using backup', () => {
    sessionManager.setRestorationComplete(true);

    // 1. Establish valid session
    const validTabs: PersistedTab[] = [
      { id: 'alpha', url: 'https://alpha.org', title: 'Alpha', lastAccessed: 10 },
      { id: 'beta', url: 'https://beta.org', title: 'Beta', lastAccessed: 20 },
    ];
    sessionManager.scheduleSave(validTabs, 'beta', true);

    // Trigger backup rotation
    const updatedTabs: PersistedTab[] = [
      ...validTabs,
      { id: 'gamma', url: 'https://gamma.org', title: 'Gamma', lastAccessed: 30 },
    ];
    sessionManager.scheduleSave(updatedTabs, 'gamma', true);

    // 2. Deliberately corrupt primary session file (e.g. power outage mid-write)
    const primaryPath = path.join(tempDir, SESSION_FILE_NAME);
    fs.writeFileSync(primaryPath, '<<< CORRUPTED TRUNCATED JSON DATA { "version": 1, ...', 'utf-8');

    // 3. Restart application and load session
    const recoveryManager = new SessionManager({ userDataDir: tempDir });
    const recovered = recoveryManager.loadSession();

    // Verify recovery happened without crashing
    assert.ok(recovered.tabs.length >= 2, 'Should recover tabs from backup');
    assert.equal(recovered.tabs[0].id, 'alpha');
    assert.equal(recovered.tabs[1].id, 'beta');
  });

  test('falls back safely to default session when both primary and backup are unreadable', () => {
    const primaryPath = path.join(tempDir, SESSION_FILE_NAME);
    const backupPath = path.join(tempDir, SESSION_BACKUP_NAME);

    fs.writeFileSync(primaryPath, 'garbage primary', 'utf-8');
    fs.writeFileSync(backupPath, 'garbage backup', 'utf-8');

    const fallbackManager = new SessionManager({ userDataDir: tempDir });
    const fallback = fallbackManager.loadSession();

    assert.equal(fallback.version, CURRENT_SESSION_VERSION);
    assert.equal(fallback.tabs.length, 1);
    assert.equal(fallback.tabs[0].url, 'browser://newtab');
  });

  test('prevents shutdown-related tab destruction from overwriting session with 0 tabs', () => {
    sessionManager.setRestorationComplete(true);

    const tabs: PersistedTab[] = [
      { id: 't1', url: 'https://example.com', title: 'Example', lastAccessed: 100 },
      { id: 't2', url: 'https://wikipedia.org', title: 'Wiki', lastAccessed: 200 },
    ];
    sessionManager.scheduleSave(tabs, 't2', true);

    // App receives shutdown signal
    sessionManager.prepareForShutdown();

    // Browser view cleanup tries to schedule save with empty array
    sessionManager.scheduleSave([], '', true);

    // Load session again and verify original tabs were preserved
    const verifyManager = new SessionManager({ userDataDir: tempDir });
    const session = verifyManager.loadSession();

    assert.equal(session.tabs.length, 2, 'Shutdown cleanup must not overwrite session with 0 tabs');
    assert.equal(session.activeTabId, 't2');
  });

  test('tracks and pops recently closed tabs for Ctrl+Shift+T restoration', () => {
    sessionManager.recordClosedTab({
      url: 'https://news.ycombinator.com',
      title: 'Hacker News',
    });

    assert.equal(sessionManager.getClosedTabsCount(), 1);

    const popped = sessionManager.popRecentlyClosedTab();
    assert.ok(popped);
    assert.equal(popped?.url, 'https://news.ycombinator.com');
    assert.equal(popped?.title, 'Hacker News');
    assert.equal(sessionManager.getClosedTabsCount(), 0);
  });
});
