/**
 * Automated Tests: URL Normalization and Protocol Safety
 */

import assert from 'node:assert/strict';
import test, { describe } from 'node:test';
import {
  DEFAULT_SEARCH_ENGINE,
  INTERNAL_NEWTAB_URL,
  isAllowedProtocol,
  normalizeUserUrl,
  sanitizePersistedUrl,
} from '../electron/urlUtils.js';

describe('URL Utilities and Safety', () => {
  test('isAllowedProtocol allows legitimate web schemes and internal pages', () => {
    assert.equal(isAllowedProtocol('https://example.com'), true);
    assert.equal(isAllowedProtocol('http://localhost:3000'), true);
    assert.equal(isAllowedProtocol(INTERNAL_NEWTAB_URL), true);
  });

  test('isAllowedProtocol rejects dangerous or unauthorized schemes', () => {
    assert.equal(isAllowedProtocol('javascript:alert(1)'), false);
    assert.equal(isAllowedProtocol('file:///etc/passwd'), false);
    assert.equal(isAllowedProtocol('data:text/html,<h1>XSS</h1>'), false);
    assert.equal(isAllowedProtocol('vbscript:msgbox'), false);
    assert.equal(isAllowedProtocol(''), false);
  });

  test('normalizeUserUrl routes raw queries to search engine', () => {
    const query = 'best mechanical keyboards 2026';
    const normalized = normalizeUserUrl(query);
    assert.equal(normalized, `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(query)}`);
  });

  test('normalizeUserUrl formats domains without protocol to https://', () => {
    assert.equal(normalizeUserUrl('github.com'), 'https://github.com');
    assert.equal(normalizeUserUrl('en.wikipedia.org/wiki/Chromium'), 'https://en.wikipedia.org/wiki/Chromium');
    assert.equal(normalizeUserUrl('localhost:3000'), 'https://localhost:3000');
  });

  test('normalizeUserUrl neutralizes javascript: and file: injection attempts', () => {
    const malicious = 'javascript:document.cookie';
    const normalized = normalizeUserUrl(malicious);
    assert.ok(normalized.startsWith(DEFAULT_SEARCH_ENGINE));
  });

  test('sanitizePersistedUrl sanitizes persisted values safely', () => {
    assert.equal(sanitizePersistedUrl('https://example.com'), 'https://example.com');
    assert.equal(sanitizePersistedUrl(INTERNAL_NEWTAB_URL), INTERNAL_NEWTAB_URL);
    assert.equal(sanitizePersistedUrl('javascript:badCode()'), INTERNAL_NEWTAB_URL);
    assert.equal(sanitizePersistedUrl('file:///C:/Windows'), INTERNAL_NEWTAB_URL);
    assert.equal(sanitizePersistedUrl(null), INTERNAL_NEWTAB_URL);
  });
});
