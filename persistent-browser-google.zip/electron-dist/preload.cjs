var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// electron/preload.ts
var preload_exports = {};
module.exports = __toCommonJS(preload_exports);
var import_electron = require("electron");

// electron/types.ts
var IPC_CHANNELS = {
  UI_READY: "ui:ready",
  STATE_UPDATE: "browser:state-update",
  TAB_CREATE: "tab:create",
  TAB_CLOSE: "tab:close",
  TAB_SWITCH: "tab:switch",
  TAB_NAVIGATE: "tab:navigate",
  TAB_GO_BACK: "tab:go-back",
  TAB_GO_FORWARD: "tab:go-forward",
  TAB_RELOAD: "tab:reload",
  TAB_STOP: "tab:stop",
  TAB_REOPEN_CLOSED: "tab:reopen-closed",
  FOCUS_ADDRESS_BAR: "shortcut:focus-address-bar",
  WINDOW_MINIMIZE: "window:minimize",
  WINDOW_MAXIMIZE: "window:maximize",
  WINDOW_CLOSE: "window:close",
  GET_INITIAL_STATE: "browser:get-initial-state"
};

// electron/preload.ts
var api = {
  createTab: (url) => {
    import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_CREATE, typeof url === "string" ? url : void 0);
  },
  closeTab: (tabId) => {
    if (typeof tabId === "string" && tabId.trim()) {
      import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_CLOSE, tabId);
    }
  },
  switchTab: (tabId) => {
    if (typeof tabId === "string" && tabId.trim()) {
      import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_SWITCH, tabId);
    }
  },
  navigateTab: (url) => {
    if (typeof url === "string") {
      import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_NAVIGATE, url);
    }
  },
  goBack: () => import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_GO_BACK),
  goForward: () => import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_GO_FORWARD),
  reload: () => import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_RELOAD),
  stop: () => import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_STOP),
  reopenRecentlyClosedTab: () => import_electron.ipcRenderer.send(IPC_CHANNELS.TAB_REOPEN_CLOSED),
  minimizeWindow: () => import_electron.ipcRenderer.send(IPC_CHANNELS.WINDOW_MINIMIZE),
  maximizeWindow: () => import_electron.ipcRenderer.send(IPC_CHANNELS.WINDOW_MAXIMIZE),
  closeWindow: () => import_electron.ipcRenderer.send(IPC_CHANNELS.WINDOW_CLOSE),
  onStateUpdate: (callback) => {
    const handler = (_event, state) => {
      callback(state);
    };
    import_electron.ipcRenderer.on(IPC_CHANNELS.STATE_UPDATE, handler);
    return () => {
      import_electron.ipcRenderer.removeListener(IPC_CHANNELS.STATE_UPDATE, handler);
    };
  },
  onFocusAddressBar: (callback) => {
    const handler = () => callback();
    import_electron.ipcRenderer.on(IPC_CHANNELS.FOCUS_ADDRESS_BAR, handler);
    return () => {
      import_electron.ipcRenderer.removeListener(IPC_CHANNELS.FOCUS_ADDRESS_BAR, handler);
    };
  },
  notifyUiReady: () => {
    import_electron.ipcRenderer.send(IPC_CHANNELS.UI_READY);
  }
};
import_electron.contextBridge.exposeInMainWorld("aeroBrowserApi", api);
//# sourceMappingURL=preload.cjs.map
