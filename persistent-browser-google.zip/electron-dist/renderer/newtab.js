(() => {
  // electron/renderer/newtab.ts
  function updateClock() {
    const clockEl = document.getElementById("digital-clock");
    const dateEl = document.getElementById("date-display");
    if (!clockEl || !dateEl) return;
    const now = /* @__PURE__ */ new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    clockEl.textContent = `${hours}:${minutes}`;
    const options = {
      weekday: "long",
      month: "long",
      day: "numeric"
    };
    dateEl.textContent = now.toLocaleDateString(void 0, options);
  }
  function setupSearch() {
    const searchForm = document.getElementById("search-form");
    const searchInput = document.getElementById("search-input");
    if (!searchForm || !searchInput) return;
    searchForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const query = searchInput.value.trim();
      if (!query) return;
      if (query.startsWith("http://") || query.startsWith("https://")) {
        window.location.href = query;
        return;
      }
      const domainPattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
      if (domainPattern.test(query)) {
        window.location.href = `https://${query}`;
        return;
      }
      window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    });
  }
  window.addEventListener("DOMContentLoaded", () => {
    updateClock();
    setInterval(updateClock, 1e3);
    setupSearch();
  });
})();
//# sourceMappingURL=newtab.js.map
