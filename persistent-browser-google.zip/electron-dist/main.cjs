var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// electron/main.ts
var import_electron2 = require("electron");
var import_node_fs2 = __toESM(require("node:fs"), 1);
var import_node_path2 = __toESM(require("node:path"), 1);

// electron/sessionManager.ts
var import_node_fs = __toESM(require("node:fs"), 1);
var import_node_path = __toESM(require("node:path"), 1);

// electron/urlUtils.ts
var INTERNAL_NEWTAB_URL = "browser://newtab";
var DEFAULT_SEARCH_ENGINE = "https://www.google.com/search?q=";
function isAllowedProtocol(urlStr) {
  if (!urlStr || typeof urlStr !== "string") return false;
  const trimmed = urlStr.trim();
  if (trimmed === INTERNAL_NEWTAB_URL) return true;
  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === "http:" || parsed.protocol === "https:";
  } catch {
    return false;
  }
}
function normalizeUserUrl(input) {
  if (!input || typeof input !== "string") {
    return INTERNAL_NEWTAB_URL;
  }
  const trimmed = input.trim();
  if (!trimmed) {
    return INTERNAL_NEWTAB_URL;
  }
  if (trimmed === "browser://newtab" || trimmed === "about:blank" || trimmed.toLowerCase() === "newtab") {
    return INTERNAL_NEWTAB_URL;
  }
  const lower = trimmed.toLowerCase();
  if (lower.startsWith("javascript:") || lower.startsWith("file:") || lower.startsWith("data:") || lower.startsWith("vbscript:")) {
    return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
  }
  if (lower.startsWith("http://") || lower.startsWith("https://")) {
    try {
      new URL(trimmed);
      return trimmed;
    } catch {
      return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
    }
  }
  const hasWhitespace = /\s/.test(trimmed);
  const domainPattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
  const localhostPattern = /^localhost(:\d+)?(\/.*)?$/;
  const ipPattern = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?(\/.*)?$/;
  if (!hasWhitespace && (domainPattern.test(trimmed) || localhostPattern.test(trimmed) || ipPattern.test(trimmed))) {
    return `https://${trimmed}`;
  }
  return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
}
function sanitizePersistedUrl(url) {
  if (typeof url !== "string" || !url) {
    return INTERNAL_NEWTAB_URL;
  }
  const trimmed = url.trim();
  if (trimmed === INTERNAL_NEWTAB_URL) {
    return INTERNAL_NEWTAB_URL;
  }
  if (isAllowedProtocol(trimmed)) {
    return trimmed;
  }
  return INTERNAL_NEWTAB_URL;
}

// electron/sessionManager.ts
var CURRENT_SESSION_VERSION = 1;
var SESSION_FILE_NAME = "aero-session-v1.json";
var SESSION_BACKUP_NAME = "aero-session-v1.json.bak";
var SESSION_TEMP_NAME = "aero-session-v1.json.tmp";
var MAX_CLOSED_TABS_HISTORY = 30;
var SessionManager = class {
  constructor(options) {
    this.debounceTimer = null;
    // Protection flags
    this.isAppShuttingDown = false;
    this.isRestorationComplete = false;
    this.cachedSession = null;
    this.closedTabsHistory = [];
    this.userDataDir = options.userDataDir;
    this.debounceMs = options.debounceMs ?? 350;
    this.log = options.onLog ?? ((msg) => console.log(`[SessionManager] ${msg}`));
    try {
      if (!import_node_fs.default.existsSync(this.userDataDir)) {
        import_node_fs.default.mkdirSync(this.userDataDir, { recursive: true });
      }
    } catch (err) {
      console.error("[SessionManager] Failed to create userDataDir:", err);
    }
    this.sessionFilePath = import_node_path.default.join(this.userDataDir, SESSION_FILE_NAME);
    this.backupFilePath = import_node_path.default.join(this.userDataDir, SESSION_BACKUP_NAME);
    this.tempFilePath = import_node_path.default.join(this.userDataDir, SESSION_TEMP_NAME);
  }
  /**
   * Mark application as shutting down.
   * This immediately prevents any subsequent tab destruction callbacks
   * from overwriting the session file with an empty tab array.
   */
  prepareForShutdown() {
    this.isAppShuttingDown = true;
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
  }
  isShuttingDown() {
    return this.isAppShuttingDown;
  }
  setRestorationComplete(complete = true) {
    this.isRestorationComplete = complete;
  }
  /**
   * Records a user-closed tab into the recent closed stack for Ctrl+Shift+T.
   */
  recordClosedTab(tab) {
    if (this.isAppShuttingDown) return;
    const sanitizedUrl = sanitizePersistedUrl(tab.url);
    if (sanitizedUrl === INTERNAL_NEWTAB_URL && tab.title === "New Tab") {
      return;
    }
    this.closedTabsHistory.unshift({
      url: sanitizedUrl,
      title: tab.title || "Untitled",
      favicon: tab.favicon,
      closedAt: Date.now()
    });
    if (this.closedTabsHistory.length > MAX_CLOSED_TABS_HISTORY) {
      this.closedTabsHistory.pop();
    }
  }
  /**
   * Retrieves and pops the most recently closed tab for restoration.
   */
  popRecentlyClosedTab() {
    return this.closedTabsHistory.shift() ?? null;
  }
  getClosedTabsCount() {
    return this.closedTabsHistory.length;
  }
  /**
   * Loads the session from disk.
   * Order of recovery:
   * 1. Primary file (aero-session-v1.json)
   * 2. Backup file (aero-session-v1.json.bak)
   * 3. Safe fallback default (single New Tab)
   */
  loadSession() {
    this.log(`Loading session from: ${this.sessionFilePath}`);
    if (import_node_fs.default.existsSync(this.sessionFilePath)) {
      try {
        const raw = import_node_fs.default.readFileSync(this.sessionFilePath, "utf-8");
        const parsed = JSON.parse(raw);
        if (this.isValidSessionPayload(parsed)) {
          const sanitized = this.sanitizeSessionPayload(parsed);
          this.log(`Primary session loaded successfully with ${sanitized.tabs.length} tabs.`);
          this.cachedSession = sanitized;
          if (sanitized.closedTabs) {
            this.closedTabsHistory = [...sanitized.closedTabs];
          }
          return sanitized;
        } else {
          this.log(`Primary session payload was structurally invalid. Attempting backup...`);
        }
      } catch (err) {
        this.log(`Primary session file parse failed (${err}). Attempting backup...`);
      }
    } else {
      this.log(`No primary session file found. Checking backup...`);
    }
    if (import_node_fs.default.existsSync(this.backupFilePath)) {
      try {
        const rawBackup = import_node_fs.default.readFileSync(this.backupFilePath, "utf-8");
        const parsedBackup = JSON.parse(rawBackup);
        if (this.isValidSessionPayload(parsedBackup)) {
          const sanitizedBackup = this.sanitizeSessionPayload(parsedBackup);
          this.log(`Recovered session from backup with ${sanitizedBackup.tabs.length} tabs.`);
          this.cachedSession = sanitizedBackup;
          this.writeSessionAtomicSync(sanitizedBackup);
          return sanitizedBackup;
        }
      } catch (backupErr) {
        this.log(`Backup session parse failed (${backupErr}).`);
      }
    }
    this.log(`Creating fresh initial session.`);
    const fallback = this.createDefaultSession();
    this.cachedSession = fallback;
    return fallback;
  }
  /**
   * Schedule a debounced session write, or execute immediately.
   */
  scheduleSave(tabs, activeTabId, immediate = false) {
    if (!this.isRestorationComplete && !immediate) {
      this.log("Skipping save because session restoration is still in progress.");
      return;
    }
    if (this.isAppShuttingDown && !immediate) {
      this.log("Skipping debounced save during shutdown.");
      return;
    }
    if (!tabs || tabs.length === 0) {
      this.log("Refusing to persist an empty tab array. Preserving previous session.");
      return;
    }
    const sessionPayload = {
      version: CURRENT_SESSION_VERSION,
      lastSaved: (/* @__PURE__ */ new Date()).toISOString(),
      activeTabId: activeTabId || tabs[0].id,
      tabs: tabs.map((t) => ({
        id: t.id,
        url: sanitizePersistedUrl(t.url),
        title: t.title || "Untitled",
        favicon: t.favicon,
        lastAccessed: t.lastAccessed || Date.now()
      })),
      closedTabs: this.closedTabsHistory.slice(0, 15)
    };
    this.cachedSession = sessionPayload;
    if (immediate) {
      if (this.debounceTimer) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = null;
      }
      this.writeSessionAtomicSync(sessionPayload);
      return;
    }
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }
    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = null;
      this.writeSessionAtomicSync(sessionPayload);
    }, this.debounceMs);
  }
  /**
   * Flushes any pending writes synchronously to disk.
   * Called during application before-quit event.
   */
  flushSync() {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    if (this.cachedSession && this.cachedSession.tabs.length > 0) {
      this.log("Flushing session synchronously to disk on shutdown...");
      this.writeSessionAtomicSync(this.cachedSession);
    }
  }
  /**
   * Atomic file write strategy:
   * 1. If primary file exists and is valid, copy/rotate to .bak
   * 2. Write serialized JSON to .tmp file
   * 3. Flush OS buffer to disk via fsyncSync
   * 4. Rename .tmp over destination with Windows atomic replace fallback
   */
  writeSessionAtomicSync(data) {
    try {
      const serialized = JSON.stringify(data, null, 2);
      if (import_node_fs.default.existsSync(this.sessionFilePath)) {
        try {
          import_node_fs.default.copyFileSync(this.sessionFilePath, this.backupFilePath);
        } catch (copyErr) {
          this.log(`Backup copy notice: ${copyErr}`);
        }
      }
      const fd = import_node_fs.default.openSync(this.tempFilePath, "w");
      import_node_fs.default.writeSync(fd, serialized, 0, "utf-8");
      import_node_fs.default.fsyncSync(fd);
      import_node_fs.default.closeSync(fd);
      try {
        import_node_fs.default.renameSync(this.tempFilePath, this.sessionFilePath);
      } catch {
        if (import_node_fs.default.existsSync(this.sessionFilePath)) {
          import_node_fs.default.unlinkSync(this.sessionFilePath);
        }
        import_node_fs.default.renameSync(this.tempFilePath, this.sessionFilePath);
      }
      this.log(`Session saved atomically (${data.tabs.length} tabs, active: ${data.activeTabId}).`);
      return true;
    } catch (err) {
      console.error("[SessionManager] Critical error writing session atomically:", err);
      return false;
    } finally {
      if (import_node_fs.default.existsSync(this.tempFilePath)) {
        try {
          import_node_fs.default.unlinkSync(this.tempFilePath);
        } catch {
        }
      }
    }
  }
  /**
   * Validates structure of candidate session payload
   */
  isValidSessionPayload(obj) {
    if (!obj || typeof obj !== "object") return false;
    const candidate = obj;
    if (typeof candidate.version !== "number" || candidate.version !== CURRENT_SESSION_VERSION) {
      return false;
    }
    if (!Array.isArray(candidate.tabs) || candidate.tabs.length === 0) {
      return false;
    }
    if (typeof candidate.activeTabId !== "string" || !candidate.activeTabId) {
      return false;
    }
    for (const tab of candidate.tabs) {
      if (!tab || typeof tab !== "object") return false;
      const t = tab;
      if (typeof t.id !== "string" || typeof t.url !== "string") {
        return false;
      }
    }
    return true;
  }
  /**
   * Sanitizes candidate session payload by validating activeTabId exists
   * and sanitizing each URL against malicious protocol schemes.
   */
  sanitizeSessionPayload(data) {
    const sanitizedTabs = data.tabs.map((tab, idx) => ({
      id: tab.id || `tab-restored-${idx}-${Date.now()}`,
      url: sanitizePersistedUrl(tab.url),
      title: tab.title || "Untitled",
      favicon: tab.favicon,
      lastAccessed: typeof tab.lastAccessed === "number" ? tab.lastAccessed : Date.now()
    }));
    let activeId = data.activeTabId;
    if (!sanitizedTabs.some((t) => t.id === activeId)) {
      activeId = sanitizedTabs[0].id;
    }
    return {
      version: CURRENT_SESSION_VERSION,
      lastSaved: data.lastSaved || (/* @__PURE__ */ new Date()).toISOString(),
      activeTabId: activeId,
      tabs: sanitizedTabs,
      closedTabs: Array.isArray(data.closedTabs) ? data.closedTabs : []
    };
  }
  createDefaultSession() {
    const initialId = `tab-init-${Date.now()}`;
    return {
      version: CURRENT_SESSION_VERSION,
      lastSaved: (/* @__PURE__ */ new Date()).toISOString(),
      activeTabId: initialId,
      tabs: [
        {
          id: initialId,
          url: INTERNAL_NEWTAB_URL,
          title: "New Tab",
          lastAccessed: Date.now()
        }
      ],
      closedTabs: []
    };
  }
  getSessionPaths() {
    return {
      sessionFile: this.sessionFilePath,
      backupFile: this.backupFilePath,
      tempFile: this.tempFilePath,
      userDataDir: this.userDataDir
    };
  }
  getCachedSession() {
    return this.cachedSession;
  }
};

// electron/tabManager.ts
var import_electron = require("electron");
var CHROME_TOOLBAR_HEIGHT = 78;
var PROFILE_PARTITION = "persist:aero-chromium-profile";
var TabManager = class {
  constructor(window, sessionManager, newtabHtmlPath, onStateChanged) {
    this.tabs = /* @__PURE__ */ new Map();
    this.tabOrder = [];
    this.activeTabId = null;
    this.window = window;
    this.sessionManager = sessionManager;
    this.newtabHtmlPath = newtabHtmlPath;
    this.onStateChanged = onStateChanged;
  }
  /**
   * Initializes tabs from the persisted session.
   * Restores active tab immediately, while background tabs are restored
   * lazily to prevent memory spikes on startup.
   */
  async restoreSessionTabs() {
    const saved = this.sessionManager.loadSession();
    console.log(`[TabManager] Restoring ${saved.tabs.length} tabs from saved session...`);
    for (const savedTab of saved.tabs) {
      this.tabs.set(savedTab.id, {
        id: savedTab.id,
        url: savedTab.url,
        title: savedTab.title || "New Tab",
        favicon: savedTab.favicon,
        isLazy: savedTab.id !== saved.activeTabId,
        isLoading: false,
        canGoBack: false,
        canGoForward: false,
        lastAccessed: savedTab.lastAccessed || Date.now()
      });
      this.tabOrder.push(savedTab.id);
    }
    const targetActiveId = saved.activeTabId && this.tabs.has(saved.activeTabId) ? saved.activeTabId : this.tabOrder[0];
    await this.activateTab(targetActiveId, true);
    this.sessionManager.setRestorationComplete(true);
    this.notifyStateChanged();
  }
  /**
   * Creates a new tab.
   * If activate = true, it becomes the active tab immediately.
   */
  async createTab(initialUrl = INTERNAL_NEWTAB_URL, activate = true, title = "New Tab") {
    const tabId = `tab-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const normalized = normalizeUserUrl(initialUrl);
    const instance = {
      id: tabId,
      url: normalized,
      title,
      isLazy: false,
      isLoading: false,
      canGoBack: false,
      canGoForward: false,
      lastAccessed: Date.now()
    };
    this.tabs.set(tabId, instance);
    this.tabOrder.push(tabId);
    if (activate || !this.activeTabId) {
      await this.activateTab(tabId, true);
    }
    this.persistCurrentSession(true);
    this.notifyStateChanged();
    return tabId;
  }
  /**
   * Switches to an existing tab. Hydrates view if tab was lazy.
   */
  async switchTab(tabId) {
    if (!this.tabs.has(tabId)) return;
    if (this.activeTabId === tabId) return;
    await this.activateTab(tabId, false);
    this.persistCurrentSession(false);
    this.notifyStateChanged();
  }
  /**
   * Activates a tab:
   * - Hides/detaches previous active tab view
   * - Hydrates target tab view if lazy
   * - Attaches view to window.contentView
   * - Adjusts layout bounds
   */
  async activateTab(tabId, isInitial = false) {
    const target = this.tabs.get(tabId);
    if (!target) return;
    const prevActiveId = this.activeTabId;
    if (prevActiveId && prevActiveId !== tabId) {
      const prev = this.tabs.get(prevActiveId);
      if (prev?.view) {
        try {
          this.window.contentView.removeChildView(prev.view);
        } catch {
        }
      }
    }
    this.activeTabId = tabId;
    target.lastAccessed = Date.now();
    if (!target.view) {
      target.view = this.createWebContentsView(target);
      target.isLazy = false;
      await this.loadUrlInView(target, target.url);
    } else if (target.isLazy) {
      target.isLazy = false;
      await this.loadUrlInView(target, target.url);
    }
    try {
      this.window.contentView.addChildView(target.view);
      this.updateViewBounds(target.view);
    } catch (err) {
      console.error(`[TabManager] Failed to attach view for tab ${tabId}:`, err);
    }
    try {
      target.view.webContents.focus();
    } catch {
    }
    if (!isInitial) {
      this.persistCurrentSession(false);
    }
  }
  /**
   * Closes a tab:
   * - Records it for Ctrl+Shift+T restoration
   * - Disposes of WebContentsView
   * - If closing active tab, switches to adjacent tab
   * - If closing last tab, opens fresh New Tab
   */
  async closeTab(tabId) {
    if (!this.tabs.has(tabId)) return;
    if (this.sessionManager.isShuttingDown()) {
      return;
    }
    const target = this.tabs.get(tabId);
    this.sessionManager.recordClosedTab({
      url: target.url,
      title: target.title,
      favicon: target.favicon
    });
    if (target.view) {
      try {
        this.window.contentView.removeChildView(target.view);
        target.view.webContents.destroy?.();
      } catch (err) {
        console.warn(`[TabManager] Error destroying view for tab ${tabId}:`, err);
      }
      target.view = void 0;
    }
    const closedIndex = this.tabOrder.indexOf(tabId);
    this.tabs.delete(tabId);
    this.tabOrder = this.tabOrder.filter((id) => id !== tabId);
    if (this.activeTabId === tabId) {
      if (this.tabOrder.length > 0) {
        const nextIndex = Math.min(closedIndex, this.tabOrder.length - 1);
        const nextId = this.tabOrder[nextIndex];
        await this.activateTab(nextId, false);
      } else {
        await this.createTab(INTERNAL_NEWTAB_URL, true);
        return;
      }
    }
    this.persistCurrentSession(true);
    this.notifyStateChanged();
  }
  /**
   * Reopens the most recently closed tab (Ctrl+Shift+T).
   */
  async reopenRecentlyClosedTab() {
    const record = this.sessionManager.popRecentlyClosedTab();
    if (!record) return;
    await this.createTab(record.url, true, record.title);
  }
  /**
   * Cycle to next / previous tab (Ctrl+Tab / Ctrl+Shift+Tab)
   */
  async cycleTab(direction) {
    if (this.tabOrder.length <= 1 || !this.activeTabId) return;
    const currentIndex = this.tabOrder.indexOf(this.activeTabId);
    if (currentIndex === -1) return;
    let nextIndex = 0;
    if (direction === "next") {
      nextIndex = (currentIndex + 1) % this.tabOrder.length;
    } else {
      nextIndex = (currentIndex - 1 + this.tabOrder.length) % this.tabOrder.length;
    }
    await this.switchTab(this.tabOrder[nextIndex]);
  }
  /**
   * Navigates the current active tab to a URL or search query.
   */
  async navigateActiveTab(input) {
    if (!this.activeTabId) return;
    const target = this.tabs.get(this.activeTabId);
    if (!target) return;
    const normalized = normalizeUserUrl(input);
    target.url = normalized;
    if (!target.view) {
      target.view = this.createWebContentsView(target);
      this.window.contentView.addChildView(target.view);
      this.updateViewBounds(target.view);
    }
    await this.loadUrlInView(target, normalized);
    this.persistCurrentSession(true);
    this.notifyStateChanged();
  }
  goBack() {
    const active = this.getActiveTabInstance();
    if (active?.view?.webContents.canGoBack()) {
      active.view.webContents.goBack();
    }
  }
  goForward() {
    const active = this.getActiveTabInstance();
    if (active?.view?.webContents.canGoForward()) {
      active.view.webContents.goForward();
    }
  }
  reload() {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      active.view.webContents.reload();
    }
  }
  stop() {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      active.view.webContents.stop();
    }
  }
  /**
   * Updates WebContentsView bounds when window resizes.
   */
  updateAllViewBounds() {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      this.updateViewBounds(active.view);
    }
  }
  updateViewBounds(view) {
    const [winWidth, winHeight] = this.window.getSize();
    const contentY = CHROME_TOOLBAR_HEIGHT;
    const contentHeight = Math.max(0, winHeight - contentY);
    try {
      view.setBounds({
        x: 0,
        y: contentY,
        width: winWidth,
        height: contentHeight
      });
    } catch (err) {
      console.error("[TabManager] Error setting view bounds:", err);
    }
  }
  /**
   * Creates an isolated, sandboxed WebContentsView using the persistent profile session.
   */
  createWebContentsView(tab) {
    const persistentSession = import_electron.session.fromPartition(PROFILE_PARTITION);
    const view = new import_electron.WebContentsView({
      webPreferences: {
        session: persistentSession,
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        webSecurity: true,
        allowRunningInsecureContent: false,
        backgroundThrottling: false
      }
    });
    const wc = view.webContents;
    wc.on("did-start-loading", () => {
      tab.isLoading = true;
      this.notifyStateChanged();
    });
    wc.on("did-stop-loading", () => {
      tab.isLoading = false;
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.notifyStateChanged();
    });
    wc.on("did-navigate", (_event, url) => {
      if (url.startsWith("file://") && url.includes("newtab.html")) {
        tab.url = INTERNAL_NEWTAB_URL;
        tab.title = "New Tab";
      } else {
        tab.url = url;
      }
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });
    wc.on("did-navigate-in-page", (_event, url) => {
      tab.url = url;
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });
    wc.on("page-title-updated", (_event, title) => {
      if (tab.url === INTERNAL_NEWTAB_URL) {
        tab.title = "New Tab";
      } else {
        tab.title = title || "Untitled";
      }
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });
    wc.on("page-favicon-updated", (_event, favicons) => {
      if (favicons && favicons.length > 0) {
        tab.favicon = favicons[0];
        this.notifyStateChanged();
      }
    });
    wc.setWindowOpenHandler((details) => {
      this.createTab(details.url, true);
      return { action: "deny" };
    });
    wc.on("render-process-gone", (_event, details) => {
      console.error(`[TabManager] Tab ${tab.id} crashed: ${details.reason}`);
      tab.isLoading = false;
      this.notifyStateChanged();
    });
    return view;
  }
  async loadUrlInView(tab, urlToLoad) {
    if (!tab.view) return;
    try {
      if (urlToLoad === INTERNAL_NEWTAB_URL) {
        await tab.view.webContents.loadFile(this.newtabHtmlPath);
        tab.title = "New Tab";
      } else {
        await tab.view.webContents.loadURL(urlToLoad);
      }
    } catch (err) {
      const errorObj = err;
      if (errorObj?.code !== "ERR_ABORTED") {
        console.warn(`[TabManager] Navigation notice for ${urlToLoad}:`, errorObj?.message || err);
      }
    }
  }
  persistCurrentSession(immediate = false) {
    const list = this.tabOrder.map((id) => this.tabs.get(id)).filter((t) => !!t).map((t) => ({
      id: t.id,
      url: t.url,
      title: t.title,
      favicon: t.favicon,
      lastAccessed: t.lastAccessed
    }));
    if (list.length > 0 && this.activeTabId) {
      this.sessionManager.scheduleSave(list, this.activeTabId, immediate);
    }
  }
  getActiveTabInstance() {
    if (!this.activeTabId) return null;
    return this.tabs.get(this.activeTabId) ?? null;
  }
  getUIState() {
    const active = this.getActiveTabInstance();
    const runtimeTabs = this.tabOrder.map((id) => this.tabs.get(id)).filter((t) => !!t).map((t) => ({
      id: t.id,
      url: t.url,
      title: t.title,
      favicon: t.favicon,
      lastAccessed: t.lastAccessed,
      isLoading: t.isLoading,
      canGoBack: t.canGoBack,
      canGoForward: t.canGoForward,
      isLazy: t.isLazy
    }));
    const cached = this.sessionManager.getCachedSession();
    return {
      tabs: runtimeTabs,
      activeTabId: this.activeTabId || "",
      canGoBack: active?.canGoBack ?? false,
      canGoForward: active?.canGoForward ?? false,
      isLoading: active?.isLoading ?? false,
      currentUrl: active?.url ?? INTERNAL_NEWTAB_URL,
      sessionStats: {
        lastSaved: cached?.lastSaved || (/* @__PURE__ */ new Date()).toISOString(),
        tabsCount: runtimeTabs.length,
        closedTabsCount: this.sessionManager.getClosedTabsCount()
      }
    };
  }
  notifyStateChanged() {
    this.onStateChanged();
  }
  /**
   * Called during application shutdown to safely release views
   */
  cleanupBeforeExit() {
    for (const tab of this.tabs.values()) {
      if (tab.view) {
        try {
          this.window.contentView.removeChildView(tab.view);
        } catch {
        }
      }
    }
  }
};

// electron/types.ts
var IPC_CHANNELS = {
  UI_READY: "ui:ready",
  STATE_UPDATE: "browser:state-update",
  TAB_CREATE: "tab:create",
  TAB_CLOSE: "tab:close",
  TAB_SWITCH: "tab:switch",
  TAB_NAVIGATE: "tab:navigate",
  TAB_GO_BACK: "tab:go-back",
  TAB_GO_FORWARD: "tab:go-forward",
  TAB_RELOAD: "tab:reload",
  TAB_STOP: "tab:stop",
  TAB_REOPEN_CLOSED: "tab:reopen-closed",
  FOCUS_ADDRESS_BAR: "shortcut:focus-address-bar",
  WINDOW_MINIMIZE: "window:minimize",
  WINDOW_MAXIMIZE: "window:maximize",
  WINDOW_CLOSE: "window:close",
  GET_INITIAL_STATE: "browser:get-initial-state"
};

// electron/main.ts
var resolvedDir = typeof __dirname !== "undefined" ? __dirname : process.cwd();
var gotTheLock = import_electron2.app.requestSingleInstanceLock();
if (!gotTheLock) {
  console.log("[AeroChromium] Another instance is already running. Exiting...");
  import_electron2.app.quit();
  process.exit(0);
}
var AeroChromiumApp = class {
  constructor() {
    this.mainWindow = null;
    this.toolbarView = null;
    this.sessionManager = null;
    this.tabManager = null;
    this.userDataDir = import_electron2.app.getPath("userData");
    console.log(`[AeroChromium] User data directory: ${this.userDataDir}`);
    this.preloadPath = import_node_path2.default.join(resolvedDir, "preload.cjs");
    if (!import_node_fs2.default.existsSync(this.preloadPath)) {
      this.preloadPath = import_node_path2.default.join(resolvedDir, "preload.js");
    }
    this.chromeHtmlPath = import_node_path2.default.join(resolvedDir, "renderer", "chrome.html");
    this.newtabHtmlPath = import_node_path2.default.join(resolvedDir, "renderer", "newtab.html");
  }
  async init() {
    this.sessionManager = new SessionManager({
      userDataDir: this.userDataDir,
      onLog: (msg) => console.log(`[SessionEngine] ${msg}`)
    });
    await import_electron2.app.whenReady();
    await this.createMainWindow();
    this.registerShortcuts();
    this.setupIpc();
    this.setupAppLifecycle();
  }
  async createMainWindow() {
    this.mainWindow = new import_electron2.BrowserWindow({
      width: 1280,
      height: 840,
      minWidth: 700,
      minHeight: 450,
      frame: false,
      // Frameless for modern custom tab strip
      titleBarStyle: "hidden",
      backgroundColor: "#0a0b0e",
      webPreferences: {
        // Main window shell itself doesn't need node integration
        nodeIntegration: false,
        contextIsolation: true
      }
    });
    const [winWidth] = this.mainWindow.getSize();
    this.toolbarView = new import_electron2.WebContentsView({
      webPreferences: {
        preload: this.preloadPath,
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true
      }
    });
    this.toolbarView.setBounds({
      x: 0,
      y: 0,
      width: winWidth,
      height: CHROME_TOOLBAR_HEIGHT
    });
    this.mainWindow.contentView.addChildView(this.toolbarView);
    this.tabManager = new TabManager(
      this.mainWindow,
      this.sessionManager,
      this.newtabHtmlPath,
      () => this.broadcastStateUpdate()
    );
    await this.toolbarView.webContents.loadFile(this.chromeHtmlPath);
    await this.tabManager.restoreSessionTabs();
    this.mainWindow.on("resize", () => {
      if (!this.mainWindow || !this.toolbarView || !this.tabManager) return;
      const [w] = this.mainWindow.getSize();
      this.toolbarView.setBounds({
        x: 0,
        y: 0,
        width: w,
        height: CHROME_TOOLBAR_HEIGHT
      });
      this.tabManager.updateAllViewBounds();
      this.broadcastStateUpdate();
    });
    this.mainWindow.on("maximize", () => this.broadcastStateUpdate());
    this.mainWindow.on("unmaximize", () => this.broadcastStateUpdate());
    import_electron2.app.on("second-instance", () => {
      if (this.mainWindow) {
        if (this.mainWindow.isMinimized()) this.mainWindow.restore();
        this.mainWindow.focus();
      }
    });
    this.mainWindow.on("closed", () => {
      this.mainWindow = null;
      this.toolbarView = null;
    });
  }
  registerShortcuts() {
    if (!this.mainWindow) return;
    import_electron2.globalShortcut.register("CommandOrControl+T", () => {
      this.tabManager?.createTab();
    });
    import_electron2.globalShortcut.register("CommandOrControl+W", () => {
      const active = this.tabManager?.getActiveTabInstance();
      if (active) {
        this.tabManager?.closeTab(active.id);
      }
    });
    import_electron2.globalShortcut.register("CommandOrControl+Shift+T", () => {
      this.tabManager?.reopenRecentlyClosedTab();
    });
    import_electron2.globalShortcut.register("CommandOrControl+L", () => {
      if (this.toolbarView) {
        this.toolbarView.webContents.focus();
        this.toolbarView.webContents.send(IPC_CHANNELS.FOCUS_ADDRESS_BAR);
      }
    });
    import_electron2.globalShortcut.register("CommandOrControl+Tab", () => {
      this.tabManager?.cycleTab("next");
    });
    import_electron2.globalShortcut.register("CommandOrControl+Shift+Tab", () => {
      this.tabManager?.cycleTab("prev");
    });
    import_electron2.globalShortcut.register("CommandOrControl+R", () => {
      this.tabManager?.reload();
    });
    import_electron2.globalShortcut.register("F5", () => {
      this.tabManager?.reload();
    });
  }
  setupIpc() {
    import_electron2.ipcMain.on(IPC_CHANNELS.UI_READY, () => {
      this.broadcastStateUpdate();
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_CREATE, (_event, url) => {
      this.tabManager?.createTab(typeof url === "string" ? url : void 0);
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_CLOSE, (_event, tabId) => {
      if (typeof tabId === "string") {
        this.tabManager?.closeTab(tabId);
      }
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_SWITCH, (_event, tabId) => {
      if (typeof tabId === "string") {
        this.tabManager?.switchTab(tabId);
      }
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_NAVIGATE, (_event, url) => {
      if (typeof url === "string") {
        this.tabManager?.navigateActiveTab(url);
      }
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_GO_BACK, () => this.tabManager?.goBack());
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_GO_FORWARD, () => this.tabManager?.goForward());
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_RELOAD, () => this.tabManager?.reload());
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_STOP, () => this.tabManager?.stop());
    import_electron2.ipcMain.on(IPC_CHANNELS.TAB_REOPEN_CLOSED, () => this.tabManager?.reopenRecentlyClosedTab());
    import_electron2.ipcMain.on(IPC_CHANNELS.WINDOW_MINIMIZE, () => this.mainWindow?.minimize());
    import_electron2.ipcMain.on(IPC_CHANNELS.WINDOW_MAXIMIZE, () => {
      if (this.mainWindow?.isMaximized()) {
        this.mainWindow.unmaximize();
      } else {
        this.mainWindow?.maximize();
      }
    });
    import_electron2.ipcMain.on(IPC_CHANNELS.WINDOW_CLOSE, () => this.mainWindow?.close());
  }
  broadcastStateUpdate() {
    if (!this.toolbarView || !this.tabManager || !this.mainWindow) return;
    const baseState = this.tabManager.getUIState();
    const fullState = {
      ...baseState,
      isMaximized: this.mainWindow.isMaximized()
    };
    try {
      this.toolbarView.webContents.send(IPC_CHANNELS.STATE_UPDATE, fullState);
    } catch {
    }
  }
  setupAppLifecycle() {
    import_electron2.app.on("before-quit", () => {
      console.log("[AeroChromium] App preparing for quit. Initiating synchronous session flush...");
      import_electron2.globalShortcut.unregisterAll();
      if (this.sessionManager) {
        this.sessionManager.prepareForShutdown();
        this.sessionManager.flushSync();
      }
      if (this.tabManager) {
        this.tabManager.cleanupBeforeExit();
      }
    });
    import_electron2.app.on("window-all-closed", () => {
      import_electron2.app.quit();
    });
  }
};
var aeroApp = new AeroChromiumApp();
aeroApp.init().catch((err) => {
  console.error("[AeroChromium] Fatal initialization error:", err);
});
//# sourceMappingURL=main.cjs.map
