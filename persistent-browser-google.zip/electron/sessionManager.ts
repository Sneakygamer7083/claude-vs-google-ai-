/**
 * AeroChromium Session Manager
 * Opera GX-style session persistence engine with atomic writes, backup rotation,
 * and corruption recovery.
 */

import fs from 'node:fs';
import path from 'node:path';
import { BrowserSessionData, ClosedTabRecord, PersistedTab } from './types.js';
import { INTERNAL_NEWTAB_URL, sanitizePersistedUrl } from './urlUtils.js';

export const CURRENT_SESSION_VERSION = 1;
export const SESSION_FILE_NAME = 'aero-session-v1.json';
export const SESSION_BACKUP_NAME = 'aero-session-v1.json.bak';
export const SESSION_TEMP_NAME = 'aero-session-v1.json.tmp';
const MAX_CLOSED_TABS_HISTORY = 30;

export interface SessionManagerOptions {
  userDataDir: string;
  debounceMs?: number;
  onLog?: (msg: string) => void;
}

export class SessionManager {
  private userDataDir: string;
  private sessionFilePath: string;
  private backupFilePath: string;
  private tempFilePath: string;
  private debounceMs: number;
  private debounceTimer: NodeJS.Timeout | null = null;
  private log: (msg: string) => void;

  // Protection flags
  private isAppShuttingDown = false;
  private isRestorationComplete = false;
  private cachedSession: BrowserSessionData | null = null;
  private closedTabsHistory: ClosedTabRecord[] = [];

  constructor(options: SessionManagerOptions) {
    this.userDataDir = options.userDataDir;
    this.debounceMs = options.debounceMs ?? 350;
    this.log = options.onLog ?? ((msg: string) => console.log(`[SessionManager] ${msg}`));

    // Ensure userData directory exists
    try {
      if (!fs.existsSync(this.userDataDir)) {
        fs.mkdirSync(this.userDataDir, { recursive: true });
      }
    } catch (err) {
      console.error('[SessionManager] Failed to create userDataDir:', err);
    }

    this.sessionFilePath = path.join(this.userDataDir, SESSION_FILE_NAME);
    this.backupFilePath = path.join(this.userDataDir, SESSION_BACKUP_NAME);
    this.tempFilePath = path.join(this.userDataDir, SESSION_TEMP_NAME);
  }

  /**
   * Mark application as shutting down.
   * This immediately prevents any subsequent tab destruction callbacks
   * from overwriting the session file with an empty tab array.
   */
  public prepareForShutdown(): void {
    this.isAppShuttingDown = true;
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
  }

  public isShuttingDown(): boolean {
    return this.isAppShuttingDown;
  }

  public setRestorationComplete(complete = true): void {
    this.isRestorationComplete = complete;
  }

  /**
   * Records a user-closed tab into the recent closed stack for Ctrl+Shift+T.
   */
  public recordClosedTab(tab: { url: string; title: string; favicon?: string }): void {
    if (this.isAppShuttingDown) return;
    const sanitizedUrl = sanitizePersistedUrl(tab.url);
    if (sanitizedUrl === INTERNAL_NEWTAB_URL && tab.title === 'New Tab') {
      // Don't clutter closed tab history with blank new tabs
      return;
    }

    this.closedTabsHistory.unshift({
      url: sanitizedUrl,
      title: tab.title || 'Untitled',
      favicon: tab.favicon,
      closedAt: Date.now(),
    });

    if (this.closedTabsHistory.length > MAX_CLOSED_TABS_HISTORY) {
      this.closedTabsHistory.pop();
    }
  }

  /**
   * Retrieves and pops the most recently closed tab for restoration.
   */
  public popRecentlyClosedTab(): ClosedTabRecord | null {
    return this.closedTabsHistory.shift() ?? null;
  }

  public getClosedTabsCount(): number {
    return this.closedTabsHistory.length;
  }

  /**
   * Loads the session from disk.
   * Order of recovery:
   * 1. Primary file (aero-session-v1.json)
   * 2. Backup file (aero-session-v1.json.bak)
   * 3. Safe fallback default (single New Tab)
   */
  public loadSession(): BrowserSessionData {
    this.log(`Loading session from: ${this.sessionFilePath}`);

    // Try primary session file
    if (fs.existsSync(this.sessionFilePath)) {
      try {
        const raw = fs.readFileSync(this.sessionFilePath, 'utf-8');
        const parsed = JSON.parse(raw);
        if (this.isValidSessionPayload(parsed)) {
          const sanitized = this.sanitizeSessionPayload(parsed);
          this.log(`Primary session loaded successfully with ${sanitized.tabs.length} tabs.`);
          this.cachedSession = sanitized;
          if (sanitized.closedTabs) {
            this.closedTabsHistory = [...sanitized.closedTabs];
          }
          return sanitized;
        } else {
          this.log(`Primary session payload was structurally invalid. Attempting backup...`);
        }
      } catch (err) {
        this.log(`Primary session file parse failed (${err}). Attempting backup...`);
      }
    } else {
      this.log(`No primary session file found. Checking backup...`);
    }

    // Try backup session file
    if (fs.existsSync(this.backupFilePath)) {
      try {
        const rawBackup = fs.readFileSync(this.backupFilePath, 'utf-8');
        const parsedBackup = JSON.parse(rawBackup);
        if (this.isValidSessionPayload(parsedBackup)) {
          const sanitizedBackup = this.sanitizeSessionPayload(parsedBackup);
          this.log(`Recovered session from backup with ${sanitizedBackup.tabs.length} tabs.`);
          this.cachedSession = sanitizedBackup;
          // Re-persist primary from recovered backup immediately
          this.writeSessionAtomicSync(sanitizedBackup);
          return sanitizedBackup;
        }
      } catch (backupErr) {
        this.log(`Backup session parse failed (${backupErr}).`);
      }
    }

    // Fallback: Default fresh session
    this.log(`Creating fresh initial session.`);
    const fallback = this.createDefaultSession();
    this.cachedSession = fallback;
    return fallback;
  }

  /**
   * Schedule a debounced session write, or execute immediately.
   */
  public scheduleSave(tabs: PersistedTab[], activeTabId: string, immediate = false): void {
    // If shutting down and not an immediate flush, or if restoration is not yet done, protect session!
    if (!this.isRestorationComplete && !immediate) {
      this.log('Skipping save because session restoration is still in progress.');
      return;
    }

    if (this.isAppShuttingDown && !immediate) {
      this.log('Skipping debounced save during shutdown.');
      return;
    }

    // Protect against accidentally saving an empty tab list during race conditions
    if (!tabs || tabs.length === 0) {
      this.log('Refusing to persist an empty tab array. Preserving previous session.');
      return;
    }

    const sessionPayload: BrowserSessionData = {
      version: CURRENT_SESSION_VERSION,
      lastSaved: new Date().toISOString(),
      activeTabId: activeTabId || tabs[0].id,
      tabs: tabs.map((t) => ({
        id: t.id,
        url: sanitizePersistedUrl(t.url),
        title: t.title || 'Untitled',
        favicon: t.favicon,
        lastAccessed: t.lastAccessed || Date.now(),
      })),
      closedTabs: this.closedTabsHistory.slice(0, 15),
    };

    this.cachedSession = sessionPayload;

    if (immediate) {
      if (this.debounceTimer) {
        clearTimeout(this.debounceTimer);
        this.debounceTimer = null;
      }
      this.writeSessionAtomicSync(sessionPayload);
      return;
    }

    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }

    this.debounceTimer = setTimeout(() => {
      this.debounceTimer = null;
      this.writeSessionAtomicSync(sessionPayload);
    }, this.debounceMs);
  }

  /**
   * Flushes any pending writes synchronously to disk.
   * Called during application before-quit event.
   */
  public flushSync(): void {
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
      this.debounceTimer = null;
    }
    if (this.cachedSession && this.cachedSession.tabs.length > 0) {
      this.log('Flushing session synchronously to disk on shutdown...');
      this.writeSessionAtomicSync(this.cachedSession);
    }
  }

  /**
   * Atomic file write strategy:
   * 1. If primary file exists and is valid, copy/rotate to .bak
   * 2. Write serialized JSON to .tmp file
   * 3. Flush OS buffer to disk via fsyncSync
   * 4. Rename .tmp over destination with Windows atomic replace fallback
   */
  public writeSessionAtomicSync(data: BrowserSessionData): boolean {
    try {
      const serialized = JSON.stringify(data, null, 2);

      // 1. Maintain last-known-good backup if primary currently exists
      if (fs.existsSync(this.sessionFilePath)) {
        try {
          fs.copyFileSync(this.sessionFilePath, this.backupFilePath);
        } catch (copyErr) {
          // Non-fatal, continue with write
          this.log(`Backup copy notice: ${copyErr}`);
        }
      }

      // 2. Write to temp file
      const fd = fs.openSync(this.tempFilePath, 'w');
      fs.writeSync(fd, serialized, 0, 'utf-8');
      fs.fsyncSync(fd);
      fs.closeSync(fd);

      // 3. Atomically replace destination
      // On Windows, fs.renameSync fails if target exists in some file system configurations;
      // we perform atomic replace or unlink+rename.
      try {
        fs.renameSync(this.tempFilePath, this.sessionFilePath);
      } catch {
        // Windows fallback
        if (fs.existsSync(this.sessionFilePath)) {
          fs.unlinkSync(this.sessionFilePath);
        }
        fs.renameSync(this.tempFilePath, this.sessionFilePath);
      }

      this.log(`Session saved atomically (${data.tabs.length} tabs, active: ${data.activeTabId}).`);
      return true;
    } catch (err) {
      console.error('[SessionManager] Critical error writing session atomically:', err);
      return false;
    } finally {
      // Clean up orphaned temp file if left
      if (fs.existsSync(this.tempFilePath)) {
        try {
          fs.unlinkSync(this.tempFilePath);
        } catch {
          // ignore
        }
      }
    }
  }

  /**
   * Validates structure of candidate session payload
   */
  public isValidSessionPayload(obj: unknown): obj is BrowserSessionData {
    if (!obj || typeof obj !== 'object') return false;
    const candidate = obj as Record<string, unknown>;

    if (typeof candidate.version !== 'number' || candidate.version !== CURRENT_SESSION_VERSION) {
      return false;
    }

    if (!Array.isArray(candidate.tabs) || candidate.tabs.length === 0) {
      return false;
    }

    if (typeof candidate.activeTabId !== 'string' || !candidate.activeTabId) {
      return false;
    }

    // Every tab must have at least an id and url string
    for (const tab of candidate.tabs) {
      if (!tab || typeof tab !== 'object') return false;
      const t = tab as Record<string, unknown>;
      if (typeof t.id !== 'string' || typeof t.url !== 'string') {
        return false;
      }
    }

    return true;
  }

  /**
   * Sanitizes candidate session payload by validating activeTabId exists
   * and sanitizing each URL against malicious protocol schemes.
   */
  public sanitizeSessionPayload(data: BrowserSessionData): BrowserSessionData {
    const sanitizedTabs: PersistedTab[] = data.tabs.map((tab, idx) => ({
      id: tab.id || `tab-restored-${idx}-${Date.now()}`,
      url: sanitizePersistedUrl(tab.url),
      title: tab.title || 'Untitled',
      favicon: tab.favicon,
      lastAccessed: typeof tab.lastAccessed === 'number' ? tab.lastAccessed : Date.now(),
    }));

    // Ensure activeTabId points to a real tab in the array
    let activeId = data.activeTabId;
    if (!sanitizedTabs.some((t) => t.id === activeId)) {
      activeId = sanitizedTabs[0].id;
    }

    return {
      version: CURRENT_SESSION_VERSION,
      lastSaved: data.lastSaved || new Date().toISOString(),
      activeTabId: activeId,
      tabs: sanitizedTabs,
      closedTabs: Array.isArray(data.closedTabs) ? data.closedTabs : [],
    };
  }

  public createDefaultSession(): BrowserSessionData {
    const initialId = `tab-init-${Date.now()}`;
    return {
      version: CURRENT_SESSION_VERSION,
      lastSaved: new Date().toISOString(),
      activeTabId: initialId,
      tabs: [
        {
          id: initialId,
          url: INTERNAL_NEWTAB_URL,
          title: 'New Tab',
          lastAccessed: Date.now(),
        },
      ],
      closedTabs: [],
    };
  }

  public getSessionPaths(): { sessionFile: string; backupFile: string; tempFile: string; userDataDir: string } {
    return {
      sessionFile: this.sessionFilePath,
      backupFile: this.backupFilePath,
      tempFile: this.tempFilePath,
      userDataDir: this.userDataDir,
    };
  }

  public getCachedSession(): BrowserSessionData | null {
    return this.cachedSession;
  }
}
