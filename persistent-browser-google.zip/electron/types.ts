/**
 * AeroChromium Browser - Type Definitions
 * Strict types for tab state, session serialization, and IPC communication.
 */

export interface PersistedTab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  lastAccessed: number;
}

export interface ClosedTabRecord {
  url: string;
  title: string;
  favicon?: string;
  closedAt: number;
}

export interface BrowserSessionData {
  version: number;
  lastSaved: string;
  activeTabId: string;
  tabs: PersistedTab[];
  closedTabs?: ClosedTabRecord[];
}

export interface RuntimeTabState extends PersistedTab {
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  isLazy?: boolean;
}

export interface BrowserUIState {
  tabs: RuntimeTabState[];
  activeTabId: string;
  canGoBack: boolean;
  canGoForward: boolean;
  isLoading: boolean;
  currentUrl: string;
  isMaximized: boolean;
  sessionStats: {
    lastSaved: string;
    tabsCount: number;
    closedTabsCount: number;
  };
}

export const IPC_CHANNELS = {
  UI_READY: 'ui:ready',
  STATE_UPDATE: 'browser:state-update',
  TAB_CREATE: 'tab:create',
  TAB_CLOSE: 'tab:close',
  TAB_SWITCH: 'tab:switch',
  TAB_NAVIGATE: 'tab:navigate',
  TAB_GO_BACK: 'tab:go-back',
  TAB_GO_FORWARD: 'tab:go-forward',
  TAB_RELOAD: 'tab:reload',
  TAB_STOP: 'tab:stop',
  TAB_REOPEN_CLOSED: 'tab:reopen-closed',
  FOCUS_ADDRESS_BAR: 'shortcut:focus-address-bar',
  WINDOW_MINIMIZE: 'window:minimize',
  WINDOW_MAXIMIZE: 'window:maximize',
  WINDOW_CLOSE: 'window:close',
  GET_INITIAL_STATE: 'browser:get-initial-state',
} as const;
