/**
 * AeroChromium Preload Script
 * Exposes a strictly scoped, secure IPC bridge ONLY for the trusted browser UI.
 * Context isolation and sandboxing are enabled; remote websites do NOT receive this bridge.
 */

import { contextBridge, ipcRenderer } from 'electron';
import { BrowserUIState, IPC_CHANNELS } from './types.js';

export interface AeroBrowserApi {
  // Tab actions
  createTab: (url?: string) => void;
  closeTab: (tabId: string) => void;
  switchTab: (tabId: string) => void;
  navigateTab: (url: string) => void;
  goBack: () => void;
  goForward: () => void;
  reload: () => void;
  stop: () => void;
  reopenRecentlyClosedTab: () => void;

  // Window actions
  minimizeWindow: () => void;
  maximizeWindow: () => void;
  closeWindow: () => void;

  // State synchronization
  onStateUpdate: (callback: (state: BrowserUIState) => void) => () => void;
  onFocusAddressBar: (callback: () => void) => () => void;
  notifyUiReady: () => void;
}

const api: AeroBrowserApi = {
  createTab: (url?: string) => {
    ipcRenderer.send(IPC_CHANNELS.TAB_CREATE, typeof url === 'string' ? url : undefined);
  },
  closeTab: (tabId: string) => {
    if (typeof tabId === 'string' && tabId.trim()) {
      ipcRenderer.send(IPC_CHANNELS.TAB_CLOSE, tabId);
    }
  },
  switchTab: (tabId: string) => {
    if (typeof tabId === 'string' && tabId.trim()) {
      ipcRenderer.send(IPC_CHANNELS.TAB_SWITCH, tabId);
    }
  },
  navigateTab: (url: string) => {
    if (typeof url === 'string') {
      ipcRenderer.send(IPC_CHANNELS.TAB_NAVIGATE, url);
    }
  },
  goBack: () => ipcRenderer.send(IPC_CHANNELS.TAB_GO_BACK),
  goForward: () => ipcRenderer.send(IPC_CHANNELS.TAB_GO_FORWARD),
  reload: () => ipcRenderer.send(IPC_CHANNELS.TAB_RELOAD),
  stop: () => ipcRenderer.send(IPC_CHANNELS.TAB_STOP),
  reopenRecentlyClosedTab: () => ipcRenderer.send(IPC_CHANNELS.TAB_REOPEN_CLOSED),

  minimizeWindow: () => ipcRenderer.send(IPC_CHANNELS.WINDOW_MINIMIZE),
  maximizeWindow: () => ipcRenderer.send(IPC_CHANNELS.WINDOW_MAXIMIZE),
  closeWindow: () => ipcRenderer.send(IPC_CHANNELS.WINDOW_CLOSE),

  onStateUpdate: (callback: (state: BrowserUIState) => void) => {
    const handler = (_event: Electron.IpcRendererEvent, state: BrowserUIState) => {
      callback(state);
    };
    ipcRenderer.on(IPC_CHANNELS.STATE_UPDATE, handler);
    return () => {
      ipcRenderer.removeListener(IPC_CHANNELS.STATE_UPDATE, handler);
    };
  },

  onFocusAddressBar: (callback: () => void) => {
    const handler = () => callback();
    ipcRenderer.on(IPC_CHANNELS.FOCUS_ADDRESS_BAR, handler);
    return () => {
      ipcRenderer.removeListener(IPC_CHANNELS.FOCUS_ADDRESS_BAR, handler);
    };
  },

  notifyUiReady: () => {
    ipcRenderer.send(IPC_CHANNELS.UI_READY);
  },
};

// Expose strictly to window.aeroBrowserApi
contextBridge.exposeInMainWorld('aeroBrowserApi', api);
