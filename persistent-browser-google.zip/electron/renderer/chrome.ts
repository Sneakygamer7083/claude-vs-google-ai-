/**
 * AeroChromium Toolbar Client Script
 * Handles tab strip DOM updates, omnibox keyboard navigation,
 * and IPC interactions via window.aeroBrowserApi.
 */

import { BrowserUIState, RuntimeTabState } from '../types.js';

declare global {
  interface Window {
    aeroBrowserApi: import('../preload.js').AeroBrowserApi;
  }
}

class ChromeRenderer {
  private tabStripEl = document.getElementById('tab-strip') as HTMLElement;
  private btnNewTab = document.getElementById('btn-new-tab') as HTMLButtonElement;
  private btnBack = document.getElementById('btn-back') as HTMLButtonElement;
  private btnForward = document.getElementById('btn-forward') as HTMLButtonElement;
  private btnReload = document.getElementById('btn-reload') as HTMLButtonElement;
  private iconReload = document.getElementById('icon-reload') as HTMLElement;
  private iconStop = document.getElementById('icon-stop') as HTMLElement;
  private btnReopenClosed = document.getElementById('btn-reopen-closed') as HTMLButtonElement;

  private omniboxForm = document.getElementById('omnibox-form') as HTMLFormElement;
  private omniboxInput = document.getElementById('omnibox-input') as HTMLInputElement;
  private iconLock = document.getElementById('icon-lock') as HTMLElement;
  private iconGlobe = document.getElementById('icon-globe') as HTMLElement;

  private winBtnMin = document.getElementById('win-btn-min') as HTMLButtonElement;
  private winBtnMax = document.getElementById('win-btn-max') as HTMLButtonElement;
  private winBtnClose = document.getElementById('win-btn-close') as HTMLButtonElement;

  private currentState: BrowserUIState | null = null;
  private isOmniboxFocused = false;

  constructor() {
    this.initEventListeners();
    this.connectIpc();
  }

  private connectIpc(): void {
    if (!window.aeroBrowserApi) {
      console.warn('aeroBrowserApi not available in window. Running in standalone preview?');
      return;
    }

    // Subscribe to browser state updates from main process
    window.aeroBrowserApi.onStateUpdate((state: BrowserUIState) => {
      this.currentState = state;
      this.render(state);
    });

    // Handle Ctrl+L address bar focus
    window.aeroBrowserApi.onFocusAddressBar(() => {
      this.omniboxInput.focus();
      this.omniboxInput.select();
    });

    // Signal main process that UI is loaded
    window.aeroBrowserApi.notifyUiReady();
  }

  private initEventListeners(): void {
    // New Tab
    this.btnNewTab.addEventListener('click', () => {
      window.aeroBrowserApi?.createTab();
    });

    // Back, Forward, Reload, Stop
    this.btnBack.addEventListener('click', () => window.aeroBrowserApi?.goBack());
    this.btnForward.addEventListener('click', () => window.aeroBrowserApi?.goForward());

    this.btnReload.addEventListener('click', () => {
      if (this.currentState?.isLoading) {
        window.aeroBrowserApi?.stop();
      } else {
        window.aeroBrowserApi?.reload();
      }
    });

    // Reopen closed tab
    this.btnReopenClosed.addEventListener('click', () => {
      window.aeroBrowserApi?.reopenRecentlyClosedTab();
    });

    // Omnibox focus tracking
    this.omniboxInput.addEventListener('focus', () => {
      this.isOmniboxFocused = true;
      this.omniboxInput.select();
    });

    this.omniboxInput.addEventListener('blur', () => {
      this.isOmniboxFocused = false;
      // Revert to current tab URL on blur if user canceled
      if (this.currentState) {
        this.updateOmniboxUrl(this.currentState.currentUrl);
      }
    });

    // Omnibox submission
    this.omniboxForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = this.omniboxInput.value.trim();
      if (val) {
        window.aeroBrowserApi?.navigateTab(val);
        this.omniboxInput.blur();
      }
    });

    // Window controls
    this.winBtnMin.addEventListener('click', () => window.aeroBrowserApi?.minimizeWindow());
    this.winBtnMax.addEventListener('click', () => window.aeroBrowserApi?.maximizeWindow());
    this.winBtnClose.addEventListener('click', () => window.aeroBrowserApi?.closeWindow());
  }

  private render(state: BrowserUIState): void {
    // Update navigation button states
    this.btnBack.disabled = !state.canGoBack;
    this.btnForward.disabled = !state.canGoForward;

    // Toggle reload vs stop icons
    if (state.isLoading) {
      this.iconReload.classList.add('hidden');
      this.iconStop.classList.remove('hidden');
      this.btnReload.title = 'Stop loading this page (Esc)';
    } else {
      this.iconReload.classList.remove('hidden');
      this.iconStop.classList.add('hidden');
      this.btnReload.title = 'Reload this page (Ctrl+R)';
    }

    // Update omnibox unless user is actively editing
    if (!this.isOmniboxFocused) {
      this.updateOmniboxUrl(state.currentUrl);
    }

    // Render tab strip
    this.renderTabs(state.tabs, state.activeTabId);
  }

  private updateOmniboxUrl(url: string): void {
    if (url === 'browser://newtab' || url === '' || url.includes('newtab.html')) {
      this.omniboxInput.value = '';
      this.omniboxInput.placeholder = 'Search with Google or enter web address';
      this.iconLock.classList.add('hidden');
      this.iconGlobe.classList.remove('hidden');
    } else {
      this.omniboxInput.value = url;
      const isHttps = url.startsWith('https://');
      if (isHttps) {
        this.iconLock.classList.remove('hidden');
        this.iconGlobe.classList.add('hidden');
      } else {
        this.iconLock.classList.add('hidden');
        this.iconGlobe.classList.remove('hidden');
      }
    }
  }

  private renderTabs(tabs: RuntimeTabState[], activeTabId: string): void {
    this.tabStripEl.innerHTML = '';

    tabs.forEach((tab) => {
      const tabEl = document.createElement('div');
      const isActive = tab.id === activeTabId;
      tabEl.className = `tab-item ${isActive ? 'active' : ''}`;
      tabEl.dataset.tabId = tab.id;

      // Favicon or Spinner
      const faviconContainer = document.createElement('div');
      faviconContainer.className = 'tab-favicon';

      if (tab.isLoading) {
        const spinner = document.createElement('span');
        spinner.className = 'tab-spinner';
        faviconContainer.appendChild(spinner);
      } else if (tab.favicon) {
        const img = document.createElement('img');
        img.src = tab.favicon;
        img.alt = '';
        img.onerror = () => {
          // Fallback globe icon if favicon fails
          faviconContainer.innerHTML = `
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <circle cx="12" cy="12" r="10"></circle>
              <line x1="2" y1="12" x2="22" y2="12"></line>
              <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
            </svg>
          `;
        };
        faviconContainer.appendChild(img);
      } else {
        faviconContainer.innerHTML = `
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="12" cy="12" r="10"></circle>
            <line x1="2" y1="12" x2="22" y2="12"></line>
            <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
          </svg>
        `;
      }
      tabEl.appendChild(faviconContainer);

      // Title
      const titleEl = document.createElement('span');
      titleEl.className = 'tab-title';
      titleEl.textContent = tab.title || (tab.url === 'browser://newtab' ? 'New Tab' : tab.url);
      tabEl.appendChild(titleEl);

      // Lazy badge if restored from disk and not yet hydrated
      if (tab.isLazy) {
        const lazyBadge = document.createElement('span');
        lazyBadge.className = 'tab-lazy-badge';
        lazyBadge.textContent = 'RESTORED';
        lazyBadge.title = 'Tab restored from session (click to load)';
        tabEl.appendChild(lazyBadge);
      }

      // Close Button
      const closeBtn = document.createElement('button');
      closeBtn.className = 'tab-close-btn';
      closeBtn.title = 'Close tab (Ctrl+W)';
      closeBtn.innerHTML = `
        <svg width="10" height="10" viewBox="0 0 10 10">
          <line x1="1" y1="1" x2="9" y2="9" stroke="currentColor" stroke-width="1.3"></line>
          <line x1="9" y1="1" x2="1" y2="9" stroke="currentColor" stroke-width="1.3"></line>
        </svg>
      `;
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        window.aeroBrowserApi?.closeTab(tab.id);
      });
      tabEl.appendChild(closeBtn);

      // Tab selection click
      tabEl.addEventListener('click', () => {
        window.aeroBrowserApi?.switchTab(tab.id);
      });

      this.tabStripEl.appendChild(tabEl);
    });

    // Auto-scroll active tab into view if needed
    const activeEl = this.tabStripEl.querySelector('.tab-item.active') as HTMLElement;
    if (activeEl) {
      activeEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'nearest' });
    }
  }
}

// Instantiate on DOM load
window.addEventListener('DOMContentLoaded', () => {
  new ChromeRenderer();
});
