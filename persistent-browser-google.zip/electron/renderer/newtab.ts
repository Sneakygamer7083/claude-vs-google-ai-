/**
 * AeroChromium New Tab Page Client Script
 * Powers digital clock, speed dial link clicks, and search input routing.
 */

function updateClock(): void {
  const clockEl = document.getElementById('digital-clock');
  const dateEl = document.getElementById('date-display');
  if (!clockEl || !dateEl) return;

  const now = new Date();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  clockEl.textContent = `${hours}:${minutes}`;

  const options: Intl.DateTimeFormatOptions = {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  };
  dateEl.textContent = now.toLocaleDateString(undefined, options);
}

function setupSearch(): void {
  const searchForm = document.getElementById('search-form') as HTMLFormElement;
  const searchInput = document.getElementById('search-input') as HTMLInputElement;

  if (!searchForm || !searchInput) return;

  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = searchInput.value.trim();
    if (!query) return;

    // Check if query is direct URL
    if (query.startsWith('http://') || query.startsWith('https://')) {
      window.location.href = query;
      return;
    }

    const domainPattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
    if (domainPattern.test(query)) {
      window.location.href = `https://${query}`;
      return;
    }

    // Otherwise route to Google Search
    window.location.href = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
  });
}

window.addEventListener('DOMContentLoaded', () => {
  updateClock();
  setInterval(updateClock, 1000);
  setupSearch();
});
