/**
 * AeroChromium Main Process Entry Point
 * Orchestrates BaseWindow / BrowserWindow, toolbar WebContentsView,
 * tab management, keyboard shortcuts, IPC handling, and single-instance locking.
 */

import { app, BrowserWindow, globalShortcut, ipcMain, WebContentsView } from 'electron';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { SessionManager } from './sessionManager.js';
import { CHROME_TOOLBAR_HEIGHT, TabManager } from './tabManager.js';
import { BrowserUIState, IPC_CHANNELS } from './types.js';

// CommonJS / Node directory resolution for compiled bundle
declare const __dirname: string | undefined;
const resolvedDir = typeof __dirname !== 'undefined' ? __dirname : process.cwd();

// Single Instance Lock: Prevents race conditions from overwriting session data
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  console.log('[AeroChromium] Another instance is already running. Exiting...');
  app.quit();
  process.exit(0);
}

class AeroChromiumApp {
  private mainWindow: BrowserWindow | null = null;
  private toolbarView: WebContentsView | null = null;
  private sessionManager: SessionManager | null = null;
  private tabManager: TabManager | null = null;
  private userDataDir: string;
  private preloadPath: string;
  private chromeHtmlPath: string;
  private newtabHtmlPath: string;

  constructor() {
    this.userDataDir = app.getPath('userData');
    console.log(`[AeroChromium] User data directory: ${this.userDataDir}`);

    // Resolve asset paths
    this.preloadPath = path.join(resolvedDir, 'preload.cjs');
    if (!fs.existsSync(this.preloadPath)) {
      this.preloadPath = path.join(resolvedDir, 'preload.js');
    }

    this.chromeHtmlPath = path.join(resolvedDir, 'renderer', 'chrome.html');
    this.newtabHtmlPath = path.join(resolvedDir, 'renderer', 'newtab.html');
  }

  public async init(): Promise<void> {
    // Initialize Session Manager
    this.sessionManager = new SessionManager({
      userDataDir: this.userDataDir,
      onLog: (msg) => console.log(`[SessionEngine] ${msg}`),
    });

    await app.whenReady();
    await this.createMainWindow();
    this.registerShortcuts();
    this.setupIpc();
    this.setupAppLifecycle();
  }

  private async createMainWindow(): Promise<void> {
    this.mainWindow = new BrowserWindow({
      width: 1280,
      height: 840,
      minWidth: 700,
      minHeight: 450,
      frame: false, // Frameless for modern custom tab strip
      titleBarStyle: 'hidden',
      backgroundColor: '#0a0b0e',
      webPreferences: {
        // Main window shell itself doesn't need node integration
        nodeIntegration: false,
        contextIsolation: true,
      },
    });

    const [winWidth] = this.mainWindow.getSize();

    // 1. Create Toolbar WebContentsView (Top 78px)
    this.toolbarView = new WebContentsView({
      webPreferences: {
        preload: this.preloadPath,
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
      },
    });

    this.toolbarView.setBounds({
      x: 0,
      y: 0,
      width: winWidth,
      height: CHROME_TOOLBAR_HEIGHT,
    });

    // Add toolbar view to the window's content view hierarchy
    this.mainWindow.contentView.addChildView(this.toolbarView);

    // 2. Initialize Tab Manager
    this.tabManager = new TabManager(
      this.mainWindow,
      this.sessionManager!,
      this.newtabHtmlPath,
      () => this.broadcastStateUpdate()
    );

    // 3. Load Toolbar UI
    await this.toolbarView.webContents.loadFile(this.chromeHtmlPath);

    // 4. Restore saved session tabs (or default if fresh)
    await this.tabManager.restoreSessionTabs();

    // Handle Window Resizing
    this.mainWindow.on('resize', () => {
      if (!this.mainWindow || !this.toolbarView || !this.tabManager) return;
      const [w] = this.mainWindow.getSize();
      this.toolbarView.setBounds({
        x: 0,
        y: 0,
        width: w,
        height: CHROME_TOOLBAR_HEIGHT,
      });
      this.tabManager.updateAllViewBounds();
      this.broadcastStateUpdate();
    });

    this.mainWindow.on('maximize', () => this.broadcastStateUpdate());
    this.mainWindow.on('unmaximize', () => this.broadcastStateUpdate());

    // Second instance launched: bring this window to focus
    app.on('second-instance', () => {
      if (this.mainWindow) {
        if (this.mainWindow.isMinimized()) this.mainWindow.restore();
        this.mainWindow.focus();
      }
    });

    this.mainWindow.on('closed', () => {
      this.mainWindow = null;
      this.toolbarView = null;
    });
  }

  private registerShortcuts(): void {
    if (!this.mainWindow) return;

    // Ctrl+T: New tab
    globalShortcut.register('CommandOrControl+T', () => {
      this.tabManager?.createTab();
    });

    // Ctrl+W: Close active tab
    globalShortcut.register('CommandOrControl+W', () => {
      const active = this.tabManager?.getActiveTabInstance();
      if (active) {
        this.tabManager?.closeTab(active.id);
      }
    });

    // Ctrl+Shift+T: Reopen recently closed tab
    globalShortcut.register('CommandOrControl+Shift+T', () => {
      this.tabManager?.reopenRecentlyClosedTab();
    });

    // Ctrl+L: Focus address bar
    globalShortcut.register('CommandOrControl+L', () => {
      if (this.toolbarView) {
        this.toolbarView.webContents.focus();
        this.toolbarView.webContents.send(IPC_CHANNELS.FOCUS_ADDRESS_BAR);
      }
    });

    // Ctrl+Tab: Next tab
    globalShortcut.register('CommandOrControl+Tab', () => {
      this.tabManager?.cycleTab('next');
    });

    // Ctrl+Shift+Tab: Previous tab
    globalShortcut.register('CommandOrControl+Shift+Tab', () => {
      this.tabManager?.cycleTab('prev');
    });

    // Ctrl+R / F5: Reload active tab
    globalShortcut.register('CommandOrControl+R', () => {
      this.tabManager?.reload();
    });
    globalShortcut.register('F5', () => {
      this.tabManager?.reload();
    });
  }

  private setupIpc(): void {
    // UI Ready signal
    ipcMain.on(IPC_CHANNELS.UI_READY, () => {
      this.broadcastStateUpdate();
    });

    // Tab creation
    ipcMain.on(IPC_CHANNELS.TAB_CREATE, (_event, url) => {
      this.tabManager?.createTab(typeof url === 'string' ? url : undefined);
    });

    // Tab close
    ipcMain.on(IPC_CHANNELS.TAB_CLOSE, (_event, tabId) => {
      if (typeof tabId === 'string') {
        this.tabManager?.closeTab(tabId);
      }
    });

    // Tab switch
    ipcMain.on(IPC_CHANNELS.TAB_SWITCH, (_event, tabId) => {
      if (typeof tabId === 'string') {
        this.tabManager?.switchTab(tabId);
      }
    });

    // Navigation
    ipcMain.on(IPC_CHANNELS.TAB_NAVIGATE, (_event, url) => {
      if (typeof url === 'string') {
        this.tabManager?.navigateActiveTab(url);
      }
    });

    // History & Controls
    ipcMain.on(IPC_CHANNELS.TAB_GO_BACK, () => this.tabManager?.goBack());
    ipcMain.on(IPC_CHANNELS.TAB_GO_FORWARD, () => this.tabManager?.goForward());
    ipcMain.on(IPC_CHANNELS.TAB_RELOAD, () => this.tabManager?.reload());
    ipcMain.on(IPC_CHANNELS.TAB_STOP, () => this.tabManager?.stop());
    ipcMain.on(IPC_CHANNELS.TAB_REOPEN_CLOSED, () => this.tabManager?.reopenRecentlyClosedTab());

    // Window controls
    ipcMain.on(IPC_CHANNELS.WINDOW_MINIMIZE, () => this.mainWindow?.minimize());
    ipcMain.on(IPC_CHANNELS.WINDOW_MAXIMIZE, () => {
      if (this.mainWindow?.isMaximized()) {
        this.mainWindow.unmaximize();
      } else {
        this.mainWindow?.maximize();
      }
    });
    ipcMain.on(IPC_CHANNELS.WINDOW_CLOSE, () => this.mainWindow?.close());
  }

  private broadcastStateUpdate(): void {
    if (!this.toolbarView || !this.tabManager || !this.mainWindow) return;

    const baseState = this.tabManager.getUIState();
    const fullState: BrowserUIState = {
      ...baseState,
      isMaximized: this.mainWindow.isMaximized(),
    };

    try {
      this.toolbarView.webContents.send(IPC_CHANNELS.STATE_UPDATE, fullState);
    } catch {
      // Toolbar may be destroyed during exit
    }
  }

  private setupAppLifecycle(): void {
    // Critical shutdown handler: Flush pending session writes atomically
    app.on('before-quit', () => {
      console.log('[AeroChromium] App preparing for quit. Initiating synchronous session flush...');
      globalShortcut.unregisterAll();

      if (this.sessionManager) {
        // Prevent tab destruction from overwriting session with zero tabs!
        this.sessionManager.prepareForShutdown();
        this.sessionManager.flushSync();
      }

      if (this.tabManager) {
        this.tabManager.cleanupBeforeExit();
      }
    });

    app.on('window-all-closed', () => {
      app.quit();
    });
  }
}

// Start application
const aeroApp = new AeroChromiumApp();
aeroApp.init().catch((err) => {
  console.error('[AeroChromium] Fatal initialization error:', err);
});
