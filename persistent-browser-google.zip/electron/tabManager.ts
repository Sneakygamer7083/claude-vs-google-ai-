/**
 * AeroChromium Tab Manager
 * Manages WebContentsView instances, lifecycle events, lazy tab hydration,
 * and standard Chromium partition persistence for website cookies and logins.
 */

import { BaseWindow, session, WebContentsView } from 'electron';
import path from 'node:path';
import { SessionManager } from './sessionManager.js';
import { ClosedTabRecord, PersistedTab, RuntimeTabState } from './types.js';
import { INTERNAL_NEWTAB_URL, normalizeUserUrl } from './urlUtils.js';

export const CHROME_TOOLBAR_HEIGHT = 78;
export const PROFILE_PARTITION = 'persist:aero-chromium-profile';

interface TabInstance {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  view?: WebContentsView;
  isLazy: boolean;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  lastAccessed: number;
}

export class TabManager {
  private window: BaseWindow;
  private sessionManager: SessionManager;
  private tabs: Map<string, TabInstance> = new Map();
  private tabOrder: string[] = [];
  private activeTabId: string | null = null;
  private onStateChanged: () => void;
  private newtabHtmlPath: string;

  constructor(
    window: BaseWindow,
    sessionManager: SessionManager,
    newtabHtmlPath: string,
    onStateChanged: () => void
  ) {
    this.window = window;
    this.sessionManager = sessionManager;
    this.newtabHtmlPath = newtabHtmlPath;
    this.onStateChanged = onStateChanged;
  }

  /**
   * Initializes tabs from the persisted session.
   * Restores active tab immediately, while background tabs are restored
   * lazily to prevent memory spikes on startup.
   */
  public async restoreSessionTabs(): Promise<void> {
    const saved = this.sessionManager.loadSession();
    console.log(`[TabManager] Restoring ${saved.tabs.length} tabs from saved session...`);

    // Register all tabs in order
    for (const savedTab of saved.tabs) {
      this.tabs.set(savedTab.id, {
        id: savedTab.id,
        url: savedTab.url,
        title: savedTab.title || 'New Tab',
        favicon: savedTab.favicon,
        isLazy: savedTab.id !== saved.activeTabId,
        isLoading: false,
        canGoBack: false,
        canGoForward: false,
        lastAccessed: savedTab.lastAccessed || Date.now(),
      });
      this.tabOrder.push(savedTab.id);
    }

    // Determine target active tab
    const targetActiveId =
      saved.activeTabId && this.tabs.has(saved.activeTabId)
        ? saved.activeTabId
        : this.tabOrder[0];

    // Immediately create and load the active tab's WebContentsView
    await this.activateTab(targetActiveId, true);

    this.sessionManager.setRestorationComplete(true);
    this.notifyStateChanged();
  }

  /**
   * Creates a new tab.
   * If activate = true, it becomes the active tab immediately.
   */
  public async createTab(
    initialUrl = INTERNAL_NEWTAB_URL,
    activate = true,
    title = 'New Tab'
  ): Promise<string> {
    const tabId = `tab-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    const normalized = normalizeUserUrl(initialUrl);

    const instance: TabInstance = {
      id: tabId,
      url: normalized,
      title: title,
      isLazy: false,
      isLoading: false,
      canGoBack: false,
      canGoForward: false,
      lastAccessed: Date.now(),
    };

    this.tabs.set(tabId, instance);
    this.tabOrder.push(tabId);

    if (activate || !this.activeTabId) {
      await this.activateTab(tabId, true);
    }

    this.persistCurrentSession(true);
    this.notifyStateChanged();
    return tabId;
  }

  /**
   * Switches to an existing tab. Hydrates view if tab was lazy.
   */
  public async switchTab(tabId: string): Promise<void> {
    if (!this.tabs.has(tabId)) return;
    if (this.activeTabId === tabId) return;

    await this.activateTab(tabId, false);
    this.persistCurrentSession(false);
    this.notifyStateChanged();
  }

  /**
   * Activates a tab:
   * - Hides/detaches previous active tab view
   * - Hydrates target tab view if lazy
   * - Attaches view to window.contentView
   * - Adjusts layout bounds
   */
  private async activateTab(tabId: string, isInitial = false): Promise<void> {
    const target = this.tabs.get(tabId);
    if (!target) return;

    const prevActiveId = this.activeTabId;
    if (prevActiveId && prevActiveId !== tabId) {
      const prev = this.tabs.get(prevActiveId);
      if (prev?.view) {
        try {
          this.window.contentView.removeChildView(prev.view);
        } catch {
          // View may already have been removed
        }
      }
    }

    this.activeTabId = tabId;
    target.lastAccessed = Date.now();

    // Hydrate view if not yet created or lazy
    if (!target.view) {
      target.view = this.createWebContentsView(target);
      target.isLazy = false;
      await this.loadUrlInView(target, target.url);
    } else if (target.isLazy) {
      target.isLazy = false;
      await this.loadUrlInView(target, target.url);
    }

    // Attach to BaseWindow
    try {
      this.window.contentView.addChildView(target.view);
      this.updateViewBounds(target.view);
    } catch (err) {
      console.error(`[TabManager] Failed to attach view for tab ${tabId}:`, err);
    }

    // Focus target view
    try {
      target.view.webContents.focus();
    } catch {
      // ignore
    }

    if (!isInitial) {
      this.persistCurrentSession(false);
    }
  }

  /**
   * Closes a tab:
   * - Records it for Ctrl+Shift+T restoration
   * - Disposes of WebContentsView
   * - If closing active tab, switches to adjacent tab
   * - If closing last tab, opens fresh New Tab
   */
  public async closeTab(tabId: string): Promise<void> {
    if (!this.tabs.has(tabId)) return;
    if (this.sessionManager.isShuttingDown()) {
      // During application shutdown, do not destroy session tabs!
      return;
    }

    const target = this.tabs.get(tabId)!;

    // Record in closed history stack
    this.sessionManager.recordClosedTab({
      url: target.url,
      title: target.title,
      favicon: target.favicon,
    });

    // Cleanup view
    if (target.view) {
      try {
        this.window.contentView.removeChildView(target.view);
        // Destroy webContents
        (target.view.webContents as unknown as { destroy?: () => void }).destroy?.();
      } catch (err) {
        console.warn(`[TabManager] Error destroying view for tab ${tabId}:`, err);
      }
      target.view = undefined;
    }

    const closedIndex = this.tabOrder.indexOf(tabId);
    this.tabs.delete(tabId);
    this.tabOrder = this.tabOrder.filter((id) => id !== tabId);

    // If active tab was closed, pick adjacent tab
    if (this.activeTabId === tabId) {
      if (this.tabOrder.length > 0) {
        const nextIndex = Math.min(closedIndex, this.tabOrder.length - 1);
        const nextId = this.tabOrder[nextIndex];
        await this.activateTab(nextId, false);
      } else {
        // Last tab closed: open sensible default new tab
        await this.createTab(INTERNAL_NEWTAB_URL, true);
        return;
      }
    }

    this.persistCurrentSession(true);
    this.notifyStateChanged();
  }

  /**
   * Reopens the most recently closed tab (Ctrl+Shift+T).
   */
  public async reopenRecentlyClosedTab(): Promise<void> {
    const record: ClosedTabRecord | null = this.sessionManager.popRecentlyClosedTab();
    if (!record) return;

    await this.createTab(record.url, true, record.title);
  }

  /**
   * Cycle to next / previous tab (Ctrl+Tab / Ctrl+Shift+Tab)
   */
  public async cycleTab(direction: 'next' | 'prev'): Promise<void> {
    if (this.tabOrder.length <= 1 || !this.activeTabId) return;
    const currentIndex = this.tabOrder.indexOf(this.activeTabId);
    if (currentIndex === -1) return;

    let nextIndex = 0;
    if (direction === 'next') {
      nextIndex = (currentIndex + 1) % this.tabOrder.length;
    } else {
      nextIndex = (currentIndex - 1 + this.tabOrder.length) % this.tabOrder.length;
    }

    await this.switchTab(this.tabOrder[nextIndex]);
  }

  /**
   * Navigates the current active tab to a URL or search query.
   */
  public async navigateActiveTab(input: string): Promise<void> {
    if (!this.activeTabId) return;
    const target = this.tabs.get(this.activeTabId);
    if (!target) return;

    const normalized = normalizeUserUrl(input);
    target.url = normalized;

    if (!target.view) {
      target.view = this.createWebContentsView(target);
      this.window.contentView.addChildView(target.view);
      this.updateViewBounds(target.view);
    }

    await this.loadUrlInView(target, normalized);
    this.persistCurrentSession(true);
    this.notifyStateChanged();
  }

  public goBack(): void {
    const active = this.getActiveTabInstance();
    if (active?.view?.webContents.canGoBack()) {
      active.view.webContents.goBack();
    }
  }

  public goForward(): void {
    const active = this.getActiveTabInstance();
    if (active?.view?.webContents.canGoForward()) {
      active.view.webContents.goForward();
    }
  }

  public reload(): void {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      active.view.webContents.reload();
    }
  }

  public stop(): void {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      active.view.webContents.stop();
    }
  }

  /**
   * Updates WebContentsView bounds when window resizes.
   */
  public updateAllViewBounds(): void {
    const active = this.getActiveTabInstance();
    if (active?.view) {
      this.updateViewBounds(active.view);
    }
  }

  private updateViewBounds(view: WebContentsView): void {
    const [winWidth, winHeight] = this.window.getSize();
    const contentY = CHROME_TOOLBAR_HEIGHT;
    const contentHeight = Math.max(0, winHeight - contentY);

    try {
      view.setBounds({
        x: 0,
        y: contentY,
        width: winWidth,
        height: contentHeight,
      });
    } catch (err) {
      console.error('[TabManager] Error setting view bounds:', err);
    }
  }

  /**
   * Creates an isolated, sandboxed WebContentsView using the persistent profile session.
   */
  private createWebContentsView(tab: TabInstance): WebContentsView {
    // Persistent profile session across restarts: preserves cookies, logins, localStorage
    const persistentSession = session.fromPartition(PROFILE_PARTITION);

    const view = new WebContentsView({
      webPreferences: {
        session: persistentSession,
        nodeIntegration: false,
        contextIsolation: true,
        sandbox: true,
        webSecurity: true,
        allowRunningInsecureContent: false,
        backgroundThrottling: false,
      },
    });

    const wc = view.webContents;

    // Handle navigation events & URL commitment
    wc.on('did-start-loading', () => {
      tab.isLoading = true;
      this.notifyStateChanged();
    });

    wc.on('did-stop-loading', () => {
      tab.isLoading = false;
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.notifyStateChanged();
    });

    // Committed main frame URL change (clicking links, redirects)
    wc.on('did-navigate', (_event, url) => {
      if (url.startsWith('file://') && url.includes('newtab.html')) {
        tab.url = INTERNAL_NEWTAB_URL;
        tab.title = 'New Tab';
      } else {
        tab.url = url;
      }
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });

    // In-page navigation: SPAs (Next.js, React Router, GitHub repo navigation)
    wc.on('did-navigate-in-page', (_event, url) => {
      tab.url = url;
      tab.canGoBack = wc.canGoBack();
      tab.canGoForward = wc.canGoForward();
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });

    // Page title updates
    wc.on('page-title-updated', (_event, title) => {
      if (tab.url === INTERNAL_NEWTAB_URL) {
        tab.title = 'New Tab';
      } else {
        tab.title = title || 'Untitled';
      }
      this.persistCurrentSession(false);
      this.notifyStateChanged();
    });

    // Favicon updates
    wc.on('page-favicon-updated', (_event, favicons) => {
      if (favicons && favicons.length > 0) {
        tab.favicon = favicons[0];
        this.notifyStateChanged();
      }
    });

    // Open new-window links (target="_blank" or window.open) inside new browser tabs
    wc.setWindowOpenHandler((details) => {
      this.createTab(details.url, true);
      return { action: 'deny' };
    });

    // Handle renderer crashes safely
    wc.on('render-process-gone', (_event, details) => {
      console.error(`[TabManager] Tab ${tab.id} crashed: ${details.reason}`);
      tab.isLoading = false;
      this.notifyStateChanged();
    });

    return view;
  }

  private async loadUrlInView(tab: TabInstance, urlToLoad: string): Promise<void> {
    if (!tab.view) return;

    try {
      if (urlToLoad === INTERNAL_NEWTAB_URL) {
        await tab.view.webContents.loadFile(this.newtabHtmlPath);
        tab.title = 'New Tab';
      } else {
        await tab.view.webContents.loadURL(urlToLoad);
      }
    } catch (err: unknown) {
      const errorObj = err as { code?: string; message?: string };
      // Ignore user-cancelled navigation (e.g. ERR_ABORTED when navigating quickly)
      if (errorObj?.code !== 'ERR_ABORTED') {
        console.warn(`[TabManager] Navigation notice for ${urlToLoad}:`, errorObj?.message || err);
      }
    }
  }

  private persistCurrentSession(immediate = false): void {
    const list: PersistedTab[] = this.tabOrder
      .map((id) => this.tabs.get(id))
      .filter((t): t is TabInstance => !!t)
      .map((t) => ({
        id: t.id,
        url: t.url,
        title: t.title,
        favicon: t.favicon,
        lastAccessed: t.lastAccessed,
      }));

    if (list.length > 0 && this.activeTabId) {
      this.sessionManager.scheduleSave(list, this.activeTabId, immediate);
    }
  }

  public getActiveTabInstance(): TabInstance | null {
    if (!this.activeTabId) return null;
    return this.tabs.get(this.activeTabId) ?? null;
  }

  public getUIState(): {
    tabs: RuntimeTabState[];
    activeTabId: string;
    canGoBack: boolean;
    canGoForward: boolean;
    isLoading: boolean;
    currentUrl: string;
    sessionStats: {
      lastSaved: string;
      tabsCount: number;
      closedTabsCount: number;
    };
  } {
    const active = this.getActiveTabInstance();
    const runtimeTabs: RuntimeTabState[] = this.tabOrder
      .map((id) => this.tabs.get(id))
      .filter((t): t is TabInstance => !!t)
      .map((t) => ({
        id: t.id,
        url: t.url,
        title: t.title,
        favicon: t.favicon,
        lastAccessed: t.lastAccessed,
        isLoading: t.isLoading,
        canGoBack: t.canGoBack,
        canGoForward: t.canGoForward,
        isLazy: t.isLazy,
      }));

    const cached = this.sessionManager.getCachedSession();

    return {
      tabs: runtimeTabs,
      activeTabId: this.activeTabId || '',
      canGoBack: active?.canGoBack ?? false,
      canGoForward: active?.canGoForward ?? false,
      isLoading: active?.isLoading ?? false,
      currentUrl: active?.url ?? INTERNAL_NEWTAB_URL,
      sessionStats: {
        lastSaved: cached?.lastSaved || new Date().toISOString(),
        tabsCount: runtimeTabs.length,
        closedTabsCount: this.sessionManager.getClosedTabsCount(),
      },
    };
  }

  private notifyStateChanged(): void {
    this.onStateChanged();
  }

  /**
   * Called during application shutdown to safely release views
   */
  public cleanupBeforeExit(): void {
    for (const tab of this.tabs.values()) {
      if (tab.view) {
        try {
          this.window.contentView.removeChildView(tab.view);
        } catch {
          // ignore
        }
      }
    }
  }
}
