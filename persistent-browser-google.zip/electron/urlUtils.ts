/**
 * AeroChromium URL Utilities
 * Handles URL normalization, search queries, and safety checks.
 */

export const INTERNAL_NEWTAB_URL = 'browser://newtab';
export const DEFAULT_SEARCH_ENGINE = 'https://www.google.com/search?q=';

/**
 * Validates whether a scheme is allowed for user navigation or session restoration.
 * Explicitly rejects unsafe schemes such as javascript:, file:, data:, or vbscript:.
 */
export function isAllowedProtocol(urlStr: string): boolean {
  if (!urlStr || typeof urlStr !== 'string') return false;
  const trimmed = urlStr.trim();
  if (trimmed === INTERNAL_NEWTAB_URL) return true;

  try {
    const parsed = new URL(trimmed);
    return parsed.protocol === 'http:' || parsed.protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * Normalizes user input from the address bar into either:
 * 1. An internal browser page (browser://newtab)
 * 2. A direct URL (prepended with https:// if scheme is missing)
 * 3. A search query routed through Google Search
 */
export function normalizeUserUrl(input: string): string {
  if (!input || typeof input !== 'string') {
    return INTERNAL_NEWTAB_URL;
  }

  const trimmed = input.trim();
  if (!trimmed) {
    return INTERNAL_NEWTAB_URL;
  }

  // Handle internal URLs
  if (trimmed === 'browser://newtab' || trimmed === 'about:blank' || trimmed.toLowerCase() === 'newtab') {
    return INTERNAL_NEWTAB_URL;
  }

  // Prevent dangerous protocol injection
  const lower = trimmed.toLowerCase();
  if (
    lower.startsWith('javascript:') ||
    lower.startsWith('file:') ||
    lower.startsWith('data:') ||
    lower.startsWith('vbscript:')
  ) {
    return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
  }

  // Check if explicit http:// or https://
  if (lower.startsWith('http://') || lower.startsWith('https://')) {
    try {
      new URL(trimmed);
      return trimmed;
    } catch {
      return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
    }
  }

  // Check if input looks like a domain name (e.g. "github.com", "sub.domain.org/path", "localhost:3000")
  const hasWhitespace = /\s/.test(trimmed);
  const domainPattern = /^([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(:\d+)?(\/.*)?$/;
  const localhostPattern = /^localhost(:\d+)?(\/.*)?$/;
  const ipPattern = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?(\/.*)?$/;

  if (!hasWhitespace && (domainPattern.test(trimmed) || localhostPattern.test(trimmed) || ipPattern.test(trimmed))) {
    return `https://${trimmed}`;
  }

  // Default to search query
  return `${DEFAULT_SEARCH_ENGINE}${encodeURIComponent(trimmed)}`;
}

/**
 * Sanitizes URLs saved into or loaded from the session file.
 * Returns fallback newtab if URL is invalid or unsafe.
 */
export function sanitizePersistedUrl(url: string | unknown): string {
  if (typeof url !== 'string' || !url) {
    return INTERNAL_NEWTAB_URL;
  }
  const trimmed = url.trim();
  if (trimmed === INTERNAL_NEWTAB_URL) {
    return INTERNAL_NEWTAB_URL;
  }
  if (isAllowedProtocol(trimmed)) {
    return trimmed;
  }
  return INTERNAL_NEWTAB_URL;
}
