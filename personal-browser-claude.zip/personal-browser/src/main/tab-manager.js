'use strict';
// Owns the real browser views. The pure tab state (tab-state.js) is the single source of truth;
// this class only keeps WebContentsViews in sync with it and feeds navigation events back in.

const { WebContentsView } = require('electron');
const config = require('./config');
const T = require('./tab-state');
const { normalizeWebUrl, normalizeInput, isSafeFaviconUrl, sameFileUrl } = require('./url-utils');
const { confirmExternalProtocol } = require('./security');

function classifyInternal(url) {
  if (sameFileUrl(url, config.NEWTAB_URL)) return 'newtab';
  if (sameFileUrl(url, config.ERROR_URL)) return 'error';
  return null;
}

function displayTitle(tab) {
  if (tab.title) return tab.title;
  if (!tab.url) return 'New Tab';
  try {
    return new URL(tab.url).hostname;
  } catch {
    return tab.url;
  }
}

class TabManager {
  constructor({ window, ui, session, newId, onPersist, toast }) {
    this.win = window;
    this.ui = ui;
    this.session = session;
    this.newId = newId;
    this.onPersist = onPersist || (() => {});
    this._toast = toast || (() => {});
    this.state = T.createState();
    this.runtime = new Map(); // tab id -> { view, cleanup[], loading, canGoBack, canGoForward, errored }
    this.attached = null;
    this.shuttingDown = false;
    this.htmlFullscreen = false;
    this.emitTimer = null;
    this.seq = 0;
  }

  // ---------- lifecycle ----------

  /** Builds tabs from a validated session (or a single blank tab) and shows the active one. */
  restore(session) {
    if (session) {
      this.state = T.fromSession(session);
    } else {
      this.state = T.addTab(T.createState(), { id: this.newId(), url: null, title: 'New Tab' });
    }
    // Background tabs get NO view yet: they appear in the tab strip and load when first selected.
    for (const t of this.state.tabs) this.runtime.set(t.id, this._blankRuntime());
    this._showActive(false);
    this._flushEmit();
  }

  beginShutdown() {
    this.shuttingDown = true;
  }

  ownsContents(wc) {
    for (const rt of this.runtime.values()) {
      if (rt.view && rt.view.webContents === wc) return true;
    }
    return false;
  }

  toSession() {
    return T.toSession(this.state);
  }

  snapshot() {
    return {
      seq: ++this.seq,
      activeId: this.state.activeId,
      tabs: this.state.tabs.map((t) => {
        const rt = this.runtime.get(t.id) || {};
        return {
          id: t.id,
          title: displayTitle(t),
          url: t.url,
          favicon: t.favicon,
          loading: !!rt.loading,
          canGoBack: !!rt.canGoBack,
          canGoForward: !!rt.canGoForward,
        };
      }),
    };
  }

  // ---------- public commands ----------

  createTab({ url = null, activate = true, afterActive = false } = {}) {
    if (this.shuttingDown) return null;
    if (this.state.tabs.length >= config.MAX_TABS) {
      this._toast(`Tab limit reached (${config.MAX_TABS}).`);
      return null;
    }
    const safe = url ? normalizeWebUrl(url) : null;
    if (url && !safe) return null;
    const id = this.newId();
    const index = afterActive ? T.indexOf(this.state, this.state.activeId) + 1 : undefined;
    this.state = T.addTab(this.state, { id, url: safe, title: safe ? '' : 'New Tab', activate, index });
    this.runtime.set(id, this._blankRuntime());
    this._ensureView(id);
    if (activate) {
      this._attach(id);
      this._focusContent(id);
    }
    this._emit();
    this.onPersist();
    return id;
  }

  closeTab(id) {
    if (this.shuttingDown || !T.getTab(this.state, id)) return;
    const wasActive = this.state.activeId === id;
    const result = T.closeTab(this.state, id, this.newId());
    this.state = result.state;
    this._destroyRuntime(id);
    for (const t of this.state.tabs) {
      if (!this.runtime.has(t.id)) this.runtime.set(t.id, this._blankRuntime());
    }
    if (wasActive) {
      this._ensureView(this.state.activeId);
      this._attach(this.state.activeId);
      this._focusContent(this.state.activeId);
    }
    this._emit();
    this.onPersist();
  }

  closeActiveTab() {
    this.closeTab(this.state.activeId);
  }

  selectTab(id) {
    if (this.shuttingDown || !T.getTab(this.state, id)) return;
    const next = T.selectTab(this.state, id);
    if (next === this.state) return;
    this.state = next;
    this._ensureView(id); // lazily-restored tabs load here
    this._attach(id);
    this._focusContent(id);
    this._emit();
    this.onPersist();
  }

  selectRelative(dir) {
    const next = T.cycleTab(this.state, dir);
    if (next.activeId !== this.state.activeId) this.selectTab(next.activeId);
  }

  selectNumber(n) {
    const next = T.selectByNumber(this.state, n);
    if (next.activeId !== this.state.activeId) this.selectTab(next.activeId);
  }

  moveTab(id, index) {
    if (this.shuttingDown) return;
    const next = T.moveTab(this.state, id, index);
    if (next === this.state) return;
    this.state = next;
    this._emit();
    this.onPersist();
  }

  reopenClosed() {
    if (this.shuttingDown) return;
    const { state, tab } = T.reopenClosed(this.state, this.newId());
    if (!tab) return;
    this.state = state;
    this.runtime.set(tab.id, this._blankRuntime());
    this._ensureView(tab.id);
    this._attach(tab.id);
    this._focusContent(tab.id);
    this._emit();
    this.onPersist();
  }

  /** Address-bar submit: URL or search query for the active tab. */
  navigate(text) {
    const target = normalizeInput(text, config.SEARCH_URL);
    const rt = this.runtime.get(this.state.activeId);
    if (!target || !rt || !rt.view) return;
    rt.view.webContents.loadURL(target.url).catch(() => {});
    rt.view.webContents.focus();
  }

  goBack() {
    const wc = this._activeContents();
    if (wc && wc.navigationHistory.canGoBack()) wc.navigationHistory.goBack();
  }

  goForward() {
    const wc = this._activeContents();
    if (wc && wc.navigationHistory.canGoForward()) wc.navigationHistory.goForward();
  }

  reload({ hard = false } = {}) {
    const id = this.state.activeId;
    const rt = this.runtime.get(id);
    const tab = T.getTab(this.state, id);
    if (!rt || !rt.view) return;
    const wc = rt.view.webContents;
    if (rt.errored && tab.url) wc.loadURL(tab.url).catch(() => {});
    else if (hard) wc.reloadIgnoringCache();
    else wc.reload();
  }

  stop() {
    const wc = this._activeContents();
    if (wc) wc.stop();
  }

  openDevTools() {
    const wc = this._activeContents();
    if (wc) wc.openDevTools({ mode: 'detach' });
  }

  focusAddress() {
    if (this.ui.isDestroyed()) return;
    this.ui.focus();
    this.ui.send('browser:focus-address');
  }

  layout() {
    if (!this.attached || this.win.isDestroyed()) return;
    const [w, h] = this.win.getContentSize();
    const top = this.htmlFullscreen ? 0 : config.CHROME_HEIGHT;
    this.attached.setBounds({ x: 0, y: top, width: Math.max(0, w), height: Math.max(0, h - top) });
  }

  /** Keyboard shortcuts, fed from before-input-event of the UI and of every tab. */
  handleKey(event, input) {
    if (input.type !== 'keyDown' || this.shuttingDown) return false;
    const key = String(input.key || '').toLowerCase();
    const ctrl = !!input.control;
    const shift = !!input.shift;
    const alt = !!input.alt;
    let handled = true;

    if (ctrl && !alt && key === 't' && !shift) this.createTab();
    else if (ctrl && !alt && key === 't' && shift) this.reopenClosed();
    else if (ctrl && !alt && key === 'w' && !shift) this.closeActiveTab();
    else if ((ctrl && !alt && key === 'l') || (alt && !ctrl && key === 'd') || key === 'f6') this.focusAddress();
    else if (ctrl && key === 'tab') this.selectRelative(shift ? -1 : 1);
    else if (ctrl && !alt && key === 'pagedown') this.selectRelative(1);
    else if (ctrl && !alt && key === 'pageup') this.selectRelative(-1);
    else if (ctrl && !alt && key === 'r') this.reload({ hard: shift });
    else if (key === 'f5') this.reload({ hard: ctrl });
    else if (alt && !ctrl && key === 'arrowleft') this.goBack();
    else if (alt && !ctrl && key === 'arrowright') this.goForward();
    else if ((ctrl && shift && key === 'i') || key === 'f12') this.openDevTools();
    else if (ctrl && !alt && !shift && /^[1-9]$/.test(key)) this.selectNumber(Number(key));
    else handled = false;

    if (handled) event.preventDefault();
    return handled;
  }

  // ---------- internals ----------

  _blankRuntime() {
    return { view: null, cleanup: [], loading: false, canGoBack: false, canGoForward: false, errored: false };
  }

  _activeContents() {
    const rt = this.runtime.get(this.state.activeId);
    return rt && rt.view ? rt.view.webContents : null;
  }

  _showActive(focus) {
    const id = this.state.activeId;
    this._ensureView(id);
    this._attach(id);
    if (focus) this._focusContent(id);
  }

  _focusContent(id) {
    const tab = T.getTab(this.state, id);
    const rt = this.runtime.get(id);
    if (!tab || !rt || !rt.view) return;
    if (tab.url) rt.view.webContents.focus();
    else this.focusAddress(); // blank new-tab page: type straight into the address bar
  }

  _attach(id) {
    const rt = this.runtime.get(id);
    if (!rt || !rt.view || this.win.isDestroyed()) return;
    if (this.attached && this.attached !== rt.view) {
      try {
        this.win.contentView.removeChildView(this.attached);
      } catch {
        /* already removed */
      }
      this.attached = null;
    }
    if (this.attached !== rt.view) {
      this.win.contentView.addChildView(rt.view);
      this.attached = rt.view;
    }
    this.layout();
  }

  _ensureView(id) {
    const rt = this.runtime.get(id);
    if (!rt) return null;
    if (rt.view) return rt.view;
    const view = new WebContentsView({
      webPreferences: {
        session: this.session,
        sandbox: true,
        contextIsolation: true,
        nodeIntegration: false,
        nodeIntegrationInSubFrames: false,
        webSecurity: true,
        allowRunningInsecureContent: false,
        webviewTag: false,
        // No preload: websites (and our own new-tab/error pages) get no privileged API at all.
      },
    });
    rt.view = view;
    this._wire(id, rt);
    const tab = T.getTab(this.state, id);
    const wc = view.webContents;
    if (tab.url) wc.loadURL(tab.url).catch(() => {});
    else wc.loadFile(config.NEWTAB_PATH).catch(() => {});
    return view;
  }

  _wire(id, rt) {
    const wc = rt.view.webContents;
    const on = (ev, fn) => {
      wc.on(ev, fn);
      rt.cleanup.push(() => wc.removeListener(ev, fn));
    };
    const syncNav = () => {
      try {
        rt.canGoBack = wc.navigationHistory.canGoBack();
        rt.canGoForward = wc.navigationHistory.canGoForward();
      } catch {
        /* contents going away */
      }
    };

    // Links that ask for a new window become tabs. The new tab is a plain navigation: there is no
    // window.opener relationship and no privileged API.
    wc.setWindowOpenHandler(({ url, disposition }) => {
      if (this.shuttingDown) return { action: 'deny' };
      if (normalizeWebUrl(url)) {
        this.createTab({ url, activate: disposition !== 'background-tab', afterActive: true });
      } else {
        confirmExternalProtocol(url, this.win);
      }
      return { action: 'deny' };
    });

    on('did-start-loading', () => {
      rt.loading = true;
      syncNav();
      this._emit();
    });
    on('did-stop-loading', () => {
      rt.loading = false;
      syncNav();
      this._emit();
    });
    // Full (cross-document) main-frame navigation committed.
    on('did-navigate', (event, url) => {
      this._onCommitted(id, rt, event.url || url);
      this._update(id, { favicon: null }, false);
      syncNav();
      this._emit();
    });
    // Same-document navigation (hash changes, history.pushState / SPA routes).
    on('did-navigate-in-page', (event, url, isMainFrame) => {
      const main = typeof event.isMainFrame === 'boolean' ? event.isMainFrame : isMainFrame;
      if (!main) return;
      this._onCommitted(id, rt, event.url || url);
      syncNav();
      this._emit();
    });
    on('page-title-updated', (_event, title) => this._update(id, { title }, true));
    on('page-favicon-updated', (_event, favicons) => {
      const icon = (favicons || []).find(isSafeFaviconUrl);
      this._update(id, { favicon: icon || null }, false);
    });
    on('did-fail-load', (_event, code, desc, validatedUrl, isMainFrame) => {
      if (!isMainFrame || code === -3 /* aborted */ || this.shuttingDown) return;
      this._showError(id, rt, { code, desc, url: validatedUrl });
    });
    on('render-process-gone', (_event, details) => {
      if (this.shuttingDown) return;
      const tab = T.getTab(this.state, id);
      if (!tab) return;
      if (tab.url) this._showError(id, rt, { code: 'CRASHED', desc: `The page stopped working (${details.reason}).`, url: tab.url });
      else wc.loadFile(config.NEWTAB_PATH).catch(() => {});
    });

    // Websites may only navigate to http(s). Anything else is blocked (mailto:/tel: ask first).
    const guard = (event, legacyUrl) => {
      const url = event.url || legacyUrl;
      if (classifyInternal(url) || normalizeWebUrl(url)) return;
      event.preventDefault();
      confirmExternalProtocol(url, this.win);
    };
    on('will-navigate', guard);
    on('will-redirect', guard);

    on('before-input-event', (event, input) => this.handleKey(event, input));
    on('enter-html-full-screen', () => {
      if (this.attached !== rt.view) return;
      this.htmlFullscreen = true;
      this.win.setFullScreen(true);
      this.layout();
    });
    on('leave-html-full-screen', () => {
      if (!this.htmlFullscreen) return;
      this.htmlFullscreen = false;
      this.win.setFullScreen(false);
      this.layout();
    });
  }

  _onCommitted(id, rt, rawUrl) {
    const kind = classifyInternal(rawUrl);
    if (kind === 'newtab') {
      rt.errored = false;
      this._update(id, { url: null, title: 'New Tab' }, true);
      return;
    }
    if (kind === 'error') {
      rt.errored = true; // keep the failed URL as the tab's URL so reload/restore retry it
      return;
    }
    const safe = normalizeWebUrl(rawUrl);
    if (!safe) return;
    rt.errored = false;
    this._update(id, { url: safe }, true);
  }

  _showError(id, rt, { code, desc, url }) {
    const safe = normalizeWebUrl(url);
    if (!safe || !rt.view || rt.view.webContents.isDestroyed()) return;
    this._update(id, { url: safe }, true);
    rt.errored = true;
    rt.view.webContents
      .loadFile(config.ERROR_PATH, { query: { code: String(code), desc: String(desc || ''), url: safe } })
      .catch(() => {});
  }

  _update(id, patch, persist) {
    const next = T.updateTab(this.state, id, patch);
    if (next === this.state) return;
    this.state = next;
    this._emit();
    if (persist && !this.shuttingDown) this.onPersist();
  }

  _destroyRuntime(id) {
    const rt = this.runtime.get(id);
    if (!rt) return;
    this.runtime.delete(id);
    if (!rt.view) return;
    for (const fn of rt.cleanup) {
      try {
        fn();
      } catch {
        /* ignore */
      }
    }
    rt.cleanup = [];
    if (this.attached === rt.view) {
      try {
        this.win.contentView.removeChildView(rt.view);
      } catch {
        /* ignore */
      }
      this.attached = null;
    }
    const wc = rt.view.webContents;
    if (!wc.isDestroyed()) {
      wc.setWindowOpenHandler(() => ({ action: 'deny' }));
      wc.close();
    }
    rt.view = null;
  }

  _emit() {
    if (this.emitTimer) return;
    this.emitTimer = setTimeout(() => {
      this.emitTimer = null;
      this._flushEmit();
    }, 16);
  }

  _flushEmit() {
    if (this.win.isDestroyed() || this.ui.isDestroyed()) return;
    const snap = this.snapshot();
    this.ui.send('browser:state', snap);
    const active = snap.tabs.find((t) => t.id === snap.activeId);
    this.win.setTitle(active ? `${active.title} - ${config.APP_NAME}` : config.APP_NAME);
  }
}

module.exports = { TabManager, classifyInternal, displayTitle };
