'use strict';
// Debounced saving with a hard "enabled" gate and a one-way shutdown flush.

class SessionPersistence {
  /**
   * @param {{saveSync:Function}} store
   * @param {() => object} getSession  returns the current session snapshot
   */
  constructor({ store, getSession, debounceMs = 400, logger = console }) {
    this.store = store;
    this.getSession = getSession;
    this.debounceMs = debounceMs;
    this.logger = logger;
    this.enabled = false; // stays false until the saved session has been restored
    this.closed = false; // set at shutdown; nothing is ever written afterwards
    this.timer = null;
    this.lastKey = null;
  }

  enable() {
    if (!this.closed) this.enabled = true;
  }

  /** Coalesces rapid changes: at most one write per debounce window. */
  schedule() {
    if (!this.enabled || this.closed || this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this._write();
    }, this.debounceMs);
  }

  _write() {
    if (!this.enabled || this.closed) return false;
    try {
      const session = this.getSession();
      const key = JSON.stringify({ a: session.activeTabId, t: session.tabs });
      if (key === this.lastKey) return false; // nothing changed
      this.store.saveSync(session);
      this.lastKey = key;
      return true;
    } catch (err) {
      this.logger.error('[session] save failed:', err && err.message);
      return false;
    }
  }

  flushSync() {
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    return this._write();
  }

  /** Final flush at shutdown, then permanently stop writing (so teardown cannot overwrite it). */
  flushAndClose() {
    this.flushSync();
    this.closed = true;
    this.enabled = false;
  }
}

module.exports = { SessionPersistence };
