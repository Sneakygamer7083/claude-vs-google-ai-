'use strict';
// IPC surface for the TRUSTED browser UI only. Every call is sender-checked and input-validated.
const config = require('./config');
const { ID_RE } = require('./tab-state');
const { sameFileUrl, MAX_URL_LENGTH } = require('./url-utils');

const isId = (v) => typeof v === 'string' && ID_RE.test(v);
const isText = (v) => typeof v === 'string' && v.length <= MAX_URL_LENGTH;
const isIndex = (v) => Number.isInteger(v) && v >= 0 && v < 10000;

function registerIpc({ ipcMain, ui, manager }) {
  const trusted = (event) => {
    const frame = event.senderFrame;
    return !!frame && event.sender === ui && frame === ui.mainFrame && sameFileUrl(frame.url, config.UI_URL);
  };

  const reg = (channel, check, run) => {
    ipcMain.handle(channel, (event, ...args) => {
      if (!trusted(event)) throw new Error('IPC rejected: untrusted sender');
      if (!check(...args)) throw new Error(`IPC rejected: invalid arguments for ${channel}`);
      return run(...args);
    });
  };

  reg('browser:get-state', (...a) => a.length === 0, () => manager.snapshot());
  reg('browser:new-tab', (...a) => a.length === 0, () => void manager.createTab());
  reg('browser:close-tab', (id, ...r) => r.length === 0 && isId(id), (id) => void manager.closeTab(id));
  reg('browser:select-tab', (id, ...r) => r.length === 0 && isId(id), (id) => void manager.selectTab(id));
  reg('browser:move-tab', (id, i, ...r) => r.length === 0 && isId(id) && isIndex(i), (id, i) => void manager.moveTab(id, i));
  reg('browser:navigate', (t, ...r) => r.length === 0 && isText(t), (t) => void manager.navigate(t));
  reg('browser:back', (...a) => a.length === 0, () => void manager.goBack());
  reg('browser:forward', (...a) => a.length === 0, () => void manager.goForward());
  reg('browser:reload', (...a) => a.length === 0, () => void manager.reload());
  reg('browser:stop', (...a) => a.length === 0, () => void manager.stop());
  reg('browser:reopen-closed', (...a) => a.length === 0, () => void manager.reopenClosed());
}

module.exports = { registerIpc };
