'use strict';
// Pure URL helpers (no Electron). Everything that crosses a trust boundary goes through here.

const MAX_URL_LENGTH = 8192;
const MAX_FAVICON_LENGTH = 200000;

/** Returns a normalized http(s) URL string, or null if the value is not a safe web URL. */
function normalizeWebUrl(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > MAX_URL_LENGTH) return null;
  let u;
  try {
    u = new URL(value);
  } catch {
    return null;
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
  if (!u.hostname) return null;
  return u.href;
}

function isLocalOrIp(host) {
  const h = host.toLowerCase();
  return h === 'localhost' || /^\d{1,3}(\.\d{1,3}){3}$/.test(h) || /^\[[0-9a-f:]+\]$/i.test(h);
}

function looksLikeHost(text) {
  const authority = text.split(/[/?#]/)[0];
  const host = authority.replace(/:\d{1,5}$/, '');
  if (!host) return false;
  if (isLocalOrIp(host)) return true;
  const labels = host.split('.');
  if (labels.length < 2 || labels.some((l) => l.length === 0)) return false;
  // Last label must look like a TLD (starts with a letter, 2+ chars) so "3.14" is not a host.
  return /^[\p{L}][\p{L}\p{N}-]+$/u.test(labels[labels.length - 1]);
}

function searchResult(text, searchTemplate) {
  return { type: 'search', url: searchTemplate.replace('%s', encodeURIComponent(text)) };
}

/**
 * Turns whatever the user typed in the address bar into a navigation target.
 * Returns {type:'url'|'search', url} or null for empty input.
 * Non-web schemes (javascript:, file:, data:, ...) are never navigated to; they become search text.
 */
function normalizeInput(input, searchTemplate) {
  if (typeof input !== 'string') return null;
  const text = input.trim();
  if (!text || text.length > MAX_URL_LENGTH) return null;

  if (/^https?:\/\//i.test(text)) {
    const href = normalizeWebUrl(text);
    return href ? { type: 'url', url: href } : searchResult(text, searchTemplate);
  }

  const hasScheme = /^[a-z][a-z0-9+.-]*:/i.test(text);
  const isHostPort = /^[^\s/:]+:\d{1,5}(?:[/?#]|$)/.test(text); // localhost:3000, example.com:8080
  if (hasScheme && !isHostPort) return searchResult(text, searchTemplate);

  if (!/\s/.test(text) && looksLikeHost(text)) {
    const host = text.split(/[/?#]/)[0].replace(/:\d{1,5}$/, '');
    const href = normalizeWebUrl((isLocalOrIp(host) ? 'http://' : 'https://') + text);
    if (href) return { type: 'url', url: href };
  }
  return searchResult(text, searchTemplate);
}

/** http(s) favicon URLs or small data:image URLs only. */
function isSafeFaviconUrl(value) {
  if (typeof value !== 'string' || value.length > MAX_FAVICON_LENGTH) return false;
  if (/^data:image\/(png|jpeg|gif|webp|x-icon|vnd\.microsoft\.icon);/i.test(value)) return true;
  return normalizeWebUrl(value) !== null;
}

function filePathKey(value) {
  try {
    const u = new URL(value);
    if (u.protocol !== 'file:') return null;
    return decodeURIComponent(u.pathname).toLowerCase();
  } catch {
    return null;
  }
}

/** True when both are file: URLs pointing at the same path (query/hash ignored). */
function sameFileUrl(a, b) {
  const ka = filePathKey(a);
  return ka !== null && ka === filePathKey(b);
}

module.exports = {
  MAX_URL_LENGTH,
  normalizeWebUrl,
  normalizeInput,
  isSafeFaviconUrl,
  sameFileUrl,
};
