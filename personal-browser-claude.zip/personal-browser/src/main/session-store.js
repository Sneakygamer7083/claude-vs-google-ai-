'use strict';
// Versioned, validated, atomically-written session file with a last-known-good backup.
// No Electron dependency: takes a directory path, so it is fully testable.

const fs = require('fs');
const path = require('path');
const config = require('./config');
const { ID_RE, SESSION_VERSION } = require('./tab-state');
const { normalizeWebUrl } = require('./url-utils');

const MAX_FILE_BYTES = 5 * 1024 * 1024;
const MAX_TITLE = 300;

function fail(error) {
  return { ok: false, error, warnings: [] };
}

/** Validates + sanitizes untrusted parsed JSON. Never throws. */
function validateSession(raw, { maxTabs = config.MAX_TABS } = {}) {
  const warnings = [];
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return fail('session is not an object');
  if (raw.version !== SESSION_VERSION) return fail(`unsupported session version: ${String(raw.version)}`);
  if (!Array.isArray(raw.tabs)) return fail('tabs is not an array');

  const seen = new Set();
  const tabs = [];
  for (const t of raw.tabs) {
    if (tabs.length >= maxTabs) {
      warnings.push(`more than ${maxTabs} tabs; extra tabs dropped`);
      break;
    }
    if (!t || typeof t !== 'object') {
      warnings.push('dropped malformed tab entry');
      continue;
    }
    if (typeof t.id !== 'string' || !ID_RE.test(t.id)) {
      warnings.push('dropped tab with invalid id');
      continue;
    }
    if (seen.has(t.id)) {
      warnings.push(`dropped duplicate tab id ${t.id}`);
      continue;
    }
    let url = null;
    if (t.url !== null && t.url !== undefined) {
      url = normalizeWebUrl(t.url);
      if (!url) warnings.push(`tab ${t.id}: unsupported URL replaced by new-tab page`);
    }
    // eslint-disable-next-line no-control-regex
    const title = typeof t.title === 'string' ? t.title.replace(/[\u0000-\u001f\u007f]/g, '').slice(0, MAX_TITLE) : '';
    seen.add(t.id);
    tabs.push({ id: t.id, url, title });
  }
  if (tabs.length === 0) return fail('no valid tabs');

  let activeTabId = raw.activeTabId;
  if (typeof activeTabId !== 'string' || !seen.has(activeTabId)) {
    warnings.push('active tab missing; first tab selected');
    activeTabId = tabs[0].id;
  }
  const savedAt = Number.isFinite(raw.savedAt) ? raw.savedAt : 0;
  return { ok: true, session: { version: SESSION_VERSION, savedAt, activeTabId, tabs }, warnings };
}

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function renameWithRetry(from, to) {
  const delays = [10, 25, 50, 100, 200, 400];
  for (let attempt = 0; ; attempt++) {
    try {
      fs.renameSync(from, to); // replaces an existing file on Windows (MoveFileEx REPLACE_EXISTING)
      return;
    } catch (err) {
      const transient = err && (err.code === 'EPERM' || err.code === 'EBUSY' || err.code === 'EACCES');
      if (!transient || attempt >= delays.length) throw err;
      sleepSync(delays[attempt]); // antivirus / indexer may briefly hold the file on Windows
    }
  }
}

/** Write to <file>.tmp, fsync, then rename over the target. */
function writeFileAtomicSync(filePath, data) {
  const tmp = `${filePath}.tmp`;
  const fd = fs.openSync(tmp, 'w');
  try {
    fs.writeSync(fd, data);
    fs.fsyncSync(fd);
  } finally {
    fs.closeSync(fd);
  }
  try {
    renameWithRetry(tmp, filePath);
  } catch (err) {
    try {
      fs.unlinkSync(tmp);
    } catch {
      /* ignore */
    }
    throw err;
  }
}

class SessionStore {
  constructor(dir) {
    this.dir = dir;
    this.primaryPath = path.join(dir, 'session.json');
    this.backupPath = path.join(dir, 'session.backup.json');
    this.corruptPath = path.join(dir, 'session.corrupt.json');
  }

  _read(file) {
    let raw;
    try {
      const st = fs.statSync(file);
      if (st.size > MAX_FILE_BYTES) return { exists: true, ok: false, error: 'file too large' };
      raw = fs.readFileSync(file, 'utf8');
    } catch (err) {
      if (err && err.code === 'ENOENT') return { exists: false, ok: false, error: 'missing' };
      return { exists: true, ok: false, error: `read error: ${err && err.message}` };
    }
    if (raw.charCodeAt(0) === 0xfeff) raw = raw.slice(1);
    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      return { exists: true, ok: false, error: `invalid JSON: ${err.message}` };
    }
    const v = validateSession(parsed);
    if (!v.ok) return { exists: true, ok: false, error: v.error };
    return { exists: true, ok: true, session: v.session, warnings: v.warnings, raw };
  }

  /**
   * Loads the best available session.
   * Returns {session|null, source:'primary'|'backup'|'none', warnings:[]}.
   * A corrupt primary file is moved to session.corrupt.json (kept for inspection).
   */
  load() {
    const warnings = [];
    const primary = this._read(this.primaryPath);
    if (primary.ok) {
      return { session: primary.session, source: 'primary', warnings: warnings.concat(primary.warnings) };
    }
    if (primary.exists) {
      warnings.push(`primary session unusable (${primary.error})`);
      try {
        fs.renameSync(this.primaryPath, this.corruptPath);
      } catch {
        /* best effort */
      }
    }
    const backup = this._read(this.backupPath);
    if (backup.ok) {
      warnings.push('recovered session from backup');
      return { session: backup.session, source: 'backup', warnings: warnings.concat(backup.warnings) };
    }
    if (backup.exists) warnings.push(`backup session unusable (${backup.error})`);
    return { session: null, source: 'none', warnings };
  }

  /** Synchronous so it can run during shutdown. Throws on invalid/empty sessions or I/O failure. */
  saveSync(session) {
    const v = validateSession(session);
    if (!v.ok) throw new Error(`refusing to save invalid session: ${v.error}`);
    const data = JSON.stringify(v.session, null, 2);
    fs.mkdirSync(this.dir, { recursive: true });
    // Keep the previous VALID primary as the last-known-good backup. A corrupt primary never
    // overwrites the backup.
    const prev = this._read(this.primaryPath);
    if (prev.ok) writeFileAtomicSync(this.backupPath, prev.raw);
    writeFileAtomicSync(this.primaryPath, data);
  }
}

module.exports = { SessionStore, validateSession, writeFileAtomicSync, SESSION_VERSION };
