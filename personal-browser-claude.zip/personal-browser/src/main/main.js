'use strict';
const path = require('path');
const crypto = require('crypto');
const { app, BrowserWindow, Menu, ipcMain, nativeTheme, session } = require('electron');

const config = require('./config');
const { SessionStore } = require('./session-store');
const { SessionPersistence } = require('./persistence');
const { TabManager } = require('./tab-manager');
const { registerIpc } = require('./ipc');
const security = require('./security');
const { normalizeWebUrl } = require('./url-utils');

let mainWindow = null;
let manager = null;
let persistence = null;
let shuttingDown = false;

// Hardening for every WebContents Electron creates (including ones we never expect).
app.on('web-contents-created', (_event, contents) => {
  contents.on('will-attach-webview', (e) => e.preventDefault());
  contents.setWindowOpenHandler(() => ({ action: 'deny' })); // tabs override this with their own handler
});

process.on('uncaughtException', (err) => console.error('[main] uncaughtException:', err));
process.on('unhandledRejection', (err) => console.error('[main] unhandledRejection:', err));

/** Called from every "we are going away" path. Idempotent. */
function beginShutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  if (persistence) persistence.flushAndClose(); // write the final, intact tab list FIRST
  if (manager) manager.beginShutdown(); // then ignore any teardown-driven tab changes
}

function createWindow() {
  nativeTheme.themeSource = 'dark';
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 600,
    minHeight: 400,
    show: false,
    backgroundColor: '#15161a',
    title: config.APP_NAME,
    webPreferences: {
      preload: config.PRELOAD_PATH,
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      webSecurity: true,
      spellcheck: false,
    },
  });
  const ui = win.webContents;
  ui.setWindowOpenHandler(() => ({ action: 'deny' }));
  ui.on('will-navigate', (e) => e.preventDefault()); // the trusted UI never navigates away
  ui.on('page-title-updated', (e) => e.preventDefault()); // window title is managed by TabManager
  ui.on('render-process-gone', () => {
    if (!shuttingDown && !win.isDestroyed()) win.reload();
  });
  win.loadFile(config.UI_PATH);
  return win;
}

function start() {
  Menu.setApplicationMenu(null);

  const store = new SessionStore(path.join(app.getPath('userData'), 'session'));
  const loaded = store.load();
  for (const w of loaded.warnings) console.warn('[session]', w);
  console.log(`[session] loaded from: ${loaded.source}${loaded.session ? ` (${loaded.session.tabs.length} tabs)` : ''}`);

  const browserSession = session.fromPartition(config.PARTITION); // persistent: cookies/storage survive restarts
  mainWindow = createWindow();
  const win = mainWindow;
  const ui = win.webContents;
  const toast = (msg) => {
    if (!ui.isDestroyed()) ui.send('browser:toast', String(msg));
  };

  persistence = new SessionPersistence({
    store,
    getSession: () => manager.toSession(),
    debounceMs: config.SAVE_DEBOUNCE_MS,
  });
  manager = new TabManager({
    window: win,
    ui,
    session: browserSession,
    newId: () => crypto.randomUUID(),
    onPersist: () => persistence.schedule(),
    toast,
  });

  security.configureSession(browserSession, {
    isTabContents: (wc) => manager.ownsContents(wc),
    parentWindow: win,
    toast,
  });
  registerIpc({ ipcMain, ui, manager });
  ui.on('before-input-event', (event, input) => manager.handleKey(event, input));

  const relayout = () => manager.layout();
  for (const ev of ['resize', 'maximize', 'unmaximize', 'restore', 'enter-full-screen', 'leave-full-screen']) {
    win.on(ev, relayout);
  }

  // Restore FIRST; only then allow saving. Until enable() nothing can be written, so an empty or
  // half-built startup state can never replace the saved session.
  manager.restore(loaded.session);
  persistence.enable();
  persistence.schedule(); // writes a recovered/fresh session back to the primary file

  win.once('ready-to-show', () => win.show());
  win.on('close', beginShutdown);
  win.on('session-end', beginShutdown); // Windows logoff / shutdown
}

function main() {
  if (!app.requestSingleInstanceLock()) {
    app.quit(); // another instance owns the session file
    return;
  }
  app.on('second-instance', (_event, argv) => {
    if (!mainWindow || mainWindow.isDestroyed() || !manager) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
    const url = argv.slice(1).find((a) => normalizeWebUrl(a));
    if (url) manager.createTab({ url });
  });
  app.on('before-quit', beginShutdown);
  app.on('window-all-closed', () => app.quit());
  app.whenReady().then(start);
}

main();
