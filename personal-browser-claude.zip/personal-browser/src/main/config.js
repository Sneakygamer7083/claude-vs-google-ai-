'use strict';
// Shared constants. Deliberately free of any Electron imports so tests can load it.
const path = require('path');
const { pathToFileURL } = require('url');

const SRC = path.join(__dirname, '..');

const UI_PATH = path.join(SRC, 'renderer', 'index.html');
const NEWTAB_PATH = path.join(SRC, 'pages', 'newtab.html');
const ERROR_PATH = path.join(SRC, 'pages', 'error.html');

module.exports = Object.freeze({
  APP_NAME: 'Personal Browser',
  // Website cookies / storage / cache live in this persistent partition.
  PARTITION: 'persist:browser',
  // Height (px) of the trusted UI strip (tab strip 38 + toolbar 44). Keep in sync with renderer/styles.css.
  CHROME_HEIGHT: 82,
  MAX_TABS: 200,
  SAVE_DEBOUNCE_MS: 400,
  SEARCH_URL: 'https://duckduckgo.com/?q=%s',
  PRELOAD_PATH: path.join(SRC, 'preload', 'preload.js'),
  UI_PATH,
  UI_URL: pathToFileURL(UI_PATH).href,
  NEWTAB_PATH,
  NEWTAB_URL: pathToFileURL(NEWTAB_PATH).href,
  ERROR_PATH,
  ERROR_URL: pathToFileURL(ERROR_PATH).href,
});
