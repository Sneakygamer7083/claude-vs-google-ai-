'use strict';
// Conservative defaults for permissions, downloads and external protocols.
const path = require('path');
const { app, dialog, shell } = require('electron');

// Allowed silently (low risk).
const AUTO_ALLOW = new Set(['fullscreen', 'clipboard-sanitized-write']);

// Ask the user (decision lasts until the browser closes). Everything else is denied.
const PROMPTABLE = new Set(['media', 'geolocation', 'notifications', 'clipboard-read']);

// External protocols that may be handed to the OS, and only after the user confirms.
const EXTERNAL_ALLOW = new Set(['mailto:', 'tel:']);

function describePermission(permission, details) {
  switch (permission) {
    case 'media': {
      const types = (details && details.mediaTypes) || [];
      const parts = [];
      if (types.includes('video')) parts.push('camera');
      if (types.includes('audio')) parts.push('microphone');
      return `use your ${parts.length ? parts.join(' and ') : 'camera or microphone'}`;
    }
    case 'geolocation':
      return 'know your location';
    case 'notifications':
      return 'show notifications';
    case 'clipboard-read':
      return 'read text and images from your clipboard';
    default:
      return `use "${permission}"`;
  }
}

function originOf(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'https:' || u.protocol === 'http:' ? u.origin : null;
  } catch {
    return null;
  }
}

function stripUserAgent(ua) {
  // Remove the "Electron/x" and app-name tokens: some sites refuse unknown browsers.
  const names = [app.getName(), app.getName().replace(/\s+/g, '')]
    .filter(Boolean)
    .map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  let out = ua.replace(/\sElectron\/\S+/g, '');
  for (const n of names) out = out.replace(new RegExp(`\\s${n}\\/\\S+`, 'g'), '');
  return out;
}

/**
 * @param {Electron.Session} ses
 * @param {{isTabContents:(wc:any)=>boolean, parentWindow:Electron.BrowserWindow, toast:(msg:string)=>void}} opts
 */
function configureSession(ses, { isTabContents, parentWindow, toast }) {
  ses.setUserAgent(stripUserAgent(ses.getUserAgent()));

  const decisions = new Map(); // "origin|permission" -> boolean (memory only)
  const pending = new Map(); // "origin|permission" -> Promise<boolean>

  ses.setPermissionRequestHandler((wc, permission, callback, details) => {
    try {
      if (!isTabContents(wc)) return callback(false);
      const origin = originOf((details && details.requestingUrl) || wc.getURL());
      if (!origin) return callback(false);
      if (AUTO_ALLOW.has(permission)) return callback(true);
      if (!PROMPTABLE.has(permission)) return callback(false);

      const key = `${origin}|${permission}`;
      if (decisions.has(key)) return callback(decisions.get(key));
      let p = pending.get(key);
      if (!p) {
        p = dialog
          .showMessageBox(parentWindow, {
            type: 'question',
            buttons: ['Allow', 'Block'],
            defaultId: 1,
            cancelId: 1,
            noLink: true,
            title: 'Permission request',
            message: `${origin} wants to ${describePermission(permission, details)}.`,
            detail: 'Your choice is remembered until you close the browser.',
          })
          .then((r) => r.response === 0)
          .finally(() => pending.delete(key));
        pending.set(key, p);
      }
      p.then((ok) => {
        decisions.set(key, ok);
        callback(ok);
      }).catch(() => callback(false));
    } catch {
      callback(false);
    }
    return undefined;
  });

  ses.setPermissionCheckHandler((wc, permission, requestingOrigin) => {
    if (AUTO_ALLOW.has(permission)) return true;
    const origin = originOf(requestingOrigin);
    return !!origin && decisions.get(`${origin}|${permission}`) === true;
  });

  // Downloads: Electron shows a native "Save as" dialog (the user's confirmation) because no
  // save path is set. Cancelling the dialog cancels the download.
  ses.on('will-download', (_event, item) => {
    const name = path.basename(String(item.getFilename() || 'download')).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_') || 'download';
    item.setSaveDialogOptions({
      title: 'Save download',
      defaultPath: path.join(app.getPath('downloads'), name),
    });
    item.once('done', (_e, state) => {
      if (state === 'completed') toast(`Downloaded ${name}`);
      else if (state === 'interrupted') toast(`Download failed: ${name}`);
    });
  });
}

let externalDialogOpen = false;

/**
 * Offers to open a mailto:/tel: link in the OS handler. Every other protocol is ignored.
 * Returns true if the link was handed to the OS.
 */
async function confirmExternalProtocol(rawUrl, parentWindow) {
  if (typeof rawUrl !== 'string' || rawUrl.length > 2000) return false;
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return false;
  }
  if (!EXTERNAL_ALLOW.has(u.protocol) || externalDialogOpen) return false;
  externalDialogOpen = true;
  try {
    const { response } = await dialog.showMessageBox(parentWindow, {
      type: 'question',
      buttons: ['Open', 'Cancel'],
      defaultId: 1,
      cancelId: 1,
      noLink: true,
      title: 'Open in another app?',
      message: `A website wants to open a ${u.protocol} link in another app.`,
      detail: u.href.slice(0, 300),
    });
    if (response !== 0) return false;
    await shell.openExternal(u.href);
    return true;
  } catch {
    return false;
  } finally {
    externalDialogOpen = false;
  }
}

module.exports = { configureSession, confirmExternalProtocol, stripUserAgent };
