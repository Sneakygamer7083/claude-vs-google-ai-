'use strict';
// Pure, immutable tab-state model: the single source of truth for tabs.
// No Electron, no I/O - this is what gets unit-tested and what gets serialized to disk.

const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const MAX_CLOSED = 25;
const SESSION_VERSION = 1;

function createState() {
  return { tabs: [], activeId: null, closed: [] };
}

function indexOf(state, id) {
  return state.tabs.findIndex((t) => t.id === id);
}

function getTab(state, id) {
  return state.tabs.find((t) => t.id === id) || null;
}

function clamp(n, lo, hi) {
  return Math.max(lo, Math.min(hi, n));
}

/** Adds a tab. `index` (optional) is the insertion position; default is the end. */
function addTab(state, { id, url = null, title = '', activate = true, index } = {}) {
  if (typeof id !== 'string' || !ID_RE.test(id)) throw new Error('invalid tab id');
  if (indexOf(state, id) !== -1) throw new Error('duplicate tab id');
  const tabs = state.tabs.slice();
  const at = Number.isInteger(index) ? clamp(index, 0, tabs.length) : tabs.length;
  tabs.splice(at, 0, { id, url: url || null, title: title || '', favicon: null });
  const activeId = activate || state.activeId === null ? id : state.activeId;
  return { ...state, tabs, activeId };
}

/**
 * Closes a tab. If it was the last tab, a fresh blank tab (id = freshId) replaces it, so the
 * browser is never left without a tab. Returns {state, closedTab, replacedWithBlank}.
 */
function closeTab(state, id, freshId) {
  const idx = indexOf(state, id);
  if (idx === -1) return { state, closedTab: null, replacedWithBlank: false };
  const closedTab = state.tabs[idx];
  const tabs = state.tabs.filter((t) => t.id !== id);
  // Only tabs with a real URL are worth reopening.
  const closed = closedTab.url
    ? [{ url: closedTab.url, title: closedTab.title, index: idx }, ...state.closed].slice(0, MAX_CLOSED)
    : state.closed;

  if (tabs.length === 0) {
    if (typeof freshId !== 'string' || !ID_RE.test(freshId)) throw new Error('freshId required');
    const fresh = { id: freshId, url: null, title: 'New Tab', favicon: null };
    return {
      state: { tabs: [fresh], activeId: freshId, closed },
      closedTab,
      replacedWithBlank: true,
    };
  }
  let activeId = state.activeId;
  if (activeId === id) activeId = tabs[Math.min(idx, tabs.length - 1)].id;
  return { state: { tabs, activeId, closed }, closedTab, replacedWithBlank: false };
}

function selectTab(state, id) {
  if (indexOf(state, id) === -1 || state.activeId === id) return state;
  return { ...state, activeId: id };
}

const PATCHABLE = ['url', 'title', 'favicon'];

/** Returns the SAME state object when nothing changed (cheap change detection). */
function updateTab(state, id, patch) {
  const idx = indexOf(state, id);
  if (idx === -1) return state;
  const cur = state.tabs[idx];
  let changed = false;
  const next = { ...cur };
  for (const key of PATCHABLE) {
    if (!(key in patch)) continue;
    let v = patch[key];
    if (key === 'title') v = typeof v === 'string' ? v : '';
    else v = typeof v === 'string' && v ? v : null;
    if (next[key] !== v) {
      next[key] = v;
      changed = true;
    }
  }
  if (!changed) return state;
  const tabs = state.tabs.slice();
  tabs[idx] = next;
  return { ...state, tabs };
}

function moveTab(state, id, toIndex) {
  const from = indexOf(state, id);
  if (from === -1 || !Number.isInteger(toIndex)) return state;
  const to = clamp(toIndex, 0, state.tabs.length - 1);
  if (to === from) return state;
  const tabs = state.tabs.slice();
  const [tab] = tabs.splice(from, 1);
  tabs.splice(to, 0, tab);
  return { ...state, tabs };
}

/** Next (dir=1) or previous (dir=-1) tab, wrapping around. */
function cycleTab(state, dir) {
  const n = state.tabs.length;
  if (n < 2) return state;
  const cur = indexOf(state, state.activeId);
  const next = (cur + (dir < 0 ? -1 : 1) + n) % n;
  return { ...state, activeId: state.tabs[next].id };
}

/** Ctrl+1..8 -> that tab; Ctrl+9 -> last tab. */
function selectByNumber(state, n) {
  if (!Number.isInteger(n) || n < 1 || n > 9 || state.tabs.length === 0) return state;
  const tab = n === 9 ? state.tabs[state.tabs.length - 1] : state.tabs[n - 1];
  return tab ? selectTab(state, tab.id) : state;
}

/** Reopens the most recently closed tab. Returns {state, tab} (tab null if nothing to reopen). */
function reopenClosed(state, newId) {
  if (state.closed.length === 0) return { state, tab: null };
  const [entry, ...rest] = state.closed;
  const next = addTab({ ...state, closed: rest }, {
    id: newId,
    url: entry.url,
    title: entry.title,
    activate: true,
    index: entry.index,
  });
  return { state: next, tab: getTab(next, newId) };
}

/** Serializable session snapshot. Only metadata - never cookies or page content. */
function toSession(state, now = Date.now()) {
  return {
    version: SESSION_VERSION,
    savedAt: now,
    activeTabId: state.activeId,
    tabs: state.tabs.map((t) => ({ id: t.id, url: t.url, title: t.title })),
  };
}

/** Builds state from an already-validated session (see session-store.validateSession). */
function fromSession(session) {
  if (!session || !Array.isArray(session.tabs) || session.tabs.length === 0) {
    throw new Error('cannot build state from an empty session');
  }
  const tabs = session.tabs.map((t) => ({ id: t.id, url: t.url || null, title: t.title || '', favicon: null }));
  const activeId = tabs.some((t) => t.id === session.activeTabId) ? session.activeTabId : tabs[0].id;
  return { tabs, activeId, closed: [] };
}

module.exports = {
  ID_RE,
  MAX_CLOSED,
  SESSION_VERSION,
  createState,
  indexOf,
  getTab,
  addTab,
  closeTab,
  selectTab,
  updateTab,
  moveTab,
  cycleTab,
  selectByNumber,
  reopenClosed,
  toSession,
  fromSession,
};
