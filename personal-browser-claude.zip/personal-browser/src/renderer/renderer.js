'use strict';
// Trusted browser UI. Talks to the main process ONLY through window.browserAPI (see preload.js).
// All page-derived text (titles, URLs) is inserted with textContent / validated attributes, never innerHTML.
(() => {
  const api = window.browserAPI;
  const $ = (id) => document.getElementById(id);
  const tabsEl = $('tabs');
  const address = $('address');
  const backBtn = $('back');
  const forwardBtn = $('forward');
  const reloadBtn = $('reload');
  const toastEl = $('toast');

  let state = { activeId: null, tabs: [] };
  let lastSeq = -1;
  let lastActiveId = null;
  let lastActiveUrl;
  let dragId = null;
  let pendingWhileDragging = null;
  let toastTimer = null;

  function makeFavicon(tab) {
    if (tab.loading) {
      const s = document.createElement('span');
      s.className = 'spinner';
      return s;
    }
    if (tab.favicon) {
      const img = document.createElement('img');
      img.className = 'fav';
      img.alt = '';
      img.referrerPolicy = 'no-referrer';
      img.draggable = false;
      img.addEventListener('error', () => {
        const ph = document.createElement('span');
        ph.className = 'fav placeholder';
        img.replaceWith(ph);
      });
      img.src = tab.favicon;
      return img;
    }
    const ph = document.createElement('span');
    ph.className = 'fav placeholder';
    return ph;
  }

  function makeTab(tab, index) {
    const el = document.createElement('div');
    el.className = 'tab' + (tab.id === state.activeId ? ' active' : '');
    el.setAttribute('role', 'tab');
    el.setAttribute('aria-selected', String(tab.id === state.activeId));
    el.tabIndex = 0;
    el.draggable = true;
    el.dataset.id = tab.id;
    el.title = tab.title;

    const title = document.createElement('span');
    title.className = 'title';
    title.textContent = tab.title;

    const close = document.createElement('button');
    close.className = 'close';
    close.tabIndex = -1;
    close.title = 'Close tab (Ctrl+W)';
    close.setAttribute('aria-label', 'Close tab');
    close.innerHTML = '<svg viewBox="0 0 16 16" width="10" height="10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="m3 3 10 10M13 3 3 13"/></svg>'; // static markup only
    close.addEventListener('click', (e) => { e.stopPropagation(); api.closeTab(tab.id); });

    el.append(makeFavicon(tab), title, close);

    el.addEventListener('click', () => api.selectTab(tab.id));
    el.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); api.selectTab(tab.id); }
    });
    el.addEventListener('mousedown', (e) => { if (e.button === 1) e.preventDefault(); });
    el.addEventListener('auxclick', (e) => { if (e.button === 1) { e.preventDefault(); api.closeTab(tab.id); } });

    el.addEventListener('dragstart', (e) => {
      dragId = tab.id;
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', tab.id);
    });
    el.addEventListener('dragover', (e) => {
      if (!dragId || dragId === tab.id) return;
      e.preventDefault();
      el.classList.add('drag-over');
    });
    el.addEventListener('dragleave', () => el.classList.remove('drag-over'));
    el.addEventListener('drop', (e) => {
      e.preventDefault();
      el.classList.remove('drag-over');
      if (dragId && dragId !== tab.id) api.moveTab(dragId, index);
    });
    el.addEventListener('dragend', () => {
      dragId = null;
      if (pendingWhileDragging) { const s = pendingWhileDragging; pendingWhileDragging = null; apply(s); }
    });
    return el;
  }

  function apply(s) {
    if (s.seq <= lastSeq) return; // stale snapshot
    lastSeq = s.seq;
    state = s;
    tabsEl.replaceChildren(...s.tabs.map(makeTab));

    const active = s.tabs.find((t) => t.id === s.activeId);
    backBtn.disabled = !active || !active.canGoBack;
    forwardBtn.disabled = !active || !active.canGoForward;
    reloadBtn.classList.toggle('loading', !!(active && active.loading));
    reloadBtn.title = active && active.loading ? 'Stop loading' : 'Reload (Ctrl+R)';
    reloadBtn.setAttribute('aria-label', active && active.loading ? 'Stop loading' : 'Reload');

    // Keep the address bar in sync, but never clobber text the user is typing unless the
    // active tab or its committed URL actually changed.
    if (active) {
      const changed = active.id !== lastActiveId || active.url !== lastActiveUrl;
      if (changed || document.activeElement !== address) address.value = active.url || '';
      lastActiveId = active.id;
      lastActiveUrl = active.url;
    }
  }

  function focusAddress() {
    address.focus();
    address.select();
  }

  function showToast(msg) {
    toastEl.textContent = String(msg);
    toastEl.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.hidden = true; }, 4000);
  }

  $('new-tab').addEventListener('click', () => api.newTab());
  backBtn.addEventListener('click', () => api.back());
  forwardBtn.addEventListener('click', () => api.forward());
  reloadBtn.addEventListener('click', () => {
    const active = state.tabs.find((t) => t.id === state.activeId);
    if (active && active.loading) api.stop(); else api.reload();
  });
  $('address-form').addEventListener('submit', (e) => {
    e.preventDefault();
    const text = address.value.trim();
    if (text) api.navigate(text);
    address.blur();
  });
  address.addEventListener('focus', () => setTimeout(() => address.select(), 0));
  address.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const active = state.tabs.find((t) => t.id === state.activeId);
      address.value = (active && active.url) || '';
      address.blur();
    }
  });

  api.onState((s) => {
    if (dragId) { pendingWhileDragging = s; return; }
    apply(s);
  });
  api.onFocusAddress(focusAddress);
  api.onToast(showToast);

  api.getState().then((s) => {
    apply(s);
    const active = s.tabs.find((t) => t.id === s.activeId);
    if (active && !active.url) focusAddress(); // blank new tab on startup
  }).catch((err) => showToast(`Could not load browser state: ${err && err.message}`));
})();
