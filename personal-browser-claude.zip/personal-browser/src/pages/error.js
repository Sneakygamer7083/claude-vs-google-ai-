'use strict';
// Reads the failure details from the query string. Everything is inserted via textContent, and the
// retry link is only enabled for http(s) URLs.
(() => {
  const q = new URLSearchParams(location.search);
  const code = q.get('code') || '';
  const desc = (q.get('desc') || '').replace(/^net::/, '');
  const url = q.get('url') || '';

  document.getElementById('url').textContent = url;
  document.getElementById('desc').textContent = desc ? `${desc}${/^-?\d+$/.test(code) ? ` (error ${code})` : ''}` : 'Something went wrong while loading the page.';

  const hints = {
    '-105': 'The site\u2019s address could not be found. Check the spelling and your internet connection.',
    '-106': 'You appear to be offline. Check your network connection.',
    '-102': 'The site refused the connection. It may be down.',
    '-118': 'The site took too long to respond.',
    '-200': 'The site\u2019s security certificate is not trusted, so the page was blocked.',
    '-201': 'Your computer\u2019s clock may be wrong, which makes the site\u2019s certificate look invalid.',
    '-202': 'The site\u2019s security certificate is not trusted, so the page was blocked.',
    '-501': 'The connection is not private, so the page was blocked.',
    CRASHED: 'The page\u2019s process stopped unexpectedly. Trying again usually fixes it.',
  };
  document.getElementById('hint').textContent = hints[code] || '';

  const retry = document.getElementById('retry');
  let ok = false;
  try {
    const u = new URL(url);
    ok = u.protocol === 'http:' || u.protocol === 'https:';
  } catch { /* not a URL */ }
  if (ok) retry.href = url; else retry.hidden = true;
})();
