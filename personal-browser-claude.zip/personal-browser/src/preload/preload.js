'use strict';
// Runs ONLY in the trusted browser UI (never in websites). Exposes a small, fixed API.
const { contextBridge, ipcRenderer } = require('electron');

const invoke = (channel, ...args) => ipcRenderer.invoke(channel, ...args);
const subscribe = (channel, cb) => {
  if (typeof cb !== 'function') return () => {};
  const handler = (_event, payload) => cb(payload);
  ipcRenderer.on(channel, handler);
  return () => ipcRenderer.removeListener(channel, handler);
};

contextBridge.exposeInMainWorld(
  'browserAPI',
  Object.freeze({
    getState: () => invoke('browser:get-state'),
    newTab: () => invoke('browser:new-tab'),
    closeTab: (id) => invoke('browser:close-tab', id),
    selectTab: (id) => invoke('browser:select-tab', id),
    moveTab: (id, index) => invoke('browser:move-tab', id, index),
    navigate: (text) => invoke('browser:navigate', text),
    back: () => invoke('browser:back'),
    forward: () => invoke('browser:forward'),
    reload: () => invoke('browser:reload'),
    stop: () => invoke('browser:stop'),
    reopenClosed: () => invoke('browser:reopen-closed'),
    onState: (cb) => subscribe('browser:state', cb),
    onFocusAddress: (cb) => subscribe('browser:focus-address', () => cb()),
    onToast: (cb) => subscribe('browser:toast', cb),
  })
);
