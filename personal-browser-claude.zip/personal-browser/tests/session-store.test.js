'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { SessionStore, validateSession } = require('../src/main/session-store');

function tmpStore() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pb-session-'));
  return { dir, store: new SessionStore(dir) };
}
const sess = (ids, active, urlFor = (i) => `https://site${i}.example/`) => ({
  version: 1,
  savedAt: 1,
  activeTabId: active,
  tabs: ids.map((id, i) => ({ id, url: urlFor(i), title: `T${i}` })),
});

test('validateSession: accepts a good session unchanged', () => {
  const r = validateSession(sess(['a', 'b', 'c'], 'b'));
  assert.ok(r.ok);
  assert.equal(r.session.activeTabId, 'b');
  assert.deepEqual(r.session.tabs.map((t) => t.id), ['a', 'b', 'c']);
  assert.deepEqual(r.warnings, []);
});

test('validateSession: rejects garbage', () => {
  for (const bad of [null, undefined, 5, 'x', [], {}, { version: 2, tabs: [] }, { version: 1 }, { version: 1, tabs: [] }, { version: 1, tabs: [null, 3, {}] }]) {
    assert.equal(validateSession(bad).ok, false, JSON.stringify(bad));
  }
});

test('validateSession: sanitizes URLs, ids, duplicates, active tab', () => {
  const r = validateSession({
    version: 1,
    activeTabId: 'ghost',
    tabs: [
      { id: 'a', url: 'javascript:alert(1)', title: 'x\u0000y' },
      { id: 'a', url: 'https://dup.example/', title: 'dup' },
      { id: '../bad', url: 'https://x.example/' },
      { id: 'b', url: 'file:///C:/secret.txt' },
      { id: 'c', url: 'https://ok.example/', title: 5 },
      { id: 'd', url: null },
    ],
  });
  assert.ok(r.ok);
  assert.deepEqual(r.session.tabs.map((t) => t.id), ['a', 'b', 'c', 'd']);
  assert.equal(r.session.tabs[0].url, null);
  assert.equal(r.session.tabs[0].title, 'xy');
  assert.equal(r.session.tabs[1].url, null);
  assert.equal(r.session.tabs[2].title, '');
  assert.equal(r.session.activeTabId, 'a');
  assert.ok(r.warnings.length >= 4);
});

test('validateSession: caps the tab count', () => {
  const ids = Array.from({ length: 50 }, (_, i) => `t${i}`);
  const r = validateSession(sess(ids, 't0'), { maxTabs: 10 });
  assert.equal(r.session.tabs.length, 10);
});

test('save then load round-trips tab order, URLs and active tab', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a', 'b', 'c'], 'b'));
  const r = store.load();
  assert.equal(r.source, 'primary');
  assert.deepEqual(r.session.tabs.map((t) => t.url), ['https://site0.example/', 'https://site1.example/', 'https://site2.example/']);
  assert.equal(r.session.activeTabId, 'b');
});

test('load with no files returns source none', () => {
  const { store } = tmpStore();
  const r = store.load();
  assert.equal(r.session, null);
  assert.equal(r.source, 'none');
});

test('saveSync refuses empty / invalid sessions and leaves the file untouched', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a'], 'a'));
  assert.throws(() => store.saveSync({ version: 1, activeTabId: null, tabs: [] }));
  assert.throws(() => store.saveSync(null));
  assert.equal(store.load().session.tabs.length, 1);
});

test('leaves no .tmp files behind', () => {
  const { dir, store } = tmpStore();
  store.saveSync(sess(['a'], 'a'));
  store.saveSync(sess(['a', 'b'], 'b'));
  assert.deepEqual(fs.readdirSync(dir).filter((f) => f.endsWith('.tmp')), []);
});

test('backup holds the previous good session; corrupt primary recovers from it', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a', 'b'], 'a'));
  store.saveSync(sess(['a', 'b', 'c'], 'c'));
  fs.writeFileSync(store.primaryPath, '{ "version": 1, "tabs": [ {"id": "a", "ur'); // truncated JSON
  const r = store.load();
  assert.equal(r.source, 'backup');
  assert.deepEqual(r.session.tabs.map((t) => t.id), ['a', 'b']);
  assert.ok(r.warnings.some((w) => /backup/.test(w)));
  assert.ok(fs.existsSync(store.corruptPath), 'corrupt file is kept for inspection');
});

test('empty (zero-byte) primary recovers from backup', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a'], 'a'));
  store.saveSync(sess(['a', 'b'], 'b'));
  fs.writeFileSync(store.primaryPath, '');
  assert.equal(store.load().source, 'backup');
});

test('both files corrupt -> safe none (caller starts with one new tab)', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a'], 'a'));
  store.saveSync(sess(['a', 'b'], 'b'));
  fs.writeFileSync(store.primaryPath, 'garbage');
  fs.writeFileSync(store.backupPath, '{"version":99}');
  const r = store.load();
  assert.equal(r.session, null);
  assert.equal(r.source, 'none');
});

test('a corrupt primary never overwrites the good backup on the next save', () => {
  const { store } = tmpStore();
  store.saveSync(sess(['a'], 'a'));
  store.saveSync(sess(['a', 'b'], 'b'));
  fs.writeFileSync(store.primaryPath, 'garbage');
  store.saveSync(sess(['z'], 'z')); // primary invalid -> backup must stay as-is
  const backup = JSON.parse(fs.readFileSync(store.backupPath, 'utf8'));
  assert.deepEqual(backup.tabs.map((t) => t.id), ['a']);
  assert.deepEqual(store.load().session.tabs.map((t) => t.id), ['z']);
});

test('tampered URLs in the file are neutralised on load', () => {
  const { store } = tmpStore();
  fs.mkdirSync(store.dir, { recursive: true });
  fs.writeFileSync(store.primaryPath, JSON.stringify({ version: 1, activeTabId: 'a', tabs: [{ id: 'a', url: 'javascript:alert(1)', title: 't' }, { id: 'b', url: 'https://ok.example/', title: 'ok' }] }));
  const r = store.load();
  assert.equal(r.session.tabs[0].url, null);
  assert.equal(r.session.tabs[1].url, 'https://ok.example/');
});

test('BOM-prefixed file still loads', () => {
  const { store } = tmpStore();
  fs.writeFileSync(store.primaryPath, '\ufeff' + JSON.stringify(sess(['a'], 'a')));
  assert.equal(store.load().source, 'primary');
});
