'use strict';
// Integration-style tests for TabManager using a FAKE `electron` module (real Electron is not
// needed). They exercise the real tab/navigation/shutdown logic, not Chromium itself.
const test = require('node:test');
const assert = require('node:assert/strict');
const Module = require('module');
const { EventEmitter } = require('events');
const path = require('path');

const created = [];
class FakeContents extends EventEmitter {
  constructor() {
    super();
    this.loads = [];
    this.destroyed = false;
    this.focused = false;
    this.navigationHistory = { canGoBack: () => false, canGoForward: () => false, goBack() {}, goForward() {} };
  }
  loadURL(u) { this.loads.push(u); return Promise.resolve(); }
  loadFile(f, o) { this.loads.push({ file: path.basename(f), query: o && o.query }); return Promise.resolve(); }
  setWindowOpenHandler(fn) { this.openHandler = fn; }
  focus() { this.focused = true; }
  isDestroyed() { return this.destroyed; }
  close() { this.destroyed = true; }
  reload() { this.reloaded = true; }
  stop() {}
}
class FakeView {
  constructor() { this.webContents = new FakeContents(); this.bounds = null; created.push(this); }
  setBounds(b) { this.bounds = b; }
}
const fakeElectron = {
  WebContentsView: FakeView,
  app: { getName: () => 'Personal Browser', getPath: () => '/tmp' },
  dialog: { showMessageBox: async () => ({ response: 1 }) },
  shell: { openExternal: async () => {} },
};
const origLoad = Module._load;
Module._load = function (request, ...rest) {
  return request === 'electron' ? fakeElectron : origLoad.call(this, request, ...rest);
};
const { TabManager } = require('../src/main/tab-manager');
const config = require('../src/main/config');
Module._load = origLoad;

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

function setup(sessionTabs, activeId) {
  created.length = 0;
  let n = 0;
  const children = [];
  const sent = [];
  const win = {
    contentView: {
      addChildView: (v) => children.push(v),
      removeChildView: (v) => { const i = children.indexOf(v); if (i >= 0) children.splice(i, 1); },
    },
    getContentSize: () => [1000, 800],
    setTitle() {}, setFullScreen() {}, isDestroyed: () => false,
  };
  const ui = { send: (ch, p) => sent.push([ch, p]), focus() {}, isDestroyed: () => false };
  let persists = 0;
  const m = new TabManager({ window: win, ui, session: {}, newId: () => `id${++n}`, onPersist: () => persists++, toast() {} });
  m.restore(sessionTabs ? { version: 1, savedAt: 0, activeTabId: activeId, tabs: sessionTabs } : null);
  return { m, children, sent, persists: () => persists };
}

const S = (id, url) => ({ id, url, title: id });

test('restore: all tabs listed in order, only the ACTIVE tab gets a real view (lazy)', () => {
  const { m, children } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/'), S('c', 'https://c.example/')], 'b');
  assert.deepEqual(m.toSession().tabs.map((t) => t.id), ['a', 'b', 'c']);
  assert.equal(m.toSession().activeTabId, 'b');
  assert.equal(created.length, 1);
  assert.equal(created[0].webContents.loads[0], 'https://b.example/');
  assert.equal(children.length, 1);
  assert.deepEqual(created[0].bounds, { x: 0, y: config.CHROME_HEIGHT, width: 1000, height: 800 - config.CHROME_HEIGHT });
});

test('selecting a lazy tab creates + loads its view, swaps the visible view', () => {
  const { m, children } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/')], 'a');
  m.selectTab('b');
  assert.equal(created.length, 2);
  assert.equal(created[1].webContents.loads[0], 'https://b.example/');
  assert.equal(children.length, 1);
  assert.equal(children[0], created[1]);
  assert.equal(m.toSession().activeTabId, 'b');
});

test('committed navigation (full + same-document) updates the saved URL', () => {
  const { m, persists } = setup([S('a', 'https://a.example/')], 'a');
  const wc = created[0].webContents;
  const before = persists();
  wc.emit('did-navigate', { url: 'https://a.example/next' }, 'https://a.example/next');
  assert.equal(m.toSession().tabs[0].url, 'https://a.example/next');
  wc.emit('did-navigate-in-page', { url: 'https://a.example/spa/route', isMainFrame: true }, 'https://a.example/spa/route', true);
  assert.equal(m.toSession().tabs[0].url, 'https://a.example/spa/route');
  wc.emit('did-navigate-in-page', { url: 'https://ads.example/frame', isMainFrame: false }, 'https://ads.example/frame', false);
  assert.equal(m.toSession().tabs[0].url, 'https://a.example/spa/route', 'subframe navigation is ignored');
  assert.ok(persists() > before);
});

test('internal pages never leak into the saved session', () => {
  const { m } = setup([S('a', 'https://a.example/')], 'a');
  const wc = created[0].webContents;
  wc.emit('did-fail-load', {}, -105, 'ERR_NAME_NOT_RESOLVED', 'https://nope.invalid/', true);
  assert.equal(m.toSession().tabs[0].url, 'https://nope.invalid/');
  assert.equal(wc.loads.at(-1).file, 'error.html');
  wc.emit('did-navigate', { url: config.ERROR_URL + '?code=-105' }, config.ERROR_URL);
  assert.equal(m.toSession().tabs[0].url, 'https://nope.invalid/');
  wc.emit('did-fail-load', {}, -3, 'ERR_ABORTED', 'https://x.example/', true);
  assert.equal(wc.loads.filter((l) => l.file === 'error.html').length, 1, 'aborted loads are ignored');
});

test('closing a tab removes it, destroys its view, and it stays closed', () => {
  const { m, children } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/'), S('c', 'https://c.example/')], 'b');
  m.closeTab('b');
  assert.deepEqual(m.toSession().tabs.map((t) => t.id), ['a', 'c']);
  assert.equal(created[0].webContents.destroyed, true);
  assert.equal(m.toSession().activeTabId, 'c');
  assert.equal(children.length, 1);
});

test('closing the last tab leaves one blank new-tab page', () => {
  const { m } = setup([S('a', 'https://a.example/')], 'a');
  m.closeTab('a');
  const s = m.toSession();
  assert.equal(s.tabs.length, 1);
  assert.equal(s.tabs[0].url, null);
  assert.equal(created.at(-1).webContents.loads[0].file, 'newtab.html');
});

test('reopen closed tab (Ctrl+Shift+T)', () => {
  const { m } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/')], 'a');
  m.closeTab('b');
  m.reopenClosed();
  assert.deepEqual(m.toSession().tabs.map((t) => t.url), ['https://a.example/', 'https://b.example/']);
});

test('window.open / target=_blank becomes a tab; non-web URLs are denied', () => {
  const { m } = setup([S('a', 'https://a.example/'), S('z', 'https://z.example/')], 'a');
  const wc = created[0].webContents;
  assert.deepEqual(wc.openHandler({ url: 'https://popup.example/', disposition: 'foreground-tab' }), { action: 'deny' });
  assert.deepEqual(m.toSession().tabs.map((t) => t.url), ['https://a.example/', 'https://popup.example/', 'https://z.example/']);
  assert.equal(m.toSession().activeTabId, 'id1');
  wc.openHandler({ url: 'javascript:alert(1)', disposition: 'foreground-tab' });
  wc.openHandler({ url: 'file:///C:/Windows/win.ini', disposition: 'foreground-tab' });
  assert.equal(m.toSession().tabs.length, 3);
});

test('will-navigate blocks non-web schemes and allows http(s)', () => {
  setup([S('a', 'https://a.example/')], 'a');
  const wc = created[0].webContents;
  let blocked = 0;
  const ev = (url) => ({ url, preventDefault: () => { blocked++; } });
  wc.emit('will-navigate', ev('https://ok.example/'));
  assert.equal(blocked, 0);
  wc.emit('will-navigate', ev('file:///C:/Windows/win.ini'));
  wc.emit('will-navigate', ev('javascript:alert(1)'));
  wc.emit('will-navigate', ev('ms-msdt:/id'));
  assert.equal(blocked, 3);
});

test('shutdown: destroying tabs afterwards cannot change the session', () => {
  const { m } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/')], 'a');
  const snapshot = JSON.stringify(m.toSession().tabs);
  m.beginShutdown();
  m.closeTab('a');
  m.closeTab('b');
  m.createTab({ url: 'https://new.example/' });
  assert.equal(JSON.stringify(m.toSession().tabs), snapshot);
});

test('keyboard shortcuts', () => {
  const { m } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/'), S('c', 'https://c.example/')], 'a');
  const key = (k, mods = {}) => {
    let prevented = false;
    const handled = m.handleKey({ preventDefault: () => { prevented = true; } }, { type: 'keyDown', key: k, control: false, shift: false, alt: false, ...mods });
    return handled && prevented;
  };
  assert.ok(key('Tab', { control: true }));
  assert.equal(m.toSession().activeTabId, 'b');
  assert.ok(key('Tab', { control: true, shift: true }));
  assert.equal(m.toSession().activeTabId, 'a');
  assert.ok(key('t', { control: true }));
  assert.equal(m.toSession().tabs.length, 4);
  assert.ok(key('w', { control: true }));
  assert.equal(m.toSession().tabs.length, 3);
  assert.ok(key('T', { control: true, shift: true }), 'blank tabs are not reopenable, but the key is still consumed');
  assert.ok(key('3', { control: true }));
  assert.equal(m.toSession().activeTabId, 'c');
  assert.ok(key('l', { control: true }));
  assert.ok(key('r', { control: true }));
  assert.ok(!key('x', { control: true }));
  assert.ok(!key('t', {}), 'plain t is not a shortcut');
});

test('UI snapshots have increasing seq and reflect active tab', async () => {
  const { m, sent } = setup([S('a', 'https://a.example/'), S('b', 'https://b.example/')], 'a');
  m.selectTab('b');
  await wait(40);
  const states = sent.filter(([c]) => c === 'browser:state').map(([, p]) => p);
  assert.ok(states.length >= 1);
  assert.equal(states.at(-1).activeId, 'b');
  for (let i = 1; i < states.length; i++) assert.ok(states[i].seq > states[i - 1].seq);
});
