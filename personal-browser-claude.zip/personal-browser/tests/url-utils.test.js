'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { normalizeWebUrl, normalizeInput, isSafeFaviconUrl, sameFileUrl } = require('../src/main/url-utils');

const SEARCH = 'https://duckduckgo.com/?q=%s';

test('normalizeWebUrl accepts only http(s)', () => {
  assert.equal(normalizeWebUrl('https://example.com'), 'https://example.com/');
  assert.equal(normalizeWebUrl('http://example.com/a?b=1#c'), 'http://example.com/a?b=1#c');
  for (const bad of ['javascript:alert(1)', 'file:///C:/x', 'data:text/html,hi', 'ftp://x.com', 'about:blank', '', null, undefined, 42, 'not a url']) {
    assert.equal(normalizeWebUrl(bad), null, String(bad));
  }
  assert.equal(normalizeWebUrl('https://example.com/' + 'a'.repeat(9000)), null);
});

test('normalizeInput: URLs, hosts, search', () => {
  assert.deepEqual(normalizeInput('https://example.com/x', SEARCH), { type: 'url', url: 'https://example.com/x' });
  assert.deepEqual(normalizeInput('example.com', SEARCH), { type: 'url', url: 'https://example.com/' });
  assert.deepEqual(normalizeInput('example.com/path?q=1', SEARCH), { type: 'url', url: 'https://example.com/path?q=1' });
  assert.deepEqual(normalizeInput('localhost:3000', SEARCH), { type: 'url', url: 'http://localhost:3000/' });
  assert.deepEqual(normalizeInput('192.168.1.1', SEARCH), { type: 'url', url: 'http://192.168.1.1/' });
  assert.equal(normalizeInput('cats and dogs', SEARCH).type, 'search');
  assert.equal(normalizeInput('3.14', SEARCH).type, 'search');
  assert.equal(normalizeInput('hello', SEARCH).type, 'search');
  assert.equal(normalizeInput('   ', SEARCH), null);
  assert.equal(normalizeInput(undefined, SEARCH), null);
});

test('normalizeInput never navigates to dangerous schemes', () => {
  for (const evil of ['javascript:alert(1)', 'file:///C:/Windows/win.ini', 'data:text/html,<script>1</script>', 'vbscript:x', 'chrome://settings']) {
    const r = normalizeInput(evil, SEARCH);
    assert.equal(r.type, 'search', evil);
    assert.ok(r.url.startsWith('https://duckduckgo.com/?q='), evil);
  }
});

test('isSafeFaviconUrl', () => {
  assert.ok(isSafeFaviconUrl('https://example.com/favicon.ico'));
  assert.ok(isSafeFaviconUrl('data:image/png;base64,AAAA'));
  assert.ok(!isSafeFaviconUrl('data:image/svg+xml;base64,AAAA'));
  assert.ok(!isSafeFaviconUrl('javascript:alert(1)'));
  assert.ok(!isSafeFaviconUrl('file:///C:/x.ico'));
});

test('sameFileUrl ignores query, hash and case', () => {
  assert.ok(sameFileUrl('file:///C:/App/src/pages/error.html?code=1', 'file:///c:/app/src/pages/error.html'));
  assert.ok(!sameFileUrl('file:///C:/App/a.html', 'file:///C:/App/b.html'));
  assert.ok(!sameFileUrl('https://example.com/a', 'https://example.com/a'));
});
