'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const T = require('../src/main/tab-state');

function build(urls) {
  let s = T.createState();
  urls.forEach((u, i) => {
    s = T.addTab(s, { id: `t${i + 1}`, url: u, title: `Title ${i + 1}` });
  });
  return s;
}

test('addTab activates new tab, supports index, rejects bad/duplicate ids', () => {
  let s = build(['https://a.com/', 'https://b.com/']);
  assert.equal(s.activeId, 't2');
  s = T.addTab(s, { id: 'x', url: null, activate: false, index: 1 });
  assert.deepEqual(s.tabs.map((t) => t.id), ['t1', 'x', 't2']);
  assert.equal(s.activeId, 't2');
  assert.throws(() => T.addTab(s, { id: 't1' }), /duplicate/);
  assert.throws(() => T.addTab(s, { id: '../evil' }), /invalid/);
});

test('closing the active tab selects the neighbour; order is preserved', () => {
  let s = build(['https://a.com/', 'https://b.com/', 'https://c.com/']);
  s = T.selectTab(s, 't2');
  const r = T.closeTab(s, 't2', 'fresh');
  assert.deepEqual(r.state.tabs.map((t) => t.id), ['t1', 't3']);
  assert.equal(r.state.activeId, 't3');
  const r2 = T.closeTab(r.state, 't3', 'fresh');
  assert.equal(r2.state.activeId, 't1');
});

test('closing a background tab keeps the active tab', () => {
  let s = build(['https://a.com/', 'https://b.com/', 'https://c.com/']);
  s = T.selectTab(s, 't3');
  assert.equal(T.closeTab(s, 't1', 'f').state.activeId, 't3');
});

test('closing the last tab yields one blank tab, never zero', () => {
  const s = build(['https://a.com/']);
  const r = T.closeTab(s, 't1', 'fresh');
  assert.equal(r.replacedWithBlank, true);
  assert.equal(r.state.tabs.length, 1);
  assert.equal(r.state.tabs[0].url, null);
  assert.equal(r.state.activeId, 'fresh');
});

test('reopenClosed restores the most recent tab at its old position', () => {
  let s = build(['https://a.com/', 'https://b.com/', 'https://c.com/']);
  s = T.closeTab(s, 't2', 'f').state;
  s = T.closeTab(s, 't3', 'f').state;
  let r = T.reopenClosed(s, 'n1');
  assert.equal(r.tab.url, 'https://c.com/');
  assert.equal(r.state.activeId, 'n1');
  r = T.reopenClosed(r.state, 'n2');
  assert.deepEqual(r.state.tabs.map((t) => t.url), ['https://a.com/', 'https://b.com/', 'https://c.com/']);
  assert.equal(T.reopenClosed(r.state, 'n3').tab, null);
});

test('blank tabs are not added to the reopen stack', () => {
  let s = T.addTab(T.createState(), { id: 'a', url: null });
  s = T.addTab(s, { id: 'b', url: 'https://x.com/' });
  s = T.closeTab(s, 'a', 'f').state;
  assert.equal(s.closed.length, 0);
});

test('updateTab returns the same object when nothing changes', () => {
  const s = build(['https://a.com/']);
  assert.equal(T.updateTab(s, 't1', { url: 'https://a.com/' }), s);
  assert.equal(T.updateTab(s, 'nope', { url: 'https://z.com/' }), s);
  const s2 = T.updateTab(s, 't1', { url: 'https://a.com/next', title: 'N' });
  assert.notEqual(s2, s);
  assert.equal(s2.tabs[0].url, 'https://a.com/next');
  assert.equal(s.tabs[0].url, 'https://a.com/', 'original state is not mutated');
  assert.equal(T.updateTab(s, 't1', { id: 'hack' }), s, 'id is not patchable');
});

test('moveTab / cycleTab / selectByNumber', () => {
  let s = build(['https://a.com/', 'https://b.com/', 'https://c.com/']);
  s = T.moveTab(s, 't3', 0);
  assert.deepEqual(s.tabs.map((t) => t.id), ['t3', 't1', 't2']);
  assert.equal(T.moveTab(s, 't3', 0), s);
  s = T.selectTab(s, 't2');
  assert.equal(T.cycleTab(s, 1).activeId, 't3');
  assert.equal(T.cycleTab(s, -1).activeId, 't1');
  assert.equal(T.cycleTab(T.selectTab(s, 't1'), -1).activeId, 't3');
  assert.equal(T.cycleTab(T.selectTab(s, 't3'), -1).activeId, 't2', 'wraps from first to last');
  assert.equal(T.selectByNumber(s, 1).activeId, 't3');
  assert.equal(T.selectByNumber(s, 9).activeId, 't2');
  assert.equal(T.selectByNumber(s, 5), s);
});

test('toSession / fromSession round trip keeps order and active tab', () => {
  let s = build(['https://a.com/', null, 'https://c.com/']);
  s = T.selectTab(s, 't2');
  const session = T.toSession(s, 123);
  assert.equal(session.version, 1);
  assert.equal(session.activeTabId, 't2');
  assert.deepEqual(session.tabs.map((t) => t.id), ['t1', 't2', 't3']);
  const back = T.fromSession(session);
  assert.deepEqual(back.tabs.map((t) => [t.id, t.url]), s.tabs.map((t) => [t.id, t.url]));
  assert.equal(back.activeId, 't2');
  assert.throws(() => T.fromSession({ tabs: [] }));
});
