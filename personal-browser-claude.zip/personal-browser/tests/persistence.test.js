'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { SessionPersistence } = require('../src/main/persistence');

const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const quiet = { error() {} };

function harness(initialTabs = ['a']) {
  const saved = [];
  let current = { version: 1, savedAt: 0, activeTabId: initialTabs[0], tabs: initialTabs.map((id) => ({ id, url: null, title: '' })) };
  const p = new SessionPersistence({
    store: { saveSync: (s) => saved.push(JSON.parse(JSON.stringify(s))) },
    getSession: () => current,
    debounceMs: 20,
    logger: quiet,
  });
  return { p, saved, set: (s) => { current = s; } };
}

test('does nothing until enabled (empty startup cannot overwrite a saved session)', async () => {
  const { p, saved } = harness();
  p.schedule();
  await wait(60);
  assert.equal(saved.length, 0);
  assert.equal(p.flushSync(), false);
  p.enable();
  p.schedule();
  await wait(60);
  assert.equal(saved.length, 1);
});

test('coalesces bursts into one write using the latest state', async () => {
  const { p, saved, set } = harness();
  p.enable();
  for (let i = 0; i < 10; i++) {
    set({ version: 1, savedAt: 0, activeTabId: 'a', tabs: [{ id: 'a', url: `https://x.example/${i}`, title: '' }] });
    p.schedule();
  }
  await wait(80);
  assert.equal(saved.length, 1);
  assert.equal(saved[0].tabs[0].url, 'https://x.example/9');
});

test('skips writes when nothing changed', async () => {
  const { p, saved } = harness();
  p.enable();
  p.schedule();
  await wait(50);
  p.schedule();
  await wait(50);
  assert.equal(saved.length, 1);
});

test('flushAndClose writes immediately, then blocks all later writes', async () => {
  const { p, saved, set } = harness(['a', 'b', 'c']);
  p.enable();
  p.schedule();
  p.flushAndClose();
  assert.equal(saved.length, 1);
  assert.equal(saved[0].tabs.length, 3);
  // simulate shutdown teardown destroying every tab
  set({ version: 1, savedAt: 0, activeTabId: null, tabs: [] });
  p.schedule();
  p.flushSync();
  await wait(60);
  assert.equal(saved.length, 1, 'no write after shutdown');
  p.enable();
  assert.equal(p.enabled, false, 'cannot be re-enabled after close');
});

test('save errors are swallowed and logged, not thrown', async () => {
  let n = 0;
  const logs = [];
  const p = new SessionPersistence({
    store: { saveSync: () => { n++; throw new Error('disk full'); } },
    getSession: () => ({ activeTabId: 'a', tabs: [{ id: 'a' }] }),
    debounceMs: 10,
    logger: { error: (...a) => logs.push(a.join(' ')) },
  });
  p.enable();
  p.schedule();
  await wait(40);
  assert.equal(n, 1);
  assert.match(logs[0], /disk full/);
});
