# Personal Browser

A personal Chromium-based desktop browser for Windows, built on Electron. Its main feature is automatic
session saving: close the browser completely, reopen it, and your tabs return in the same order with the
previously active tab selected.

> **Status:** the pure logic (tab state, session file, URL handling, debounce/shutdown gating) and the
> TabManager (against a *fake* `electron` module) are covered by automated tests (`npm test`).
> The app has **not** been launched inside real Electron/Chromium by its author. Run the manual checklist
> below before trusting it.

## Architecture

| Layer | Files | Role |
|---|---|---|
| Main process (trusted) | `src/main/main.js` | Single-instance lock, window, startup restore, shutdown flush |
| Tab state (pure) | `src/main/tab-state.js` | **Single source of truth** for tabs: immutable add/close/select/move/reopen/update |
| Views | `src/main/tab-manager.js` | One real `WebContentsView` per loaded tab; feeds navigation events back into tab state |
| Session file | `src/main/session-store.js` | Versioned JSON, validation, atomic write, backup, corruption recovery |
| Debounce/gating | `src/main/persistence.js` | Debounced saves; disabled until restore finishes; one-way shutdown flush |
| Security | `src/main/security.js`, `src/main/ipc.js` | Permissions, downloads, external protocols, IPC sender/arg validation |
| Browser UI (trusted) | `src/renderer/*`, `src/preload/preload.js` | Tab strip + toolbar; only a fixed `window.browserAPI` |
| Internal pages | `src/pages/*` | New-tab page and error page (static, no scripts that touch privileged APIs) |

* Electron `^41.0.0` (bundled Chromium). Uses `WebContentsView`, `webContents.navigationHistory`, and
  `setWindowOpenHandler`, all available since Electron 30-32. If `npm install` reports that range does not
  exist, run `npm install --save-dev electron@latest`. I could not verify the exact current version offline.
* Websites run in `WebContentsView`s with `sandbox: true`, `contextIsolation: true`, `nodeIntegration: false`,
  `webSecurity` on, and **no preload script**. Only the trusted UI window has a preload.
* Background tabs restored from a session are **lazy**: they show in the tab strip immediately but only get a
  Chromium view (and load) when first selected. The active tab loads first.

## Project tree

```
personal-browser/
├─ package.json
├─ README.md
├─ .gitignore
├─ src/
│  ├─ main/    main.js  config.js  tab-state.js  tab-manager.js  session-store.js
│  │           persistence.js  url-utils.js  security.js  ipc.js
│  ├─ preload/ preload.js
│  ├─ renderer/ index.html  styles.css  renderer.js
│  └─ pages/   newtab.html  newtab.css  error.html  error.css  error.js
└─ tests/      url-utils / tab-state / session-store / persistence / tab-manager .test.js
```

## Install, run, test (Windows, PowerShell)

Requires Node.js 20+ (https://nodejs.org).

```powershell
cd personal-browser
npm install
npm test        # automated tests (no Electron needed)
npm start       # run the browser
```

## Build a Windows executable

```powershell
npm run pack            # unpacked app: release\win-unpacked\Personal Browser.exe  (fastest to try)
npm run dist            # NSIS installer: release\Personal Browser Setup 1.0.0.exe
npm run dist:portable   # single portable .exe
```

If electron-builder fails with a "cannot create symbolic link" error, enable Windows *Developer Mode*
(Settings → For developers) or run the terminal as Administrator, then retry. The executable is unsigned, so
Windows SmartScreen may warn on first launch.

## Where data is stored

Everything lives under `%APPDATA%\Personal Browser\` (same folder for `npm start` and the packaged app):

* **Session metadata (tabs):** `%APPDATA%\Personal Browser\session\`
  * `session.json` - primary (tab IDs, URLs, titles, order, active tab ID, version)
  * `session.backup.json` - last-known-good copy (the previous valid primary)
  * `session.corrupt.json` - a primary file that failed validation (kept for inspection)
* **Website profile data (cookies, localStorage, IndexedDB, cache):** Electron's persistent partition
  `persist:browser`, stored by Chromium under `%APPDATA%\Personal Browser\Partitions\browser\`.

These are separate: deleting `session\` forgets your tabs but keeps logins; deleting `Partitions\` signs you out
of sites but keeps your tabs. Logins persist only as long as each website's own cookie lifetime/security rules allow.

## Session behavior (what is and is not restored)

Saved per tab: ID, latest committed main-frame URL (including same-document/SPA route changes), title, tab order,
active tab. Saved after tab create/close/select/move/navigation/title change, debounced (~400 ms, max one write
per window), plus an unconditional flush on normal shutdown (window close, quit, Windows logoff).

**Not** restored: scroll position, form input, in-page state, POST results, per-tab back/forward history
(restored tabs start with a fresh history), favicons until the page loads.

Safety rules implemented:
* Saving is disabled until restoration finishes, and the store refuses to write a session with zero valid tabs.
* On shutdown the final session is written *first*, then saving is permanently disabled and tab-closing is
  ignored, so teardown can never record "all tabs closed".
* Writes go to `session.json.tmp` → fsync → rename (with retry for Windows file locks). The old valid file is
  copied to the backup first. A corrupt primary never overwrites the backup.
* Single-instance lock: a second launch focuses the existing window (and opens a URL argument as a tab).
* Closing the last tab leaves one new-tab page.

## Security notes

* Remote content never gets Node.js, the preload, or any browser-control API. The UI IPC handlers verify the
  sender is the trusted UI frame and validate every argument.
* Websites may navigate only to `http(s)`. `file:`, `javascript:`, `data:` and custom schemes are blocked;
  `mailto:`/`tel:` ask for confirmation before opening an external app.
* Permissions: fullscreen and sanitized clipboard-write are allowed; camera/mic, location, notifications and
  clipboard-read ask (remembered until you close the browser); everything else is denied.
* Downloads show a native Save dialog. Downloaded files are **not** scanned by this app.
* Certificate errors are not bypassed (the page is blocked and an error page is shown).
* The user-agent drops the "Electron" token to improve site compatibility.

**This is not as hardened as Chrome/Edge.** It has no Safe Browsing, no sandboxed auto-update channel, and its
security depends on you updating Electron regularly (`npm install electron@latest`, rebuild). Do not rely on it for
high-risk browsing.

## Manual end-to-end checklist

Run with `npm start`, then repeat the restart tests against `release\win-unpacked\Personal Browser.exe`.

1. **Order + active tab:** open 3 different sites, select the middle tab, close the window, relaunch → 3 tabs in order, middle selected and loaded; others load when clicked.
2. **Link navigation:** click a link inside a site, wait ~1 s, close, relaunch → the latest URL returns.
3. **SPA route:** on a single-page app (e.g. GitHub, YouTube) click between pages, restart → latest route returns.
4. **Closed stays closed:** close one tab, restart → it is gone. Ctrl+Shift+T reopens it in its old position.
5. **Repeated cycles:** open/close the app 5 times → no lost or duplicated tabs.
6. **Crash recovery:** change tabs, wait 1–2 s, then `taskkill /F /IM "Personal Browser.exe"` (or kill in Task Manager), relaunch → most recent state is back.
7. **Corruption:** close the app, open `%APPDATA%\Personal Browser\session\session.json`, delete half the text, relaunch → tabs come back from the backup (and `session.corrupt.json` appears). Corrupt both files → one new-tab page, no crash.
8. **Shutdown safety:** with 5+ tabs, close the window → after relaunch all 5 tabs are still there (not zero).
9. **Cookies/storage:** log in to a site that supports it (or set a persistent cookie), restart → still logged in.
10. **New-window links:** click a `target=_blank` link → opens as a tab; the new tab cannot access any `browserAPI` (check DevTools console with Ctrl+Shift+I: `typeof browserAPI` → `undefined`).
11. **Last tab:** close every tab → a new-tab page appears; restart → one new-tab page.
12. **Controls:** back/forward/reload/stop, address bar URL vs. search, Ctrl+T/W/L/R, Ctrl+Tab and Ctrl+Shift+Tab, drag to reorder tabs, window resize/maximize (page fills the space below the toolbar).
13. **Errors:** go to `https://nonexistent.invalid` → error page, app stays alive; Try again works.

## Known limitations

* Not yet run in real Electron by the author; expect to fix small issues on first launch.
* Widevine DRM (Netflix, Spotify web, etc.) is not available in stock Electron; those sites may not play protected media.
* No extension support (no Chrome Web Store extensions).
* Some sign-in flows (notably Google) block or degrade embedded browsers. Popup-based sign-ins that rely on
  `window.opener` will not work because popups open as ordinary tabs.
* `window.open('')`/`about:blank` popups are denied. Other custom protocols are blocked (only `mailto:`/`tel:` prompt).
  Whether Chromium surfaces a given external-protocol click to `will-navigate` is not something I could verify.
* No bookmarks, history UI, find-in-page, context menu, tab pinning/groups, private windows, settings page, or multi-window.
* Per-tab back/forward history and in-page state are not persisted.
* No window size/position memory.
* Packaged exe is unsigned; no auto-update.
